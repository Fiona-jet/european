﻿// European Countryside - OpenGL Night Scene
// Features: Medieval village, castle, bridge, well, lamp posts, trees, water, moon, fog
// Controls: WASD to move, Arrow keys to look, Space/Shift for up/down, Q/E to strafe
// F for flashlight toggle, +/- for fog density, 1/2 for time of day

#define _USE_MATH_DEFINES
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// Window dimensions
const unsigned int SCR_WIDTH = 1280;
const unsigned int SCR_HEIGHT = 720;

// Camera
glm::vec3 cameraPos = glm::vec3(0.0f, 2.0f, 15.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float yaw = -90.0f;
float pitch = -5.0f;
float moveSpeed = 5.0f;
float sensitivity = 50.0f;

// Timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;
float globalTime = 0.0f;

// Scene settings
float fogDensity = 0.025f;
bool flashlightOn = false;
bool isNightScene = true;  // Toggle with N key: true=night, false=day
float fov = 60.0f; // Field of view for zoom

// ============================================================
// Collision detection - AABB obstacles
// ============================================================
struct AABB {
    glm::vec3 min;
    glm::vec3 max;
};
std::vector<AABB> obstacles;

void addObstacle(glm::vec3 center, glm::vec3 halfExtents) {
    AABB box;
    box.min = center - halfExtents;
    box.max = center + halfExtents;
    obstacles.push_back(box);
}

bool checkCollision(glm::vec3 pos, float radius = 0.5f) {
    for (const auto& ob : obstacles) {
        // Find closest point on AABB to camera
        glm::vec3 closest;
        closest.x = std::max(ob.min.x, std::min(pos.x, ob.max.x));
        closest.y = std::max(ob.min.y, std::min(pos.y, ob.max.y));
        closest.z = std::max(ob.min.z, std::min(pos.z, ob.max.z));
        float dist = glm::length(pos - closest);
        if (dist < radius) return true;
    }
    return false;
}

// ============================================================
// Interactive Door System
// ============================================================
struct DoorInfo {
    glm::vec3 housePos;       // house world position
    float houseRotY;          // house Y rotation in degrees
    float scale;              // house scale
    float openAngle;          // current animation angle (0=closed, 90=open)
    bool isOpen;              // target state
    int obstacleIndex;        // index into obstacles[] for this house's main AABB
    glm::vec3 doorWorldPos;   // computed world position of the door
};
std::vector<DoorInfo> doors;
bool gKeyWasPressed = false; // debounce for G key

// ============================================================
// Mesh structure
// ============================================================
struct Mesh {
    GLuint VAO, VBO, EBO;
    int indexCount;
    int vertexCount;
    bool useIndices;
};

struct PointLight {
    glm::vec3 position;
    glm::vec3 color;
    float radius;
};

std::vector<PointLight> pointLights;

// ============================================================
// Shader loading
// ============================================================
std::string loadFile(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        std::cerr << "ERROR: Cannot open file: " << path << std::endl;
        return "";
    }
    std::stringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

GLuint compileShader(GLenum type, const std::string& source) {
    GLuint shader = glCreateShader(type);
    const char* src = source.c_str();
    glShaderSource(shader, 1, &src, NULL);
    glCompileShader(shader);
    int success;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        char log[512];
        glGetShaderInfoLog(shader, 512, NULL, log);
        std::cerr << "Shader compilation error: " << log << std::endl;
    }
    return shader;
}

GLuint createShaderProgram(const std::string& vsPath, const std::string& fsPath) {
    std::string vsSource = loadFile(vsPath);
    std::string fsSource = loadFile(fsPath);
    GLuint vs = compileShader(GL_VERTEX_SHADER, vsSource);
    GLuint fs = compileShader(GL_FRAGMENT_SHADER, fsSource);
    GLuint program = glCreateProgram();
    glAttachShader(program, vs);
    glAttachShader(program, fs);
    glLinkProgram(program);
    int success;
    glGetProgramiv(program, GL_LINK_STATUS, &success);
    if (!success) {
        char log[512];
        glGetProgramInfoLog(program, 512, NULL, log);
        std::cerr << "Program linking error: " << log << std::endl;
    }
    glDeleteShader(vs);
    glDeleteShader(fs);
    return program;
}

// ============================================================
// Mesh creation helpers
// ============================================================
// Vertex: pos(3) + normal(3) + texcoord(2) + color(3) = 11 floats
Mesh createMesh(const std::vector<float>& vertices, const std::vector<unsigned int>& indices) {
    Mesh mesh;
    mesh.indexCount = indices.size();
    mesh.vertexCount = vertices.size() / 11;
    mesh.useIndices = !indices.empty();

    glGenVertexArrays(1, &mesh.VAO);
    glGenBuffers(1, &mesh.VBO);
    glBindVertexArray(mesh.VAO);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.VBO);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

    if (!indices.empty()) {
        glGenBuffers(1, &mesh.EBO);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);
    }

    // Position
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Normal
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // TexCoord
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);
    // Color
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(float), (void*)(8 * sizeof(float)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0);
    return mesh;
}

void drawMesh(const Mesh& mesh) {
    glBindVertexArray(mesh.VAO);
    if (mesh.useIndices)
        glDrawElements(GL_TRIANGLES, mesh.indexCount, GL_UNSIGNED_INT, 0);
    else
        glDrawArrays(GL_TRIANGLES, 0, mesh.vertexCount);
    glBindVertexArray(0);
}

// Helper to add a vertex
void addVert(std::vector<float>& v, float x, float y, float z,
    float nx, float ny, float nz, float u, float t,
    float r, float g, float b) {
    v.push_back(x); v.push_back(y); v.push_back(z);
    v.push_back(nx); v.push_back(ny); v.push_back(nz);
    v.push_back(u); v.push_back(t);
    v.push_back(r); v.push_back(g); v.push_back(b);
}

// Add a quad (two triangles) with given normal and color
void addQuad(std::vector<float>& verts, std::vector<unsigned int>& idx,
    glm::vec3 p0, glm::vec3 p1, glm::vec3 p2, glm::vec3 p3,
    glm::vec3 normal, glm::vec3 color) {
    unsigned int base = verts.size() / 11;
    addVert(verts, p0.x, p0.y, p0.z, normal.x, normal.y, normal.z, 0, 0, color.r, color.g, color.b);
    addVert(verts, p1.x, p1.y, p1.z, normal.x, normal.y, normal.z, 1, 0, color.r, color.g, color.b);
    addVert(verts, p2.x, p2.y, p2.z, normal.x, normal.y, normal.z, 1, 1, color.r, color.g, color.b);
    addVert(verts, p3.x, p3.y, p3.z, normal.x, normal.y, normal.z, 0, 1, color.r, color.g, color.b);
    idx.push_back(base); idx.push_back(base + 1); idx.push_back(base + 2);
    idx.push_back(base); idx.push_back(base + 2); idx.push_back(base + 3);
}

// ============================================================
// Create a Box mesh (for buildings, etc.)
// ============================================================
Mesh createBox(float w, float h, float d, glm::vec3 color) {
    std::vector<float> v;
    std::vector<unsigned int> idx;
    float hw = w / 2, hh = h / 2, hd = d / 2;

    // Front
    addQuad(v, idx, { -hw,  -hh, hd }, { hw, -hh, hd }, { hw, hh, hd }, { -hw, hh, hd },
        { 0,0,1 }, color);
    // Back
    addQuad(v, idx, { hw, -hh, -hd }, { -hw, -hh, -hd }, { -hw, hh, -hd }, { hw, hh, -hd },
        { 0,0,-1 }, color);
    // Left
    addQuad(v, idx, { -hw, -hh, -hd }, { -hw, -hh, hd }, { -hw, hh, hd }, { -hw, hh, -hd },
        { -1,0,0 }, color);
    // Right
    addQuad(v, idx, { hw, -hh, hd }, { hw, -hh, -hd }, { hw, hh, -hd }, { hw, hh, hd },
        { 1,0,0 }, color);
    // Top
    addQuad(v, idx, { -hw, hh, hd }, { hw, hh, hd }, { hw, hh, -hd }, { -hw, hh, -hd },
        { 0,1,0 }, color);
    // Bottom
    addQuad(v, idx, { -hw, -hh, -hd }, { hw, -hh, -hd }, { hw, -hh, hd }, { -hw, -hh, hd },
        { 0,-1,0 }, color);
    return createMesh(v, idx);
}

// ============================================================
// Create ground plane
// ============================================================
Mesh createGround(float size, glm::vec3 color) {
    std::vector<float> v;
    std::vector<unsigned int> idx;
    float hs = size / 2;
    float tileScale = size / 5.0f; // tile every 5 units
    unsigned int base = v.size() / 11;
    addVert(v, -hs, 0, hs, 0, 1, 0, 0, 0, color.r, color.g, color.b);
    addVert(v, hs, 0, hs, 0, 1, 0, tileScale, 0, color.r, color.g, color.b);
    addVert(v, hs, 0, -hs, 0, 1, 0, tileScale, tileScale, color.r, color.g, color.b);
    addVert(v, -hs, 0, -hs, 0, 1, 0, 0, tileScale, color.r, color.g, color.b);
    idx.push_back(base); idx.push_back(base + 1); idx.push_back(base + 2);
    idx.push_back(base); idx.push_back(base + 2); idx.push_back(base + 3);
    return createMesh(v, idx);
}

// ============================================================
// Create a cylinder (for lamp posts, well)
// ============================================================
Mesh createCylinder(float radius, float height, int segments, glm::vec3 color) {
    std::vector<float> v;
    std::vector<unsigned int> idx;

    for (int i = 0; i < segments; i++) {
        float a0 = 2.0f * M_PI * i / segments;
        float a1 = 2.0f * M_PI * (i + 1) / segments;
        float x0 = cos(a0) * radius, z0 = sin(a0) * radius;
        float x1 = cos(a1) * radius, z1 = sin(a1) * radius;
        float nx0 = cos(a0), nz0 = sin(a0);
        float nx1 = cos(a1), nz1 = sin(a1);
        glm::vec3 n = glm::normalize(glm::vec3((nx0 + nx1) / 2, 0, (nz0 + nz1) / 2));

        addQuad(v, idx, { x0, 0, z0 }, { x1, 0, z1 }, { x1, height, z1 }, { x0, height, z0 },
            n, color);
    }
    return createMesh(v, idx);
}

// ============================================================
// Create a cone (for roofs, tree tops)
// ============================================================
Mesh createCone(float radius, float height, int segments, glm::vec3 color) {
    std::vector<float> v;
    std::vector<unsigned int> idx;

    for (int i = 0; i < segments; i++) {
        float a0 = 2.0f * M_PI * i / segments;
        float a1 = 2.0f * M_PI * (i + 1) / segments;
        float x0 = cos(a0) * radius, z0 = sin(a0) * radius;
        float x1 = cos(a1) * radius, z1 = sin(a1) * radius;

        unsigned int base = v.size() / 11;
        glm::vec3 n = glm::normalize(glm::vec3(cos((a0 + a1) / 2), 0.3f, sin((a0 + a1) / 2)));

        addVert(v, 0, height, 0, n.x, n.y, n.z, 0.5f, 1.0f, color.r, color.g, color.b);
        addVert(v, x0, 0, z0, n.x, n.y, n.z, 0, 0, color.r, color.g, color.b);
        addVert(v, x1, 0, z1, n.x, n.y, n.z, 1, 0, color.r, color.g, color.b);

        idx.push_back(base); idx.push_back(base + 1); idx.push_back(base + 2);
    }
    return createMesh(v, idx);
}

// ============================================================
// Create sphere (for moon, decorations)
// ============================================================
Mesh createSphere(float radius, int stacks, int slices, glm::vec3 color) {
    std::vector<float> v;
    std::vector<unsigned int> idx;

    for (int i = 0; i <= stacks; i++) {
        float phi = M_PI * i / stacks;
        for (int j = 0; j <= slices; j++) {
            float theta = 2.0f * M_PI * j / slices;
            float x = sin(phi) * cos(theta);
            float y = cos(phi);
            float z = sin(phi) * sin(theta);
            addVert(v, x * radius, y * radius, z * radius, x, y, z,
                (float)j / slices, (float)i / stacks, color.r, color.g, color.b);
        }
    }
    for (int i = 0; i < stacks; i++) {
        for (int j = 0; j < slices; j++) {
            int a = i * (slices + 1) + j;
            int b = a + slices + 1;
            idx.push_back(a); idx.push_back(b); idx.push_back(a + 1);
            idx.push_back(a + 1); idx.push_back(b); idx.push_back(b + 1);
        }
    }
    return createMesh(v, idx);
}

// ============================================================
// Simple pseudo-random based on seed (deterministic)
// ============================================================
float hashFloat(int seed) {
    seed = (seed ^ 61) ^ (seed >> 16);
    seed *= 9;
    seed = seed ^ (seed >> 4);
    seed *= 0x27d4eb2d;
    seed = seed ^ (seed >> 15);
    return (float)(seed & 0x7FFFFFFF) / (float)0x7FFFFFFF;
}

// ============================================================
// Create a leaf cluster: many small quads (leaves) scattered
// in a spherical volume, each randomly oriented
// ============================================================
Mesh createLeafCluster(float radius, int leafCount, glm::vec3 color) {
    std::vector<float> v;
    std::vector<unsigned int> idx;

    float leafSize = radius * 0.18f;  // each leaf relative to cluster

    for (int i = 0; i < leafCount; i++) {
        // Deterministic random position within sphere
        float u = hashFloat(i * 3 + 0) * 2.0f - 1.0f;
        float v1 = hashFloat(i * 3 + 1) * 2.0f - 1.0f;
        float w = hashFloat(i * 3 + 2) * 2.0f - 1.0f;
        float len = sqrt(u * u + v1 * v1 + w * w);
        if (len < 0.001f) { u = 1; len = 1; }
        // Place more leaves toward the surface for a denser shell
        float r = radius * pow(hashFloat(i * 7 + 100), 0.4f);
        float px = u / len * r;
        float py = v1 / len * r;
        float pz = w / len * r;

        // Random leaf orientation angles
        float rotA = hashFloat(i * 5 + 200) * 360.0f;
        float tiltA = hashFloat(i * 5 + 300) * 60.0f - 30.0f;

        // Build leaf normal from rotation
        float ra = rotA * M_PI / 180.0f;
        float ta = tiltA * M_PI / 180.0f;
        glm::vec3 normal(sin(ra) * cos(ta), sin(ta), cos(ra) * cos(ta));
        normal = glm::normalize(normal);

        // Two perpendicular vectors to the normal for the leaf quad
        glm::vec3 up(0, 1, 0);
        if (fabs(glm::dot(normal, up)) > 0.9f) up = glm::vec3(1, 0, 0);
        glm::vec3 right = glm::normalize(glm::cross(normal, up));
        glm::vec3 forward = glm::normalize(glm::cross(right, normal));

        // Vary leaf size slightly
        float ls = leafSize * (0.7f + hashFloat(i * 11 + 400) * 0.6f);
        // Leaf shape: slightly elongated diamond/oval quad
        float lw = ls * 0.6f;   // width
        float lh = ls * 1.0f;   // height (elongated)

        // Vary green color per leaf
        float colorVar = 0.8f + hashFloat(i * 13 + 500) * 0.4f;
        glm::vec3 leafCol = color * colorVar;

        // 4 vertices of the leaf quad (diamond shape)
        glm::vec3 center(px, py, pz);
        glm::vec3 p0 = center - forward * lh;             // bottom
        glm::vec3 p1 = center + right * lw;               // right
        glm::vec3 p2 = center + forward * lh;             // top
        glm::vec3 p3 = center - right * lw;               // left

        unsigned int base = v.size() / 11;

        // Front face
        addVert(v, p0.x, p0.y, p0.z, normal.x, normal.y, normal.z, 0.5f, 0, leafCol.r, leafCol.g, leafCol.b);
        addVert(v, p1.x, p1.y, p1.z, normal.x, normal.y, normal.z, 1, 0.5f, leafCol.r, leafCol.g, leafCol.b);
        addVert(v, p2.x, p2.y, p2.z, normal.x, normal.y, normal.z, 0.5f, 1, leafCol.r, leafCol.g, leafCol.b);
        addVert(v, p3.x, p3.y, p3.z, normal.x, normal.y, normal.z, 0, 0.5f, leafCol.r, leafCol.g, leafCol.b);

        idx.push_back(base); idx.push_back(base + 1); idx.push_back(base + 2);
        idx.push_back(base); idx.push_back(base + 2); idx.push_back(base + 3);

        // Back face (so leaves visible from both sides)
        glm::vec3 bn = -normal;
        addVert(v, p0.x, p0.y, p0.z, bn.x, bn.y, bn.z, 0.5f, 0, leafCol.r, leafCol.g, leafCol.b);
        addVert(v, p3.x, p3.y, p3.z, bn.x, bn.y, bn.z, 0, 0.5f, leafCol.r, leafCol.g, leafCol.b);
        addVert(v, p2.x, p2.y, p2.z, bn.x, bn.y, bn.z, 0.5f, 1, leafCol.r, leafCol.g, leafCol.b);
        addVert(v, p1.x, p1.y, p1.z, bn.x, bn.y, bn.z, 1, 0.5f, leafCol.r, leafCol.g, leafCol.b);

        idx.push_back(base + 4); idx.push_back(base + 5); idx.push_back(base + 6);
        idx.push_back(base + 4); idx.push_back(base + 6); idx.push_back(base + 7);
    }
    return createMesh(v, idx);
}

// ============================================================
// Create a pine needle cluster: many thin elongated quads
// radiating outward in a drooping conical pattern
// ============================================================
Mesh createNeedleCluster(float radius, int needleCount, glm::vec3 color) {
    std::vector<float> v;
    std::vector<unsigned int> idx;

    float needleLen = radius * 0.55f;
    float needleW = radius * 0.018f;

    for (int i = 0; i < needleCount; i++) {
        // Distribute needles in a hemisphere-like pattern, biased outward
        float phi = hashFloat(i * 7 + 50) * 2.0f * M_PI;       // angle around trunk
        float tilt = 0.35f + hashFloat(i * 11 + 70) * 0.55f;   // droop angle (radians from vertical)
        float rDist = radius * (0.3f + hashFloat(i * 13 + 90) * 0.7f); // radial distance

        // Base point of needle (on the branch surface)
        float bx = cos(phi) * rDist * 0.3f;
        float by = hashFloat(i * 3 + 10) * radius * 0.6f;  // height variation
        float bz = sin(phi) * rDist * 0.3f;

        // Direction the needle points (outward + drooping)
        float dx = cos(phi) * sin(tilt);
        float dy = -cos(tilt) * 0.3f + 0.1f;  // slight droop
        float dz = sin(phi) * sin(tilt);
        float dLen = sqrt(dx * dx + dy * dy + dz * dz);
        if (dLen < 0.001f) dLen = 1.0f;
        dx /= dLen; dy /= dLen; dz /= dLen;

        // Tip of the needle
        float nLen = needleLen * (0.7f + hashFloat(i * 17 + 130) * 0.6f);
        float tx = bx + dx * nLen;
        float ty = by + dy * nLen;
        float tz = bz + dz * nLen;

        // Perpendicular vector for needle width
        glm::vec3 dir(dx, dy, dz);
        glm::vec3 up(0, 1, 0);
        if (fabs(glm::dot(dir, up)) > 0.95f) up = glm::vec3(1, 0, 0);
        glm::vec3 side = glm::normalize(glm::cross(dir, up));
        float hw = needleW * (0.6f + hashFloat(i * 19 + 150) * 0.8f);

        // Normal for the needle face
        glm::vec3 normal = glm::normalize(glm::cross(dir, side));

        // Vary color per needle
        float cVar = 0.75f + hashFloat(i * 23 + 170) * 0.5f;
        glm::vec3 nc = color * cVar;

        // Two triangles forming a long thin quad
        glm::vec3 p0(bx - side.x * hw, by - side.y * hw, bz - side.z * hw);
        glm::vec3 p1(bx + side.x * hw, by + side.y * hw, bz + side.z * hw);
        glm::vec3 p2(tx + side.x * hw * 0.3f, ty + side.y * hw * 0.3f, tz + side.z * hw * 0.3f);
        glm::vec3 p3(tx - side.x * hw * 0.3f, ty - side.y * hw * 0.3f, tz - side.z * hw * 0.3f);

        unsigned int base = v.size() / 11;

        // Front face
        addVert(v, p0.x, p0.y, p0.z, normal.x, normal.y, normal.z, 0, 0, nc.r, nc.g, nc.b);
        addVert(v, p1.x, p1.y, p1.z, normal.x, normal.y, normal.z, 1, 0, nc.r, nc.g, nc.b);
        addVert(v, p2.x, p2.y, p2.z, normal.x, normal.y, normal.z, 1, 1, nc.r, nc.g, nc.b);
        addVert(v, p3.x, p3.y, p3.z, normal.x, normal.y, normal.z, 0, 1, nc.r, nc.g, nc.b);
        idx.push_back(base); idx.push_back(base + 1); idx.push_back(base + 2);
        idx.push_back(base); idx.push_back(base + 2); idx.push_back(base + 3);

        // Back face
        glm::vec3 bn = -normal;
        addVert(v, p0.x, p0.y, p0.z, bn.x, bn.y, bn.z, 0, 0, nc.r, nc.g, nc.b);
        addVert(v, p3.x, p3.y, p3.z, bn.x, bn.y, bn.z, 0, 1, nc.r, nc.g, nc.b);
        addVert(v, p2.x, p2.y, p2.z, bn.x, bn.y, bn.z, 1, 1, nc.r, nc.g, nc.b);
        addVert(v, p1.x, p1.y, p1.z, bn.x, bn.y, bn.z, 1, 0, nc.r, nc.g, nc.b);
        idx.push_back(base + 4); idx.push_back(base + 5); idx.push_back(base + 6);
        idx.push_back(base + 4); idx.push_back(base + 6); idx.push_back(base + 7);
    }
    return createMesh(v, idx);
}

// ============================================================
// Create a prism roof (triangular cross-section for houses)
// ============================================================
Mesh createRoof(float w, float h, float d, glm::vec3 color) {
    std::vector<float> v;
    std::vector<unsigned int> idx;
    float hw = w / 2, hd = d / 2;

    // Left slope
    addQuad(v, idx, { -hw, 0, hd }, { 0, h, hd }, { 0, h, -hd }, { -hw, 0, -hd },
        glm::normalize(glm::vec3(-h, hw, 0)), color);
    // Right slope
    addQuad(v, idx, { 0, h, hd }, { hw, 0, hd }, { hw, 0, -hd }, { 0, h, -hd },
        glm::normalize(glm::vec3(h, hw, 0)), color);
    // Front triangle
    unsigned int base = v.size() / 11;
    addVert(v, -hw, 0, hd, 0, 0, 1, 0, 0, color.r, color.g, color.b);
    addVert(v, hw, 0, hd, 0, 0, 1, 1, 0, color.r, color.g, color.b);
    addVert(v, 0, h, hd, 0, 0, 1, 0.5f, 1, color.r, color.g, color.b);
    idx.push_back(base); idx.push_back(base + 1); idx.push_back(base + 2);
    // Back triangle
    base = v.size() / 11;
    addVert(v, hw, 0, -hd, 0, 0, -1, 0, 0, color.r, color.g, color.b);
    addVert(v, -hw, 0, -hd, 0, 0, -1, 1, 0, color.r, color.g, color.b);
    addVert(v, 0, h, -hd, 0, 0, -1, 0.5f, 1, color.r, color.g, color.b);
    idx.push_back(base); idx.push_back(base + 1); idx.push_back(base + 2);

    return createMesh(v, idx);
}

// drawDetailedBridge() is defined after drawObject() � see below

// ============================================================
// Create cobblestone road
// ============================================================
Mesh createRoad(float length, float width, glm::vec3 color) {
    std::vector<float> v;
    std::vector<unsigned int> idx;
    float hw = width / 2, hl = length / 2;
    float tileU = length / 3.0f; // tile every 3 units along length
    float tileV = width / 3.0f;  // tile every 3 units across width
    unsigned int base = v.size() / 11;
    addVert(v, -hl, 0.01f, hw, 0, 1, 0, 0, 0, color.r, color.g, color.b);
    addVert(v, hl, 0.01f, hw, 0, 1, 0, tileU, 0, color.r, color.g, color.b);
    addVert(v, hl, 0.01f, -hw, 0, 1, 0, tileU, tileV, color.r, color.g, color.b);
    addVert(v, -hl, 0.01f, -hw, 0, 1, 0, 0, tileV, color.r, color.g, color.b);
    idx.push_back(base); idx.push_back(base + 1); idx.push_back(base + 2);
    idx.push_back(base); idx.push_back(base + 2); idx.push_back(base + 3);
    return createMesh(v, idx);
}

// ============================================================
// Scene objects - all meshes
// ============================================================
// Ground
Mesh groundMesh, waterMesh;
// Buildings
Mesh houseBody, houseRoof, windowMesh;
// Castle
Mesh castleWall, castleTower, castleTowerRoof;
// Bridge (now drawn procedurally in drawDetailedBridge)
// Well
Mesh wellBase, wellRoof, wellPole;
// Tree
Mesh treeTrunk, treeBranch, leafClusterBig, leafClusterMed, leafClusterSmall;
// Pine needle clusters
Mesh needleClusterBig, needleClusterMed, needleClusterSmall;
// Lamp
Mesh lampPost, lampHead;
// Roads
Mesh mainRoad, sideRoad1, sideRoad2, squareGround;
// Moon
Mesh moonMesh;
// Stars
Mesh starMesh;
// Clouds
Mesh cloudPuff;
// Rocks
Mesh rockMesh;
// Bench
Mesh benchSeat, benchLeg;
// Farmstead
Mesh fencePostMesh, fenceRailMesh, cornStalkMesh, hayBlockMesh;

GLuint shaderProgram;

// Texture IDs
GLuint texGrass = 0, texRoad = 0, texBridge = 0, texBrick = 0, texRoof = 0, texBark = 0;

// Load a texture from file (JPG or PNG)
GLuint loadTexture(const char* path) {
    int w, h, channels;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* data = stbi_load(path, &w, &h, &channels, 0);
    if (!data) {
        std::cerr << "ERROR: Failed to load texture: " << path << std::endl;
        return 0;
    }
    GLenum format = (channels == 4) ? GL_RGBA : GL_RGB;
    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, format, w, h, 0, format, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    stbi_image_free(data);
    std::cout << "Loaded texture: " << path << " (" << w << "x" << h << ", " << channels << " ch)" << std::endl;
    return tex;
}

// ============================================================
// Set uniforms helper
// ============================================================
void setMat4(GLuint prog, const std::string& name, const glm::mat4& mat) {
    glUniformMatrix4fv(glGetUniformLocation(prog, name.c_str()), 1, GL_FALSE, glm::value_ptr(mat));
}
void setVec3(GLuint prog, const std::string& name, const glm::vec3& val) {
    glUniform3fv(glGetUniformLocation(prog, name.c_str()), 1, glm::value_ptr(val));
}
void setFloat(GLuint prog, const std::string& name, float val) {
    glUniform1f(glGetUniformLocation(prog, name.c_str()), val);
}
void setInt(GLuint prog, const std::string& name, int val) {
    glUniform1i(glGetUniformLocation(prog, name.c_str()), val);
}
void setBool(GLuint prog, const std::string& name, bool val) {
    glUniform1i(glGetUniformLocation(prog, name.c_str()), (int)val);
}

// Draw an object at a given transform
void drawObject(const Mesh& mesh, glm::mat4 model, glm::vec3 color,
    bool emissive = false, float emissiveStr = 1.0f,
    bool water = false, bool useVC = false, GLuint textureID = 0) {
    setMat4(shaderProgram, "model", model);
    setVec3(shaderProgram, "materialColor", color);
    setBool(shaderProgram, "useVertexColor", useVC);
    setBool(shaderProgram, "isEmissive", emissive);
    setFloat(shaderProgram, "emissiveStrength", emissiveStr);
    setBool(shaderProgram, "isWater", water);
    setBool(shaderProgram, "isStar", false);
    if (textureID != 0) {
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, textureID);
        setInt(shaderProgram, "textureSampler", 0);
        setBool(shaderProgram, "useTexture", true);
    }
    else {
        setBool(shaderProgram, "useTexture", false);
    }
    drawMesh(mesh);
}

// ============================================================
// Draw detailed stone arch bridge (reference: stone pillars,
// wooden railings, stairs, arch underside, brick texture)
// ============================================================
void drawDetailedBridge(glm::vec3 pos, float rotY = 0.0f) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    // --- Colours ---
    glm::vec3 stoneCol(0.55f, 0.52f, 0.48f);     // main stone
    glm::vec3 stoneDark(0.38f, 0.36f, 0.32f);     // dark stone / arch
    glm::vec3 stoneLight(0.65f, 0.62f, 0.56f);    // light stone caps
    glm::vec3 plankCol(0.32f, 0.22f, 0.12f);      // wooden planks
    glm::vec3 plankDark(0.22f, 0.15f, 0.08f);     // dark plank gaps
    glm::vec3 railWood(0.28f, 0.18f, 0.10f);      // railing beams

    // --- Dimensions ---
    float length = 12.0f;   // total bridge length along X
    float width = 5.0f;     // bridge width along Z
    float deckH = 2.2f;     // deck height above ground at peak of arch
    float archR = 3.5f;     // arch radius
    float wallH = 1.2f;     // wall height from deck surface
    float hw = width / 2.0f;
    float hl = length / 2.0f;

    // ===== STONE ARCH BODY (left and right side walls) =====
    float wallThick = 0.45f;
    int segs = 24;
    for (float side : {-1.0f, 1.0f}) {
        float zOuter = side * (hw + wallThick / 2);
        for (int i = 0; i < segs; i++) {
            float t0 = (float)i / segs;
            float t1 = (float)(i + 1) / segs;
            float x0 = -hl + t0 * length;
            float x1 = -hl + t1 * length;
            float yt0 = deckH * sin(t0 * M_PI) * 0.35f;
            float yt1 = deckH * sin(t1 * M_PI) * 0.35f;
            float yb0 = -archR * sin(t0 * M_PI) * 0.7f;
            float yb1 = -archR * sin(t1 * M_PI) * 0.7f;

            float segW = (x1 - x0);
            float segCX = (x0 + x1) / 2.0f;
            float segCYt = (yt0 + yt1) / 2.0f;
            float segCYb = (yb0 + yb1) / 2.0f;
            float segH = segCYt - segCYb;

            glm::mat4 m = glm::translate(base, glm::vec3(segCX, (segCYt + segCYb) / 2.0f, zOuter));
            m = glm::scale(m, glm::vec3(segW / 4.0f, segH / 3.0f, wallThick / 3.5f));
            drawObject(houseBody, m, stoneCol, false, 1.0f, false, false, texBrick);
        }
    }

    // ===== BRIDGE DECK (flat road surface on top) =====
    for (int i = 0; i < segs; i++) {
        float t0 = (float)i / segs;
        float t1 = (float)(i + 1) / segs;
        float x0 = -hl + t0 * length;
        float x1 = -hl + t1 * length;
        float y0 = deckH * sin(t0 * M_PI) * 0.35f;
        float y1 = deckH * sin(t1 * M_PI) * 0.35f;
        float cx = (x0 + x1) / 2.0f;
        float cy = (y0 + y1) / 2.0f;

        glm::mat4 m = glm::translate(base, glm::vec3(cx, cy, 0));
        m = glm::scale(m, glm::vec3((x1 - x0) / 4.0f + 0.002f, 0.04f, width / 3.5f));
        drawObject(houseBody, m, stoneCol, false, 1.0f, false, false, texBridge);
    }

    // Wooden plank lines on deck
    for (int i = 0; i < 20; i++) {
        float t = (float)(i + 0.5f) / 20.0f;
        float px = -hl + t * length;
        float py = deckH * sin(t * M_PI) * 0.35f + 0.045f;

        glm::mat4 m = glm::translate(base, glm::vec3(px, py, 0));
        m = glm::scale(m, glm::vec3(0.015f, 0.005f, hw * 0.9f));
        drawObject(houseBody, m, plankDark);
    }

    // ===== DECK EDGE TRIM (stone border on each side) =====
    for (float side : {-1.0f, 1.0f}) {
        for (int i = 0; i < segs; i++) {
            float t0 = (float)i / segs;
            float t1 = (float)(i + 1) / segs;
            float x0 = -hl + t0 * length;
            float x1 = -hl + t1 * length;
            float y0 = deckH * sin(t0 * M_PI) * 0.35f;
            float y1 = deckH * sin(t1 * M_PI) * 0.35f;
            float cx = (x0 + x1) / 2.0f;
            float cy = (y0 + y1) / 2.0f + 0.06f;
            float zz = side * (hw - 0.05f);

            glm::mat4 m = glm::translate(base, glm::vec3(cx, cy, zz));
            m = glm::scale(m, glm::vec3((x1 - x0) / 4.0f + 0.002f, 0.06f, 0.08f));
            drawObject(houseBody, m, stoneDark, false, 1.0f, false, false, texBrick);
        }
    }

    // ===== RAILING PILLARS (square stone posts along each side) =====
    int numPillars = 7;
    float pillarW = 0.25f;
    float pillarH = 1.0f;
    for (float side : {-1.0f, 1.0f}) {
        float zz = side * (hw + 0.05f);
        for (int i = 0; i < numPillars; i++) {
            float t = (float)(i + 0.5f) / numPillars;
            float px = -hl + t * length;
            float py = deckH * sin(t * M_PI) * 0.35f + 0.04f;

            // Main pillar body
            glm::mat4 m = glm::translate(base, glm::vec3(px, py + pillarH / 2, zz));
            m = glm::scale(m, glm::vec3(pillarW / 4.0f, pillarH / 3.0f, pillarW / 3.5f));
            drawObject(houseBody, m, stoneLight, false, 1.0f, false, false, texBrick);

            // Pillar base (wider)
            glm::mat4 pb = glm::translate(base, glm::vec3(px, py + 0.06f, zz));
            pb = glm::scale(pb, glm::vec3(pillarW * 0.42f, 0.06f, pillarW * 0.42f));
            drawObject(houseBody, pb, stoneDark);

            // Pillar cap (wider stone cap on top)
            glm::mat4 pc = glm::translate(base, glm::vec3(px, py + pillarH + 0.04f, zz));
            pc = glm::scale(pc, glm::vec3(pillarW * 0.45f, 0.04f, pillarW * 0.45f));
            drawObject(houseBody, pc, stoneLight);

            // Small decorative sphere on top of cap
            glm::mat4 ps = glm::translate(base, glm::vec3(px, py + pillarH + 0.12f, zz));
            ps = glm::scale(ps, glm::vec3(0.06f, 0.06f, 0.06f));
            drawObject(rockMesh, ps, stoneLight);
        }
    }

    // ===== HORIZONTAL RAILING BEAMS (between pillars) =====
    for (float side : {-1.0f, 1.0f}) {
        float zz = side * (hw + 0.05f);
        for (int i = 0; i < numPillars - 1; i++) {
            float t0 = (float)(i + 0.5f) / numPillars;
            float t1 = (float)(i + 1.5f) / numPillars;
            float px0 = -hl + t0 * length;
            float px1 = -hl + t1 * length;
            float py0 = deckH * sin(t0 * M_PI) * 0.35f + 0.04f;
            float py1 = deckH * sin(t1 * M_PI) * 0.35f + 0.04f;
            float cx = (px0 + px1) / 2.0f;
            float cy = (py0 + py1) / 2.0f;
            float spanLen = px1 - px0;

            // Top railing beam
            glm::mat4 m = glm::translate(base, glm::vec3(cx, cy + pillarH * 0.85f, zz));
            m = glm::scale(m, glm::vec3(spanLen / 4.0f, 0.03f, 0.025f));
            drawObject(houseBody, m, railWood);

            // Middle railing beam
            glm::mat4 m2 = glm::translate(base, glm::vec3(cx, cy + pillarH * 0.45f, zz));
            m2 = glm::scale(m2, glm::vec3(spanLen / 4.0f, 0.025f, 0.02f));
            drawObject(houseBody, m2, railWood);
        }
    }

    // ===== STAIRS on both approach ends =====
    int numSteps = 5;
    float stepW = width;
    float stepD = 0.5f;
    float stepH = 0.18f;

    for (float endSide : {-1.0f, 1.0f}) {
        for (int i = 0; i < numSteps; i++) {
            float sx = endSide * (hl + stepD * (i + 0.5f));
            float sy = -stepH * i + deckH * sin((endSide < 0 ? 0.02f : 0.98f) * M_PI) * 0.35f;

            glm::mat4 m = glm::translate(base, glm::vec3(sx, sy - stepH / 2, 0));
            m = glm::scale(m, glm::vec3(stepD / 4.0f, stepH / 3.0f, stepW / 3.5f));
            drawObject(houseBody, m, stoneCol, false, 1.0f, false, false, texBridge);

            glm::mat4 me = glm::translate(base, glm::vec3(sx - endSide * stepD * 0.4f, sy + 0.005f, 0));
            me = glm::scale(me, glm::vec3(0.01f, 0.003f, stepW / 3.6f));
            drawObject(houseBody, me, stoneDark);
        }

        for (float side : {-1.0f, 1.0f}) {
            float zz = side * (hw + wallThick / 2);
            for (int i = 0; i < numSteps; i++) {
                float sx = endSide * (hl + stepD * (i + 0.5f));
                float sy = -stepH * i + deckH * sin((endSide < 0 ? 0.02f : 0.98f) * M_PI) * 0.35f;
                float wallHere = (numSteps - i) * stepH + 0.3f;

                glm::mat4 m = glm::translate(base, glm::vec3(sx, sy - wallHere / 2, zz));
                m = glm::scale(m, glm::vec3(stepD / 4.0f, wallHere / 3.0f, wallThick / 3.5f));
                drawObject(houseBody, m, stoneDark, false, 1.0f, false, false, texBrick);
            }
        }
    }

    // ===== ARCH UNDERSIDE (visible from below) =====
    int archSegs = 20;
    float archWidth = width + wallThick * 2;
    for (int i = 0; i < archSegs; i++) {
        float t0 = (float)i / archSegs;
        float t1 = (float)(i + 1) / archSegs;
        float x0 = -hl + t0 * length;
        float x1 = -hl + t1 * length;
        float ya0 = -archR * sin(t0 * M_PI) * 0.7f;
        float ya1 = -archR * sin(t1 * M_PI) * 0.7f;
        float cx = (x0 + x1) / 2.0f;
        float cy = (ya0 + ya1) / 2.0f;
        float segW = x1 - x0;

        glm::mat4 m = glm::translate(base, glm::vec3(cx, cy, 0));
        m = glm::scale(m, glm::vec3(segW / 4.0f + 0.002f, 0.08f, archWidth / 3.5f));
        drawObject(houseBody, m, stoneDark, false, 1.0f, false, false, texBrick);
    }

    // ===== ARCH OPENING STONE RING (decorative arch border) =====
    int ringSegs = 16;
    for (float side : {-1.0f, 1.0f}) {
        float zz = side * (hw + wallThick);
        for (int i = 0; i < ringSegs; i++) {
            float a0 = M_PI * (float)i / ringSegs;
            float a1 = M_PI * (float)(i + 1) / ringSegs;
            float ax0 = cos(a0) * archR * 0.55f;
            float ay0 = -sin(a0) * archR * 0.7f;
            float ax1 = cos(a1) * archR * 0.55f;
            float ay1 = -sin(a1) * archR * 0.7f;
            float cx = (ax0 + ax1) / 2.0f;
            float cy = (ay0 + ay1) / 2.0f;

            glm::mat4 m = glm::translate(base, glm::vec3(cx, cy, zz));
            float segLen = sqrt((ax1 - ax0) * (ax1 - ax0) + (ay1 - ay0) * (ay1 - ay0));
            float angle = atan2(ay1 - ay0, ax1 - ax0);
            m = glm::rotate(m, angle, glm::vec3(0, 0, 1));
            m = glm::scale(m, glm::vec3(segLen / 4.0f + 0.01f, 0.12f, 0.08f));
            drawObject(houseBody, m, stoneLight, false, 1.0f, false, false, texBrick);
        }
    }
}

// ============================================================
// Draw a cottage house (reference: stone walls, steep thatched
// roof, dormer window, large chimney, wooden door, warm glow)
// ============================================================
void drawCottageHouse(glm::vec3 pos, float rotY, float scale = 1.0f, int doorIndex = -1) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));
    float s = scale;

    // Get door open angle for this house
    float doorOpenAngle = 0.0f;
    if (doorIndex >= 0 && doorIndex < (int)doors.size()) {
        doorOpenAngle = doors[doorIndex].openAngle;
    }

    // --- Colours matching reference ---
    glm::vec3 stoneWall(0.62f, 0.58f, 0.52f);     // warm beige-grey stone
    glm::vec3 stoneDark(0.38f, 0.35f, 0.30f);     // darker stone accents
    glm::vec3 stoneLight(0.72f, 0.68f, 0.60f);    // lighter stone highlights
    glm::vec3 roofBrown(0.28f, 0.20f, 0.12f);     // dark thatched brown
    glm::vec3 roofEdge(0.22f, 0.15f, 0.08f);      // darker roof trim
    glm::vec3 chimStone(0.42f, 0.42f, 0.44f);     // grey chimney stone
    glm::vec3 chimDark(0.32f, 0.32f, 0.34f);      // dark chimney mortar
    glm::vec3 doorWood(0.30f, 0.20f, 0.10f);      // brown wooden door
    glm::vec3 doorDark(0.18f, 0.12f, 0.06f);      // door planks
    glm::vec3 winGlow(1.0f, 0.88f, 0.42f);        // warm golden window glow
    glm::vec3 frame(0.20f, 0.14f, 0.08f);         // window/door frame
    glm::vec3 foundation(0.35f, 0.32f, 0.28f);    // dark stone foundation

    // --- Dimensions ---
    float bodyW = 3.8f * s;   // width
    float bodyH = 2.8f * s;   // wall height
    float bodyD = 3.2f * s;   // depth
    float roofH = 2.6f * s;   // roof peak height
    float hw = bodyW / 2;
    float hd = bodyD / 2;
    float o = 0.01f;          // surface offset

    // ===== FOUNDATION (dark stone strip at bottom) =====
    glm::mat4 m = glm::translate(base, glm::vec3(0, 0.1f * s, 0));
    m = glm::scale(m, glm::vec3(bodyW / 3.9f, 0.2f * s / 3.0f, bodyD / 3.4f));
    drawObject(houseBody, m, foundation, false, 1.0f, false, false, texBrick);

    // ===== MAIN STONE WALLS =====
    m = glm::translate(base, glm::vec3(0, bodyH / 2, 0));
    m = glm::scale(m, glm::vec3(bodyW / 4.0f, bodyH / 3.0f, bodyD / 3.5f));
    drawObject(houseBody, m, stoneWall, false, 1.0f, false, false, texBrick);
    float fz = hd + o;

    // ===== STEEP THATCHED ROOF =====
    m = glm::translate(base, glm::vec3(0, bodyH, 0));
    float roofOverhang = 1.18f;
    m = glm::scale(m, glm::vec3(bodyW / 5.0f * roofOverhang, roofH / 2.0f, bodyD / 4.0f * 1.2f));
    drawObject(houseRoof, m, roofBrown, false, 1.0f, false, false, texRoof);


    // ===== DORMER WINDOW (front, triangular gable) =====
    float dormerX = -0.3f * s;  // slightly left of center
    float dormerY = bodyH + roofH * 0.2f;
    float dormerW = 0.8f * s;
    float dormerH = 1.0f * s;
    float dormerD = 0.4f * s;

    // Dormer front wall
    glm::mat4 dw = glm::translate(base, glm::vec3(dormerX, dormerY + dormerH * 0.35f, fz * 0.85f));
    dw = glm::scale(dw, glm::vec3(dormerW / 4.0f, dormerH / 3.0f * 0.7f, dormerD / 3.5f));
    drawObject(houseBody, dw, stoneWall, false, 1.0f, false, false, texBrick);

    // Dormer mini roof
    glm::mat4 dr = glm::translate(base, glm::vec3(dormerX, dormerY + dormerH * 0.72f, fz * 0.85f));
    dr = glm::scale(dr, glm::vec3(dormerW / 5.2f * 1.15f, dormerH / 2.5f, dormerD / 4.0f * 1.1f));
    drawObject(houseRoof, dr, roofEdge, false, 1.0f, false, false, texRoof);

    // Dormer window glow
    glm::mat4 dgw = glm::translate(base, glm::vec3(dormerX, dormerY + dormerH * 0.38f, fz * 0.85f + dormerD * 0.25f + 0.01f));
    dgw = glm::scale(dgw, glm::vec3(0.2f * s, 0.25f * s, 0.005f));
    drawObject(houseBody, dgw, winGlow, true, 2.0f);

    // Dormer window frame
    glm::mat4 dwf;
    // Top
    dwf = glm::translate(base, glm::vec3(dormerX, dormerY + dormerH * 0.38f + 0.13f * s, fz * 0.85f + dormerD * 0.25f + 0.015f));
    dwf = glm::scale(dwf, glm::vec3(0.22f * s, 0.012f, 0.008f));
    drawObject(houseBody, dwf, frame);
    // Bottom
    dwf = glm::translate(base, glm::vec3(dormerX, dormerY + dormerH * 0.38f - 0.13f * s, fz * 0.85f + dormerD * 0.25f + 0.015f));
    dwf = glm::scale(dwf, glm::vec3(0.22f * s, 0.012f, 0.008f));
    drawObject(houseBody, dwf, frame);
    // Cross bar (vertical)
    dwf = glm::translate(base, glm::vec3(dormerX, dormerY + dormerH * 0.38f, fz * 0.85f + dormerD * 0.25f + 0.015f));
    dwf = glm::scale(dwf, glm::vec3(0.01f, 0.13f * s, 0.008f));
    drawObject(houseBody, dwf, frame);

    // ===== LARGE STONE CHIMNEY (right side) =====
    float chimX = hw + 0.25f * s;
    float chimW = 0.6f * s;
    float chimD = 0.55f * s;
    float chimH = bodyH + roofH * 0.7f;

    // Main chimney body
    glm::mat4 ch = glm::translate(base, glm::vec3(chimX, chimH / 2, -hd * 0.15f));
    ch = glm::scale(ch, glm::vec3(chimW / 4.0f, chimH / 3.0f, chimD / 3.5f));
    drawObject(houseBody, ch, chimStone, false, 1.0f, false, false, texBrick);

    // Chimney cap (wider top)
    glm::mat4 cap = glm::translate(base, glm::vec3(chimX, chimH, -hd * 0.15f));
    cap = glm::scale(cap, glm::vec3(chimW * 0.35f, 0.06f * s, chimD * 0.35f));
    drawObject(houseBody, cap, chimDark);

    // Chimney mortar lines
    for (float cy : {chimH * 0.25f, chimH * 0.45f, chimH * 0.65f, chimH * 0.85f}) {
        glm::mat4 cm = glm::translate(base, glm::vec3(chimX, cy, -hd * 0.15f + chimD * 0.26f));
        cm = glm::scale(cm, glm::vec3(chimW * 0.28f, 0.005f, 0.005f));
        drawObject(houseBody, cm, chimDark);
    }

    // ===== WOODEN DOOR (center, double doors) � ANIMATED =====
    float doorW = 0.6f * s;
    float doorH2 = 1.3f * s;
    float doorY = doorH2 / 2;

    // Door frame (always visible)
    glm::mat4 df;
    // Top
    df = glm::translate(base, glm::vec3(0, doorH2 + 0.02f * s, fz + 0.01f));
    df = glm::scale(df, glm::vec3(doorW * 0.6f, 0.03f * s, 0.02f));
    drawObject(houseBody, df, frame);
    // Left
    df = glm::translate(base, glm::vec3(-doorW * 0.48f, doorY, fz + 0.01f));
    df = glm::scale(df, glm::vec3(0.025f * s, doorH2 / 2, 0.02f));
    drawObject(houseBody, df, frame);
    // Right 
    df = glm::translate(base, glm::vec3(doorW * 0.48f, doorY, fz + 0.01f));
    df = glm::scale(df, glm::vec3(0.025f * s, doorH2 / 2, 0.02f));
    drawObject(houseBody, df, frame);

    if (doorOpenAngle < 1.0f) {
        // Door is closed � draw flat door panels
        // Door background (recessed dark area)
        glm::mat4 dd = glm::translate(base, glm::vec3(0, doorY, fz - 0.02f * s));
        dd = glm::scale(dd, glm::vec3(doorW * 0.55f, doorH2 / 3.0f, 0.04f));
        drawObject(houseBody, dd, doorDark);

        // Left door panel
        glm::mat4 dl = glm::translate(base, glm::vec3(-doorW * 0.22f, doorY, fz + 0.005f));
        dl = glm::scale(dl, glm::vec3(doorW * 0.22f, doorH2 / 3.0f * 0.95f, 0.02f));
        drawObject(houseBody, dl, doorWood);

        // Right door panel
        glm::mat4 drp = glm::translate(base, glm::vec3(doorW * 0.22f, doorY, fz + 0.005f));
        drp = glm::scale(drp, glm::vec3(doorW * 0.22f, doorH2 / 3.0f * 0.95f, 0.02f));
        drawObject(houseBody, drp, doorWood);

        // Door vertical plank lines
        for (float dx : {-0.33f, -0.1f, 0.1f, 0.33f}) {
            glm::mat4 pl = glm::translate(base, glm::vec3(dx * doorW, doorY, fz + 0.015f));
            pl = glm::scale(pl, glm::vec3(0.008f, doorH2 / 3.0f * 0.9f, 0.005f));
            drawObject(houseBody, pl, doorDark);
        }
    }
    else {
        // Door is opening/open � draw dark void on the wall surface
        // so it's visually clear the door has been opened
        glm::mat4 darkVoid = glm::translate(base, glm::vec3(0, doorY, fz + 0.002f));
        darkVoid = glm::scale(darkVoid, glm::vec3(doorW * 0.55f, doorH2 / 3.0f * 0.98f, 0.01f));
        drawObject(houseBody, darkVoid, glm::vec3(0.02f, 0.02f, 0.02f));

        // Draw swinging panels
        float rad = glm::radians(doorOpenAngle);
        float panelW = doorW * 0.44f; // width of each panel
        float panelH = doorH2 * 0.95f;

        // Left door panel � hinges on left edge, swings inward (-Z)
        glm::mat4 leftHinge = glm::translate(base, glm::vec3(-doorW * 0.44f, doorY, fz + 0.005f));
        leftHinge = glm::rotate(leftHinge, rad, glm::vec3(0, 1, 0)); // swing open
        glm::mat4 leftPanel = glm::translate(leftHinge, glm::vec3(panelW / 2, 0, 0));
        leftPanel = glm::scale(leftPanel, glm::vec3(panelW / 4.0f, panelH / 3.0f, 0.02f));
        drawObject(houseBody, leftPanel, doorWood);

        // Right door panel � hinges on right edge, swings inward (-Z)
        glm::mat4 rightHinge = glm::translate(base, glm::vec3(doorW * 0.44f, doorY, fz + 0.005f));
        rightHinge = glm::rotate(rightHinge, -rad, glm::vec3(0, 1, 0)); // swing other way
        glm::mat4 rightPanel = glm::translate(rightHinge, glm::vec3(-panelW / 2, 0, 0));
        rightPanel = glm::scale(rightPanel, glm::vec3(panelW / 4.0f, panelH / 3.0f, 0.02f));
        drawObject(houseBody, rightPanel, doorWood);
    }

    // ===== SIMPLE INTERIOR (visible when door is open) =====
    if (doorOpenAngle > 10.0f) {
        // Interior floor
        glm::mat4 iFloor = glm::translate(base, glm::vec3(0, 0.02f, 0));
        iFloor = glm::scale(iFloor, glm::vec3(bodyW / 4.2f, 0.01f, bodyD / 3.8f));
        drawObject(houseBody, iFloor, glm::vec3(0.2f, 0.14f, 0.08f));

        // Interior back wall darkened
        glm::mat4 iWall = glm::translate(base, glm::vec3(0, bodyH * 0.35f, -hd + 0.05f));
        iWall = glm::scale(iWall, glm::vec3(bodyW / 4.1f, bodyH / 3.2f, 0.01f));
        drawObject(houseBody, iWall, glm::vec3(0.35f, 0.3f, 0.25f));

        // Fireplace on back wall
        glm::mat4 fp = glm::translate(base, glm::vec3(0, 0.4f * s, -hd + 0.1f));
        fp = glm::scale(fp, glm::vec3(0.3f * s, 0.25f * s, 0.1f * s));
        drawObject(houseBody, fp, glm::vec3(0.15f, 0.12f, 0.1f));

        // Fireplace glow
        glm::mat4 fpg = glm::translate(base, glm::vec3(0, 0.25f * s, -hd + 0.15f));
        fpg = glm::scale(fpg, glm::vec3(0.15f * s, 0.12f * s, 0.05f * s));
        drawObject(houseBody, fpg, glm::vec3(1.0f, 0.5f, 0.1f), true, 3.0f);

        // Simple table
        glm::mat4 table = glm::translate(base, glm::vec3(0.5f * s, 0.45f * s, 0.2f * s));
        table = glm::scale(table, glm::vec3(0.3f * s, 0.02f * s, 0.2f * s));
        drawObject(houseBody, table, glm::vec3(0.25f, 0.18f, 0.1f));
        // Table legs
        for (float tx : {-0.25f, 0.25f}) {
            for (float tz : {-0.15f, 0.15f}) {
                glm::mat4 tl = glm::translate(base, glm::vec3((0.5f + tx * 0.3f) * s, 0.22f * s, (0.2f + tz * 0.2f) * s));
                tl = glm::scale(tl, glm::vec3(0.015f * s, 0.22f * s, 0.015f * s));
                drawObject(houseBody, tl, glm::vec3(0.2f, 0.14f, 0.08f));
            }
        }

        // Chair beside table
        glm::mat4 chair = glm::translate(base, glm::vec3(0.9f * s, 0.25f * s, 0.2f * s));
        chair = glm::scale(chair, glm::vec3(0.12f * s, 0.01f * s, 0.12f * s));
        drawObject(houseBody, chair, glm::vec3(0.22f, 0.15f, 0.08f));
        // Chair back
        glm::mat4 cb = glm::translate(base, glm::vec3(0.98f * s, 0.4f * s, 0.2f * s));
        cb = glm::scale(cb, glm::vec3(0.01f * s, 0.15f * s, 0.1f * s));
        drawObject(houseBody, cb, glm::vec3(0.2f, 0.13f, 0.07f));
    }

    // ===== FRONT WINDOWS (2, flanking the door) =====
    float winW = 0.18f * s;
    float winH = 0.22f * s;
    float winY = bodyH * 0.45f;

    for (float side : {-1.0f, 1.0f}) {
        float wx = side * (hw * 0.65f);
        float wz = fz + o + 0.01f;

        // Window glow
        glm::mat4 wg = glm::translate(base, glm::vec3(wx, winY, wz));
        wg = glm::scale(wg, glm::vec3(winW, winH, 0.005f));
        drawObject(houseBody, wg, winGlow, true, 2.2f);

        // Window frame: top, bottom, left, right, cross
        glm::mat4 wf;
        wf = glm::translate(base, glm::vec3(wx, winY + winH / 2, wz + 0.005f));
        wf = glm::scale(wf, glm::vec3(winW + 0.02f, 0.015f, 0.01f));
        drawObject(houseBody, wf, frame);
        wf = glm::translate(base, glm::vec3(wx, winY - winH / 2, wz + 0.005f));
        wf = glm::scale(wf, glm::vec3(winW + 0.02f, 0.015f, 0.01f));
        drawObject(houseBody, wf, frame);
        wf = glm::translate(base, glm::vec3(wx - winW / 2, winY, wz + 0.005f));
        wf = glm::scale(wf, glm::vec3(0.015f, winH / 2, 0.01f));
        drawObject(houseBody, wf, frame);
        wf = glm::translate(base, glm::vec3(wx + winW / 2, winY, wz + 0.005f));
        wf = glm::scale(wf, glm::vec3(0.015f, winH / 2, 0.01f));
        drawObject(houseBody, wf, frame);
        // Cross muntins
        wf = glm::translate(base, glm::vec3(wx, winY, wz + 0.005f));
        wf = glm::scale(wf, glm::vec3(0.008f, winH / 2, 0.008f));
        drawObject(houseBody, wf, frame);
        wf = glm::translate(base, glm::vec3(wx, winY, wz + 0.005f));
        wf = glm::scale(wf, glm::vec3(winW / 2, 0.008f, 0.008f));
        drawObject(houseBody, wf, frame);
    }



    // ===== SIDE WINDOWS (one on each side wall) =====
    for (float side : {-1.0f, 1.0f}) {
        float sx = side * (hw + o + 0.01f);
        glm::mat4 swg = glm::translate(base, glm::vec3(sx, winY, 0));
        swg = glm::scale(swg, glm::vec3(0.005f, winH * 0.8f, winW * 0.8f));
        drawObject(houseBody, swg, winGlow, true, 1.8f);

        // Side window frame
        glm::mat4 swf;
        swf = glm::translate(base, glm::vec3(sx + side * 0.005f, winY + winH * 0.4f, 0));
        swf = glm::scale(swf, glm::vec3(0.008f, 0.012f, winW * 0.42f));
        drawObject(houseBody, swf, frame);
        swf = glm::translate(base, glm::vec3(sx + side * 0.005f, winY - winH * 0.4f, 0));
        swf = glm::scale(swf, glm::vec3(0.008f, 0.012f, winW * 0.42f));
        drawObject(houseBody, swf, frame);
    }

    // ===== INTERIOR WARM LIGHT (point light inside) =====
    PointLight houseLight;
    houseLight.position = pos + glm::vec3(0, bodyH * 0.4f, 0);
    houseLight.color = glm::vec3(1.0f, 0.85f, 0.4f);
    houseLight.radius = 8.0f;
    pointLights.push_back(houseLight);
}

// Draw a stone-and-timber house matching reference:
// Stone/brick lower floor, timber-framed upper floor, arched
// doorway, steep roof, warm lit windows, wall lanterns
// variant: 0=small cottage, 1=medium, 2=larger with arched entry
// ============================================================
void drawStoneHouse(glm::vec3 pos, float rotY, float scaleX, float scaleY, float scaleZ,
    int variant = 1, bool hasLitWindows = true) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    // --- Colours from reference image (high contrast) ---
    glm::vec3 stone(0.25f, 0.22f, 0.18f);        // dark grey-brown stone (ground floor)
    glm::vec3 stoneDark(0.18f, 0.15f, 0.10f);    // very dark stone accents/mortar
    glm::vec3 plaster(0.72f, 0.67f, 0.58f);      // light warm cream plaster (upper floor)
    glm::vec3 timber(0.06f, 0.04f, 0.02f);       // very dark timber beams
    glm::vec3 roofCol(0.14f, 0.10f, 0.06f);      // very dark brown-black roof
    glm::vec3 doorCol(0.10f, 0.06f, 0.03f);      // very dark wood door
    glm::vec3 winGlow(1.0f, 0.88f, 0.45f);       // warm golden window glow
    glm::vec3 frame(0.06f, 0.04f, 0.02f);        // window/door frame color

    // --- Proportions scaled by variant ---
    float floorH, upperH, bodyW, bodyD, roofH;
    if (variant == 0) {           // small cottage
        floorH = 1.5f * scaleY; upperH = 1.4f * scaleY;
        bodyW = 2.6f * scaleX;  bodyD = 2.6f * scaleZ;
        roofH = 1.6f * scaleY;
    }
    else if (variant == 2) {    // larger house
        floorH = 2.0f * scaleY; upperH = 2.0f * scaleY;
        bodyW = 4.0f * scaleX;  bodyD = 3.5f * scaleZ;
        roofH = 2.4f * scaleY;
    }
    else {                      // medium (default)
        floorH = 1.8f * scaleY; upperH = 1.8f * scaleY;
        bodyW = 3.2f * scaleX;  bodyD = 3.0f * scaleZ;
        roofH = 2.0f * scaleY;
    }

    float bodyH = floorH + upperH;
    float hw = bodyW / 2;
    float hd = bodyD / 2;
    float tb = 0.05f;         // timber beam thickness
    float o = 0.015f;         // surface offset

    // ===== STONE GROUND FLOOR =====
    glm::mat4 m = glm::translate(base, glm::vec3(0, floorH / 2, 0));
    m = glm::scale(m, glm::vec3(bodyW / 4.0f, floorH / 3.0f, bodyD / 3.5f));
    drawObject(houseBody, m, stone, false, 1.0f, false, false, texBrick);

    // Stone detail: horizontal mortar line bands on ground floor (front)
    float fz = hd + o;
    for (float my : {floorH * 0.25f, floorH * 0.5f, floorH * 0.75f}) {
        glm::mat4 bm = glm::translate(base, glm::vec3(0, my, fz + 0.003f));
        bm = glm::scale(bm, glm::vec3(hw, 0.008f, 0.006f));
        drawObject(houseBody, bm, stoneDark);
    }

    // Stone quoin corners (ground floor - vertical stone accent strips)
    for (float side : {-1.0f, 1.0f}) {
        glm::mat4 q = glm::translate(base, glm::vec3(side * (hw - 0.04f), floorH / 2, fz + 0.003f));
        q = glm::scale(q, glm::vec3(0.06f, floorH / 2, 0.008f));
        drawObject(houseBody, q, stoneDark);
    }

    // ===== PLASTER UPPER FLOOR =====
    m = glm::translate(base, glm::vec3(0, floorH + upperH / 2, 0));
    m = glm::scale(m, glm::vec3(bodyW / 4.0f, upperH / 3.0f, bodyD / 3.5f));
    drawObject(houseBody, m, plaster, false, 1.0f, false, false, texBrick);

    // ===== FRONT WALL TIMBER FRAMING (upper floor only) =====
    glm::mat4 bm;

    // Floor division beam (stone-to-timber transition)
    bm = glm::translate(base, glm::vec3(0, floorH, fz + 0.005f));
    bm = glm::scale(bm, glm::vec3(hw + 0.02f, tb * 0.7f, tb * 0.5f));
    drawObject(houseBody, bm, timber);

    // Top beam (at roofline)
    bm = glm::translate(base, glm::vec3(0, bodyH - tb * 0.5f, fz + 0.005f));
    bm = glm::scale(bm, glm::vec3(hw + 0.02f, tb * 0.5f, tb * 0.5f));
    drawObject(houseBody, bm, timber);

    // Left corner vertical timber
    bm = glm::translate(base, glm::vec3(-hw + tb * 0.5f, floorH + upperH / 2, fz + 0.005f));
    bm = glm::scale(bm, glm::vec3(tb * 0.5f, upperH / 2, tb * 0.5f));
    drawObject(houseBody, bm, timber);

    // Right corner vertical timber
    bm = glm::translate(base, glm::vec3(hw - tb * 0.5f, floorH + upperH / 2, fz + 0.005f));
    bm = glm::scale(bm, glm::vec3(tb * 0.5f, upperH / 2, tb * 0.5f));
    drawObject(houseBody, bm, timber);

    // Center vertical timber (upper floor)
    bm = glm::translate(base, glm::vec3(0, floorH + upperH / 2, fz + 0.005f));
    bm = glm::scale(bm, glm::vec3(tb * 0.4f, upperH / 2, tb * 0.5f));
    drawObject(houseBody, bm, timber);

    // Cross-braces (X pattern on upper floor front)
    // Left diagonal
    bm = glm::translate(base, glm::vec3(-hw * 0.35f, floorH + upperH * 0.5f, fz + 0.005f));
    bm = glm::rotate(bm, glm::radians(28.0f), glm::vec3(0, 0, 1));
    bm = glm::scale(bm, glm::vec3(tb * 0.4f, upperH * 0.44f, tb * 0.5f));
    drawObject(houseBody, bm, timber);
    // Right diagonal
    bm = glm::translate(base, glm::vec3(hw * 0.35f, floorH + upperH * 0.5f, fz + 0.005f));
    bm = glm::rotate(bm, glm::radians(-28.0f), glm::vec3(0, 0, 1));
    bm = glm::scale(bm, glm::vec3(tb * 0.4f, upperH * 0.44f, tb * 0.5f));
    drawObject(houseBody, bm, timber);

    // ===== SIDE WALLS - timber framing on upper, stone on lower =====
    for (float side : {-1.0f, 1.0f}) {
        float sx = side * (hw + o);

        // Side stone mortar lines (ground floor)
        for (float my : {floorH * 0.3f, floorH * 0.6f}) {
            glm::mat4 sm = glm::translate(base, glm::vec3(sx + side * 0.003f, my, 0));
            sm = glm::scale(sm, glm::vec3(0.006f, 0.008f, hd));
            drawObject(houseBody, sm, stoneDark);
        }

        // Floor division horizontal timber
        bm = glm::translate(base, glm::vec3(sx + side * 0.005f, floorH, 0));
        bm = glm::scale(bm, glm::vec3(tb * 0.5f, tb * 0.6f, hd));
        drawObject(houseBody, bm, timber);

        // Diagonal brace on upper floor
        bm = glm::translate(base, glm::vec3(sx + side * 0.005f, floorH + upperH * 0.5f, 0));
        bm = glm::rotate(bm, glm::radians(side * 30.0f), glm::vec3(0, 0, 1));
        bm = glm::scale(bm, glm::vec3(tb * 0.4f, tb * 0.6f, upperH * 0.35f));
        drawObject(houseBody, bm, timber);
    }

    // ===== STEEP PEAKED ROOF (dark tiles) =====
    m = glm::translate(base, glm::vec3(0, bodyH, 0));
    m = glm::scale(m, glm::vec3(bodyW / 5.0f * 1.2f, roofH / 2.0f, bodyD / 4.0f * 1.15f));
    drawObject(houseRoof, m, roofCol, false, 1.0f, false, false, texRoof);

    // slight roof overhang (eave strip)
    bm = glm::translate(base, glm::vec3(0, bodyH + 0.01f, hd * 1.15f + 0.02f));
    bm = glm::scale(bm, glm::vec3(hw * 1.2f, 0.025f, 0.03f));
    drawObject(houseBody, bm, timber);
    bm = glm::translate(base, glm::vec3(0, bodyH + 0.01f, -hd * 1.15f - 0.02f));
    bm = glm::scale(bm, glm::vec3(hw * 1.2f, 0.025f, 0.03f));
    drawObject(houseBody, bm, timber);

    // ===== CHIMNEY =====
    float chimX = -hw * 0.35f;
    glm::mat4 chim = glm::translate(base, glm::vec3(chimX, bodyH + roofH * 0.5f, -hd * 0.3f));
    chim = glm::scale(chim, glm::vec3(0.15f, roofH * 0.4f, 0.15f));
    drawObject(houseBody, chim, stoneDark);
    // chimney cap
    glm::mat4 chimCap = glm::translate(base, glm::vec3(chimX, bodyH + roofH * 0.5f + roofH * 0.4f + 0.02f, -hd * 0.3f));
    chimCap = glm::scale(chimCap, glm::vec3(0.18f, 0.02f, 0.18f));
    drawObject(houseBody, chimCap, stoneDark);

    // ===== UPPER FLOOR WINDOWS (cross-muntin, emissive) =====
    float ww = 0.28f * scaleX;
    float wh = 0.35f * scaleY;

    if (hasLitWindows) {
        int numWin = (variant == 0) ? 1 : 2;
        float winSpacing = (variant == 0) ? 0.0f : hw * 0.4f;
        for (int wi = 0; wi < numWin; wi++) {
            float wx = (numWin == 1) ? 0.0f : (-winSpacing + wi * 2.0f * winSpacing);
            float wy = floorH + upperH * 0.5f;
            float wz = hd + o + 0.01f;

            // Window glow
            glm::mat4 win = glm::translate(base, glm::vec3(wx, wy, wz));
            win = glm::scale(win, glm::vec3(ww, wh, 0.005f));
            drawObject(houseBody, win, winGlow, true, 2.2f);

            // Frame: top, bottom, left, right
            glm::mat4 fr;
            fr = glm::translate(base, glm::vec3(wx, wy + wh / 2, wz + 0.005f));
            fr = glm::scale(fr, glm::vec3(ww + 0.02f, 0.015f, 0.01f));
            drawObject(houseBody, fr, frame);
            fr = glm::translate(base, glm::vec3(wx, wy - wh / 2, wz + 0.005f));
            fr = glm::scale(fr, glm::vec3(ww + 0.02f, 0.015f, 0.01f));
            drawObject(houseBody, fr, frame);
            fr = glm::translate(base, glm::vec3(wx - ww / 2, wy, wz + 0.005f));
            fr = glm::scale(fr, glm::vec3(0.015f, wh / 2 + 0.01f, 0.01f));
            drawObject(houseBody, fr, frame);
            fr = glm::translate(base, glm::vec3(wx + ww / 2, wy, wz + 0.005f));
            fr = glm::scale(fr, glm::vec3(0.015f, wh / 2 + 0.01f, 0.01f));
            drawObject(houseBody, fr, frame);
            // Cross muntins
            fr = glm::translate(base, glm::vec3(wx, wy, wz + 0.006f));
            fr = glm::scale(fr, glm::vec3(ww, 0.01f, 0.008f));
            drawObject(houseBody, fr, frame);
            fr = glm::translate(base, glm::vec3(wx, wy, wz + 0.006f));
            fr = glm::scale(fr, glm::vec3(0.01f, wh / 2, 0.008f));
            drawObject(houseBody, fr, frame);
        }
    }

    // ===== GROUND FLOOR: DOOR =====
    float doorW = 0.3f * scaleX;
    float doorH = 0.85f * scaleY;
    if (variant == 2) { doorW = 0.4f * scaleX; doorH = 1.1f * scaleY; }
    float doorZ = hd + o;

    // Door panel
    glm::mat4 door = glm::translate(base, glm::vec3(0, doorH / 2, doorZ + 0.005f));
    door = glm::scale(door, glm::vec3(doorW, doorH / 2, 0.01f));
    drawObject(houseBody, door, doorCol);

    // Door frame (stone surround)
    glm::mat4 df;
    df = glm::translate(base, glm::vec3(-doorW, doorH / 2, doorZ + 0.008f));
    df = glm::scale(df, glm::vec3(0.04f, doorH / 2 + 0.02f, 0.015f));
    drawObject(houseBody, df, stoneDark);
    df = glm::translate(base, glm::vec3(doorW, doorH / 2, doorZ + 0.008f));
    df = glm::scale(df, glm::vec3(0.04f, doorH / 2 + 0.02f, 0.015f));
    drawObject(houseBody, df, stoneDark);
    df = glm::translate(base, glm::vec3(0, doorH + 0.02f, doorZ + 0.008f));
    df = glm::scale(df, glm::vec3(doorW + 0.06f, 0.04f, 0.015f));
    drawObject(houseBody, df, stoneDark);

    // Arched stone keystone above door (variant 2 gets bigger arch)
    if (variant == 2) {
        glm::mat4 arch = glm::translate(base, glm::vec3(0, doorH + 0.12f, doorZ + 0.012f));
        arch = glm::scale(arch, glm::vec3(0.06f, 0.06f, 0.01f));
        drawObject(rockMesh, arch, stoneDark);
    }

    // Transom window above door
    if (hasLitWindows) {
        glm::mat4 tw = glm::translate(base, glm::vec3(0, doorH + 0.15f * scaleY, doorZ + 0.01f));
        tw = glm::scale(tw, glm::vec3(doorW * 0.7f, 0.08f * scaleY, 0.005f));
        drawObject(houseBody, tw, winGlow, true, 1.5f);
    }

    // ===== WALL LANTERNS (flanking door) =====
    if (hasLitWindows) {
        for (float lx : {-hw * 0.55f, hw * 0.55f}) {
            float ly = floorH * 0.6f;
            glm::vec3 lp(lx, ly, hd + o + 0.12f);
            glm::vec3 wlp = glm::vec3(base * glm::vec4(lp, 1.0f));

            // Bracket arm
            glm::mat4 bracket = glm::translate(base, glm::vec3(lx, ly, hd + o + 0.05f));
            bracket = glm::scale(bracket, glm::vec3(0.012f, 0.012f, 0.05f));
            drawObject(houseBody, bracket, frame);

            // Lantern housing
            glm::mat4 lh = glm::translate(base, glm::vec3(lx, ly - 0.03f, hd + o + 0.12f));
            lh = glm::scale(lh, glm::vec3(0.04f, 0.07f, 0.04f));
            drawObject(houseBody, lh, frame);

            // Lantern glow
            glm::mat4 lg = glm::translate(base, glm::vec3(lx, ly - 0.03f, hd + o + 0.12f));
            lg = glm::scale(lg, glm::vec3(0.025f, 0.05f, 0.025f));
            drawObject(houseBody, lg, glm::vec3(1.0f, 0.88f, 0.45f), true, 2.8f);

            // Lantern cap
            glm::mat4 lc = glm::translate(base, glm::vec3(lx, ly + 0.04f, hd + o + 0.12f));
            lc = glm::scale(lc, glm::vec3(0.02f, 0.01f, 0.02f));
            drawObject(castleTowerRoof, lc, frame);

            PointLight wl;
            wl.position = wlp;
            wl.color = glm::vec3(1.0f, 0.85f, 0.45f);
            wl.radius = 6.0f;
            pointLights.push_back(wl);
        }
    }

    // ===== GROUND FLOOR WINDOW (stone floor window) =====
    if (hasLitWindows) {
        float gww = 0.22f * scaleX;
        float gwh = 0.25f * scaleY;
        float gwy = floorH * 0.5f;

        // Left ground window
        glm::mat4 gw = glm::translate(base, glm::vec3(-hw * 0.55f, gwy, hd + o + 0.01f));
        gw = glm::scale(gw, glm::vec3(gww, gwh, 0.005f));
        drawObject(houseBody, gw, winGlow, true, 1.5f);

        // Stone sill
        glm::mat4 gf;
        gf = glm::translate(base, glm::vec3(-hw * 0.55f, gwy - gwh / 2 - 0.01f, hd + o + 0.015f));
        gf = glm::scale(gf, glm::vec3(gww + 0.03f, 0.02f, 0.015f));
        drawObject(houseBody, gf, stoneDark);

        // Stone lintel
        gf = glm::translate(base, glm::vec3(-hw * 0.55f, gwy + gwh / 2 + 0.01f, hd + o + 0.015f));
        gf = glm::scale(gf, glm::vec3(gww + 0.03f, 0.02f, 0.015f));
        drawObject(houseBody, gf, stoneDark);

        // Right ground window (medium and large variants)
        if (variant >= 1) {
            gw = glm::translate(base, glm::vec3(hw * 0.55f, gwy, hd + o + 0.01f));
            gw = glm::scale(gw, glm::vec3(gww, gwh, 0.005f));
            drawObject(houseBody, gw, winGlow, true, 1.5f);

            gf = glm::translate(base, glm::vec3(hw * 0.55f, gwy - gwh / 2 - 0.01f, hd + o + 0.015f));
            gf = glm::scale(gf, glm::vec3(gww + 0.03f, 0.02f, 0.015f));
            drawObject(houseBody, gf, stoneDark);
            gf = glm::translate(base, glm::vec3(hw * 0.55f, gwy + gwh / 2 + 0.01f, hd + o + 0.015f));
            gf = glm::scale(gf, glm::vec3(gww + 0.03f, 0.02f, 0.015f));
            drawObject(houseBody, gf, stoneDark);
        }
    }

    // ===== SIDE WINDOWS (one on each side, upper floor) =====
    if (hasLitWindows) {
        for (float side : {-1.0f, 1.0f}) {
            float swx = side * (hw + o + 0.005f);
            glm::mat4 sw = glm::translate(base, glm::vec3(swx, floorH + upperH * 0.5f, 0));
            sw = glm::scale(sw, glm::vec3(0.005f, 0.3f * scaleY, 0.22f * scaleZ));
            drawObject(houseBody, sw, winGlow, true, 1.5f);
        }
    }
}

// ============================================================
// Draw a detailed lamp post with lantern head
// Reference: decorative base, tapered pole, glass-panel lantern
// ============================================================
void drawLampPost(glm::vec3 pos) {
    glm::vec3 metal(0.06f, 0.06f, 0.08f);      // dark iron
    glm::vec3 metalLight(0.1f, 0.1f, 0.12f);    // lighter metal

    // === DECORATIVE BASE === wider at bottom
    // Base plate
    glm::mat4 bp = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 0.05f, 0));
    bp = glm::scale(bp, glm::vec3(0.25f, 0.05f, 0.25f));
    drawObject(houseBody, bp, metal);

    // Base column (wider cylinder)
    glm::mat4 bc = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 0.1f, 0));
    glm::mat4 bcs = glm::scale(bc, glm::vec3(1.8f, 0.15f, 1.8f));
    drawObject(lampPost, bcs, metal);

    // Decorative ring at base
    glm::mat4 ring = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 0.4f, 0));
    ring = glm::scale(ring, glm::vec3(0.12f, 0.04f, 0.12f));
    drawObject(houseBody, ring, metalLight);

    // === MAIN POLE ===
    glm::mat4 pole = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 0.3f, 0));
    glm::mat4 poles = glm::scale(pole, glm::vec3(1.0f, 0.85f, 1.0f));
    drawObject(lampPost, poles, metal);

    // Mid-pole decorative ring
    glm::mat4 midRing = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 2.0f, 0));
    midRing = glm::scale(midRing, glm::vec3(0.1f, 0.03f, 0.1f));
    drawObject(houseBody, midRing, metalLight);

    // Upper pole (slightly thinner)
    glm::mat4 upole = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 2.0f, 0));
    upole = glm::scale(upole, glm::vec3(0.8f, 0.4f, 0.8f));
    drawObject(lampPost, upole, metal);

    // === LANTERN HEAD ===
    float lh = 3.5f;  // lantern height
    glm::vec3 lpos = pos + glm::vec3(0, lh, 0);

    // Lantern bottom plate
    glm::mat4 lbp = glm::translate(glm::mat4(1.0f), lpos + glm::vec3(0, -0.2f, 0));
    lbp = glm::scale(lbp, glm::vec3(0.2f, 0.03f, 0.2f));
    drawObject(houseBody, lbp, metal);

    // Lantern frame - 4 vertical corner posts
    for (float fx : {-0.12f, 0.12f}) {
        for (float fz : {-0.12f, 0.12f}) {
            glm::mat4 fp = glm::translate(glm::mat4(1.0f), lpos + glm::vec3(fx, 0.15f, fz));
            fp = glm::scale(fp, glm::vec3(0.015f, 0.18f, 0.015f));
            drawObject(houseBody, fp, metal);
        }
    }

    // Lantern frame - horizontal rings (top and bottom of glass area)
    for (float fy : {0.0f, 0.3f}) {
        glm::mat4 hr = glm::translate(glm::mat4(1.0f), lpos + glm::vec3(0, fy, 0));
        hr = glm::scale(hr, glm::vec3(0.14f, 0.015f, 0.14f));
        drawObject(houseBody, hr, metal);
    }

    // Glass panels (4 sides - emissive warm glow)
    glm::vec3 glowColor(1.0f, 0.88f, 0.5f);
    // Front glass
    glm::mat4 gp = glm::translate(glm::mat4(1.0f), lpos + glm::vec3(0, 0.15f, 0.11f));
    gp = glm::scale(gp, glm::vec3(0.09f, 0.13f, 0.005f));
    drawObject(houseBody, gp, glowColor, true, 3.0f);
    // Back glass
    gp = glm::translate(glm::mat4(1.0f), lpos + glm::vec3(0, 0.15f, -0.11f));
    gp = glm::scale(gp, glm::vec3(0.09f, 0.13f, 0.005f));
    drawObject(houseBody, gp, glowColor, true, 3.0f);
    // Left glass
    gp = glm::translate(glm::mat4(1.0f), lpos + glm::vec3(-0.11f, 0.15f, 0));
    gp = glm::scale(gp, glm::vec3(0.005f, 0.13f, 0.09f));
    drawObject(houseBody, gp, glowColor, true, 3.0f);
    // Right glass
    gp = glm::translate(glm::mat4(1.0f), lpos + glm::vec3(0.11f, 0.15f, 0));
    gp = glm::scale(gp, glm::vec3(0.005f, 0.13f, 0.09f));
    drawObject(houseBody, gp, glowColor, true, 3.0f);

    // Lantern top cap (pyramid-like - using a small cone/box)
    glm::mat4 cap = glm::translate(glm::mat4(1.0f), lpos + glm::vec3(0, 0.35f, 0));
    cap = glm::scale(cap, glm::vec3(0.08f, 0.06f, 0.08f));
    drawObject(castleTowerRoof, cap, metal);

    // Finial (tiny spike on top)
    glm::mat4 finial = glm::translate(glm::mat4(1.0f), lpos + glm::vec3(0, 0.42f, 0));
    finial = glm::scale(finial, glm::vec3(0.15f, 0.04f, 0.15f));
    drawObject(lampPost, finial, metalLight);

    // Add point light
    PointLight pl;
    pl.position = lpos + glm::vec3(0, 0.1f, 0);
    pl.color = glm::vec3(1.0f, 0.85f, 0.5f);
    pl.radius = 14.0f;
    pointLights.push_back(pl);
}

// ============================================================
// Helper: draw a branch (tilted cylinder) from a point
// ============================================================
void drawBranch(glm::vec3 base, float angleY, float angleZ, float length, float thickness, glm::vec3 color) {
    glm::mat4 m = glm::translate(glm::mat4(1.0f), base);
    m = glm::rotate(m, glm::radians(angleY), glm::vec3(0, 1, 0));
    m = glm::rotate(m, glm::radians(angleZ), glm::vec3(0, 0, 1));
    m = glm::scale(m, glm::vec3(thickness, length, thickness));
    drawObject(treeBranch, m, color);
}

// ============================================================
// Helper: draw a leaf cluster at a point
// ============================================================
void drawLeaves(glm::vec3 center, float sx, float sy, float sz, glm::vec3 color, const Mesh& mesh) {
    glm::mat4 m = glm::translate(glm::mat4(1.0f), center);
    m = glm::scale(m, glm::vec3(sx, sy, sz));
    drawObject(mesh, m, color, false, 0, false, true);
}

// ============================================================
// Draw a realistic tree with branching trunk and leaf clusters
// ============================================================
void drawTree(glm::vec3 pos, float scale, glm::vec3 canopyColor) {
    glm::vec3 bark(0.15f, 0.1f, 0.04f);
    glm::vec3 darkBark(0.12f, 0.08f, 0.03f);
    float s = scale;

    // === MAIN TRUNK ===
    glm::mat4 m = glm::translate(glm::mat4(1.0f), pos);
    m = glm::scale(m, glm::vec3(s, s, s));
    drawObject(treeTrunk, m, darkBark, false, 1.0f, false, false, texBark);

    // Upper trunk continuation
    float trunkH = 3.5f * s;
    glm::mat4 ut = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, trunkH * 0.85f, 0));
    ut = glm::scale(ut, glm::vec3(s * 0.6f, s * 0.5f, s * 0.6f));
    drawObject(treeBranch, ut, bark);

    // === BRANCHES === visible between leaf clusters
    float brkY = trunkH * 0.65f;

    drawBranch(pos + glm::vec3(0.15f * s, brkY, 0.1f * s), 30.0f, -45.0f, s * 0.8f, s * 0.7f, bark);
    drawBranch(pos + glm::vec3(-0.1f * s, brkY, -0.05f * s), 200.0f, -40.0f, s * 0.75f, s * 0.65f, bark);
    drawBranch(pos + glm::vec3(0.05f * s, brkY + 0.5f * s, -0.15f * s), -60.0f, -50.0f, s * 0.7f, s * 0.6f, bark);
    drawBranch(pos + glm::vec3(-0.1f * s, brkY + 0.3f * s, 0.1f * s), 140.0f, -55.0f, s * 0.65f, s * 0.55f, bark);
    drawBranch(pos + glm::vec3(0.1f * s, brkY + 0.8f * s, 0), -20.0f, -35.0f, s * 0.6f, s * 0.5f, bark);
    drawBranch(pos + glm::vec3(-0.05f * s, brkY + 0.6f * s, -0.1f * s), 230.0f, -45.0f, s * 0.55f, s * 0.5f, bark);
    // Additional sub-branches
    drawBranch(pos + glm::vec3(0.2f * s, brkY + 0.2f * s, 0.2f * s), 80.0f, -60.0f, s * 0.5f, s * 0.4f, bark);
    drawBranch(pos + glm::vec3(-0.15f * s, brkY + 0.7f * s, 0.15f * s), 160.0f, -50.0f, s * 0.45f, s * 0.4f, bark);

    // === LEAF CLUSTERS === scattered around branch tips
    float fy = trunkH + 0.5f * s;

    // Color variations for natural look
    glm::vec3 c1 = canopyColor;
    glm::vec3 c2 = canopyColor * 0.82f;
    glm::vec3 c3 = canopyColor * 1.12f;
    glm::vec3 c4 = canopyColor * 0.72f;
    glm::vec3 c5 = canopyColor * 0.93f;

    // Major leaf clusters at branch tips (big clusters)
    drawLeaves(pos + glm::vec3(0, fy + 1.8f * s, 0), s * 1.4f, s * 1.2f, s * 1.4f, c1, leafClusterBig);
    drawLeaves(pos + glm::vec3(1.6f * s, fy + 0.5f * s, 0.4f * s), s * 1.2f, s * 1.0f, s * 1.1f, c2, leafClusterBig);
    drawLeaves(pos + glm::vec3(-1.5f * s, fy + 0.6f * s, -0.3f * s), s * 1.15f, s * 0.9f, s * 1.1f, c3, leafClusterBig);
    drawLeaves(pos + glm::vec3(0.3f * s, fy + 0.8f * s, -1.4f * s), s * 1.0f, s * 0.85f, s * 1.0f, c5, leafClusterBig);
    drawLeaves(pos + glm::vec3(-0.2f * s, fy + 0.7f * s, 1.3f * s), s * 1.0f, s * 0.9f, s * 1.05f, c1, leafClusterBig);

    // Medium clusters filling gaps and upper crown
    drawLeaves(pos + glm::vec3(1.0f * s, fy + 1.7f * s, -0.5f * s), s * 1.0f, s * 0.85f, s * 0.95f, c4, leafClusterMed);
    drawLeaves(pos + glm::vec3(-0.9f * s, fy + 1.9f * s, 0.6f * s), s * 0.95f, s * 0.8f, s * 0.9f, c2, leafClusterMed);
    drawLeaves(pos + glm::vec3(0.1f * s, fy + 2.8f * s, -0.1f * s), s * 0.9f, s * 0.75f, s * 0.9f, c3, leafClusterMed);
    drawLeaves(pos + glm::vec3(0.8f * s, fy + 0.3f * s, 0.9f * s), s * 0.85f, s * 0.7f, s * 0.8f, c5, leafClusterMed);
    drawLeaves(pos + glm::vec3(-1.0f * s, fy + 0.4f * s, 0.8f * s), s * 0.8f, s * 0.65f, s * 0.75f, c4, leafClusterMed);

    // Small clusters at edges and between main clusters
    drawLeaves(pos + glm::vec3(1.2f * s, fy + 1.2f * s, -0.8f * s), s * 0.75f, s * 0.6f, s * 0.7f, c1, leafClusterSmall);
    drawLeaves(pos + glm::vec3(-1.2f * s, fy + 1.3f * s, -0.7f * s), s * 0.7f, s * 0.6f, s * 0.7f, c3, leafClusterSmall);
    drawLeaves(pos + glm::vec3(1.3f * s, fy - 0.2f * s, 0), s * 0.7f, s * 0.55f, s * 0.65f, c4, leafClusterSmall);
    drawLeaves(pos + glm::vec3(-1.2f * s, fy - 0.1f * s, 0.3f * s), s * 0.65f, s * 0.5f, s * 0.6f, c2, leafClusterSmall);
    drawLeaves(pos + glm::vec3(0, fy - 0.1f * s, 1.1f * s), s * 0.6f, s * 0.5f, s * 0.6f, c5, leafClusterSmall);
    drawLeaves(pos + glm::vec3(0.2f * s, fy - 0.15f * s, -1.1f * s), s * 0.6f, s * 0.45f, s * 0.55f, c1, leafClusterSmall);
    // Extra clusters for fullness
    drawLeaves(pos + glm::vec3(0.5f * s, fy + 2.3f * s, 0.4f * s), s * 0.65f, s * 0.55f, s * 0.65f, c2, leafClusterSmall);
    drawLeaves(pos + glm::vec3(-0.6f * s, fy + 0.2f * s, -0.9f * s), s * 0.6f, s * 0.5f, s * 0.55f, c4, leafClusterSmall);
}

// ============================================================
// Draw the well
// ============================================================
void drawWell(glm::vec3 pos) {
    // Base cylinder (stone)
    glm::mat4 m = glm::translate(glm::mat4(1.0f), pos);
    drawObject(wellBase, m, glm::vec3(0.45f, 0.45f, 0.5f));

    // Left pole
    glm::mat4 pole1 = glm::translate(glm::mat4(1.0f), pos + glm::vec3(-0.6f, 1.0f, 0));
    pole1 = glm::scale(pole1, glm::vec3(0.5f, 1.0f, 0.5f));
    drawObject(lampPost, pole1, glm::vec3(0.2f, 0.12f, 0.05f));

    // Right pole
    glm::mat4 pole2 = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0.6f, 1.0f, 0));
    pole2 = glm::scale(pole2, glm::vec3(0.5f, 1.0f, 0.5f));
    drawObject(lampPost, pole2, glm::vec3(0.2f, 0.12f, 0.05f));

    // Roof beam
    glm::mat4 beam = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 3.0f, 0));
    beam = glm::scale(beam, glm::vec3(0.8f, 0.08f, 0.5f));
    drawObject(houseBody, beam, glm::vec3(0.2f, 0.12f, 0.05f));

    // Small roof
    glm::mat4 roof = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 3.1f, 0));
    roof = glm::scale(roof, glm::vec3(0.55f, 0.4f, 0.45f));
    drawObject(houseRoof, roof, glm::vec3(0.2f, 0.12f, 0.05f));
}

// ============================================================
// Draw castle
// ============================================================
void drawCastle(glm::vec3 pos) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);

    // Main wall
    glm::mat4 m = glm::translate(base, glm::vec3(0, 4.0f, 0));
    m = glm::scale(m, glm::vec3(2.5f, 4.0f, 2.0f));
    drawObject(houseBody, m, glm::vec3(0.4f, 0.4f, 0.42f));

    // Left tower
    glm::mat4 t1 = glm::translate(base, glm::vec3(-5.0f, 0, 0));
    t1 = glm::scale(t1, glm::vec3(1.0f, 1.5f, 1.0f));
    drawObject(castleTower, t1, glm::vec3(0.38f, 0.38f, 0.4f));

    // Left tower roof
    glm::mat4 tr1 = glm::translate(base, glm::vec3(-5.0f, 9.0f, 0));
    tr1 = glm::scale(tr1, glm::vec3(1.2f, 1.0f, 1.2f));
    drawObject(castleTowerRoof, tr1, glm::vec3(0.25f, 0.15f, 0.15f));

    // Right tower
    glm::mat4 t2 = glm::translate(base, glm::vec3(5.0f, 0, 0));
    t2 = glm::scale(t2, glm::vec3(1.0f, 1.5f, 1.0f));
    drawObject(castleTower, t2, glm::vec3(0.38f, 0.38f, 0.4f));

    // Right tower roof
    glm::mat4 tr2 = glm::translate(base, glm::vec3(5.0f, 9.0f, 0));
    tr2 = glm::scale(tr2, glm::vec3(1.2f, 1.0f, 1.2f));
    drawObject(castleTowerRoof, tr2, glm::vec3(0.25f, 0.15f, 0.15f));

    // Center tower (taller)
    glm::mat4 ct = glm::translate(base, glm::vec3(0, 0, -2.0f));
    ct = glm::scale(ct, glm::vec3(0.8f, 2.0f, 0.8f));
    drawObject(castleTower, ct, glm::vec3(0.42f, 0.42f, 0.44f));

    glm::mat4 ctr = glm::translate(base, glm::vec3(0, 12.0f, -2.0f));
    ctr = glm::scale(ctr, glm::vec3(1.0f, 1.2f, 1.0f));
    drawObject(castleTowerRoof, ctr, glm::vec3(0.25f, 0.15f, 0.15f));

    // Castle windows (lit)
    glm::vec3 wc(1.0f, 0.75f, 0.3f);
    glm::mat4 cw1 = glm::translate(base, glm::vec3(-2.0f, 5.5f, 2.01f));
    cw1 = glm::scale(cw1, glm::vec3(0.3f, 0.5f, 0.02f));
    drawObject(houseBody, cw1, wc, true, 2.0f);

    glm::mat4 cw2 = glm::translate(base, glm::vec3(2.0f, 5.5f, 2.01f));
    cw2 = glm::scale(cw2, glm::vec3(0.3f, 0.5f, 0.02f));
    drawObject(houseBody, cw2, wc, true, 2.0f);

    glm::mat4 cw3 = glm::translate(base, glm::vec3(0, 6.0f, 2.01f));
    cw3 = glm::scale(cw3, glm::vec3(0.4f, 0.6f, 0.02f));
    drawObject(houseBody, cw3, wc, true, 2.5f);

    // Add warm light from castle windows
    PointLight cl;
    cl.position = pos + glm::vec3(0, 6.0f, 3.0f);
    cl.color = glm::vec3(1.0f, 0.7f, 0.3f);
    cl.radius = 8.0f;
    pointLights.push_back(cl);
}

// ============================================================
// Draw a bench
// ============================================================
void drawBench(glm::vec3 pos, float rotY) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    // Seat
    glm::mat4 seat = glm::translate(base, glm::vec3(0, 0.5f, 0));
    seat = glm::scale(seat, glm::vec3(1.5f, 0.05f, 0.4f));
    drawObject(houseBody, seat, glm::vec3(0.25f, 0.15f, 0.05f));

    // Legs
    for (float x : {-0.6f, 0.6f}) {
        for (float z : {-0.15f, 0.15f}) {
            glm::mat4 leg = glm::translate(base, glm::vec3(x, 0.25f, z));
            leg = glm::scale(leg, glm::vec3(0.05f, 0.25f, 0.05f));
            drawObject(houseBody, leg, glm::vec3(0.2f, 0.12f, 0.05f));
        }
    }
}

// ============================================================
// Draw a rock cluster
// ============================================================
void drawRocks(glm::vec3 pos, float scale) {
    glm::mat4 m = glm::translate(glm::mat4(1.0f), pos);
    m = glm::scale(m, glm::vec3(scale, scale * 0.6f, scale));
    drawObject(rockMesh, m, glm::vec3(0.4f, 0.4f, 0.42f));

    glm::mat4 m2 = glm::translate(glm::mat4(1.0f), pos + glm::vec3(scale * 0.5f, 0, scale * 0.3f));
    m2 = glm::scale(m2, glm::vec3(scale * 0.7f, scale * 0.4f, scale * 0.7f));
    drawObject(rockMesh, m2, glm::vec3(0.45f, 0.43f, 0.44f));
}

// ============================================================
// Draw a large barn with gambrel-style roof
// ============================================================
void drawBarn(glm::vec3 pos, float rotY) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    // Colors
    glm::vec3 barnRed(0.35f, 0.12f, 0.08f);     // dark red-brown
    glm::vec3 barnRedLight(0.42f, 0.15f, 0.1f);
    glm::vec3 barnTrim(0.18f, 0.12f, 0.06f);     // dark wood trim
    glm::vec3 roofGrey(0.2f, 0.18f, 0.16f);      // dark grey roof
    glm::vec3 doorBrown(0.12f, 0.08f, 0.04f);

    float bw = 6.0f, bh = 5.0f, bd = 8.0f;  // barn width, height, depth

    // === Main barn body ===
    glm::mat4 m = glm::translate(base, glm::vec3(0, bh / 2, 0));
    m = glm::scale(m, glm::vec3(bw / 4.0f, bh / 3.0f, bd / 3.5f));
    drawObject(houseBody, m, barnRed, false, 1.0f, false, false, texBrick);

    // === Gambrel roof ===
    m = glm::translate(base, glm::vec3(0, bh, 0));
    m = glm::scale(m, glm::vec3(bw / 5.0f * 1.15f, 3.0f / 2.0f, bd / 4.0f * 1.1f));
    drawObject(houseRoof, m, roofGrey, false, 1.0f, false, false, texRoof);

    // === Barn door (large, front) ===
    float doorW = 1.8f, doorH = 3.5f;
    glm::mat4 d1 = glm::translate(base, glm::vec3(0, doorH / 2, bd / 2 + 0.02f));
    d1 = glm::scale(d1, glm::vec3(doorW / 2, doorH / 2, 0.02f));
    drawObject(houseBody, d1, doorBrown);

    // Door frame
    glm::mat4 df;
    df = glm::translate(base, glm::vec3(-doorW, doorH / 2, bd / 2 + 0.03f));
    df = glm::scale(df, glm::vec3(0.06f, doorH / 2 + 0.05f, 0.02f));
    drawObject(houseBody, df, barnTrim);
    df = glm::translate(base, glm::vec3(doorW, doorH / 2, bd / 2 + 0.03f));
    df = glm::scale(df, glm::vec3(0.06f, doorH / 2 + 0.05f, 0.02f));
    drawObject(houseBody, df, barnTrim);
    df = glm::translate(base, glm::vec3(0, doorH + 0.05f, bd / 2 + 0.03f));
    df = glm::scale(df, glm::vec3(doorW + 0.1f, 0.06f, 0.02f));
    drawObject(houseBody, df, barnTrim);

    // === Horizontal trim bands ===
    for (float ty : {bh * 0.35f, bh * 0.7f}) {
        glm::mat4 trim = glm::translate(base, glm::vec3(0, ty, bd / 2 + 0.015f));
        trim = glm::scale(trim, glm::vec3(bw / 2 + 0.02f, 0.04f, 0.01f));
        drawObject(houseBody, trim, barnTrim);
    }

    // === Hay loft window (upper, emissive) ===
    glm::vec3 hayGlow(0.6f, 0.5f, 0.2f);
    glm::mat4 hw = glm::translate(base, glm::vec3(0, bh + 0.8f, bd / 2 + 0.02f));
    hw = glm::scale(hw, glm::vec3(0.5f, 0.4f, 0.01f));
    drawObject(houseBody, hw, hayGlow, true, 1.8f);

    // === Side window (small, each side) ===
    for (float side : {-1.0f, 1.0f}) {
        glm::mat4 sw = glm::translate(base, glm::vec3(side * (bw / 2 + 0.02f), bh * 0.6f, 0));
        sw = glm::scale(sw, glm::vec3(0.01f, 0.35f, 0.35f));
        drawObject(houseBody, sw, hayGlow, true, 1.2f);
    }

    // Warm interior glow light
    PointLight bl;
    bl.position = pos + glm::vec3(0, 3.0f, 0);
    bl.color = glm::vec3(0.6f, 0.45f, 0.2f);
    bl.radius = 8.0f;
    pointLights.push_back(bl);
}

// ============================================================
// Draw a grain silo
// ============================================================
void drawSilo(glm::vec3 pos) {
    glm::vec3 concrete(0.5f, 0.48f, 0.45f);
    glm::vec3 capColor(0.25f, 0.18f, 0.15f);

    // Silo body (tall cylinder)
    glm::mat4 m = glm::translate(glm::mat4(1.0f), pos);
    m = glm::scale(m, glm::vec3(1.0f, 1.6f, 1.0f));
    drawObject(castleTower, m, concrete);

    // Silo cap (cone)
    glm::mat4 cap = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 9.6f, 0));
    cap = glm::scale(cap, glm::vec3(0.85f, 0.6f, 0.85f));
    drawObject(castleTowerRoof, cap, capColor);

    // Metal bands (decorative rings)
    for (float h : {2.0f, 5.0f, 8.0f}) {
        glm::mat4 band = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, h, 0));
        band = glm::scale(band, glm::vec3(0.11f, 0.04f, 0.11f));
        drawObject(houseBody, band, glm::vec3(0.3f, 0.3f, 0.32f));
    }
}

// ============================================================
// Draw a small farmhouse/cabin
// ============================================================
void drawFarmhouse(glm::vec3 pos, float rotY) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    glm::vec3 woodWall(0.35f, 0.25f, 0.12f);  // warm wood brown
    glm::vec3 roofDark(0.18f, 0.12f, 0.08f);
    glm::vec3 doorCol(0.15f, 0.1f, 0.05f);
    glm::vec3 winGlow(1.0f, 0.85f, 0.4f);

    float fw = 3.5f, fh = 2.8f, fd = 3.0f;

    // Walls
    glm::mat4 m = glm::translate(base, glm::vec3(0, fh / 2, 0));
    m = glm::scale(m, glm::vec3(fw / 4.0f, fh / 3.0f, fd / 3.5f));
    drawObject(houseBody, m, woodWall, false, 1.0f, false, false, texBrick);

    // Roof
    m = glm::translate(base, glm::vec3(0, fh, 0));
    m = glm::scale(m, glm::vec3(fw / 5.0f * 1.15f, 1.5f / 2.0f, fd / 4.0f * 1.1f));
    drawObject(houseRoof, m, roofDark, false, 1.0f, false, false, texRoof);

    // Door (properly sized: ~0.7 wide x 1.5 tall)
    glm::mat4 door = glm::translate(base, glm::vec3(0, 0.75f, fd / 2 + 0.01f));
    door = glm::scale(door, glm::vec3(0.175f, 0.5f, 0.01f));
    drawObject(houseBody, door, doorCol);

    // Front window (lit) - positioned to the right, no overlap with door
    glm::mat4 win = glm::translate(base, glm::vec3(1.2f, fh * 0.55f, fd / 2 + 0.015f));
    win = glm::scale(win, glm::vec3(0.125f, 0.15f, 0.005f));
    drawObject(houseBody, win, winGlow, true, 2.0f);

    // Side window
    glm::mat4 swin = glm::translate(base, glm::vec3(fw / 2 + 0.015f, fh * 0.55f, 0));
    swin = glm::scale(swin, glm::vec3(0.005f, 0.3f, 0.25f));
    drawObject(houseBody, swin, winGlow, true, 1.5f);

    // Chimney
    glm::mat4 chim = glm::translate(base, glm::vec3(-fw * 0.3f, fh + 1.2f, -fd * 0.2f));
    chim = glm::scale(chim, glm::vec3(0.15f, 0.6f, 0.15f));
    drawObject(houseBody, chim, glm::vec3(0.4f, 0.35f, 0.32f));

    // Porch step
    glm::mat4 step = glm::translate(base, glm::vec3(0, 0.08f, fd / 2 + 0.3f));
    step = glm::scale(step, glm::vec3(0.5f, 0.08f, 0.15f));
    drawObject(houseBody, step, glm::vec3(0.3f, 0.2f, 0.1f));

    PointLight fl;
    fl.position = pos + glm::vec3(0, 2.0f, fd / 2 + 0.5f);
    fl.color = glm::vec3(1.0f, 0.85f, 0.45f);
    fl.radius = 5.0f;
    pointLights.push_back(fl);
}

// ============================================================
// Draw a small shed/outhouse
// ============================================================
void drawShed(glm::vec3 pos, float rotY) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    glm::vec3 wood(0.3f, 0.22f, 0.1f);
    glm::vec3 roof(0.2f, 0.14f, 0.08f);

    float sw = 2.0f, sh = 2.2f, sd = 2.0f;

    // Body
    glm::mat4 m = glm::translate(base, glm::vec3(0, sh / 2, 0));
    m = glm::scale(m, glm::vec3(sw / 4.0f, sh / 3.0f, sd / 3.5f));
    drawObject(houseBody, m, wood, false, 1.0f, false, false, texBrick);

    // Roof
    m = glm::translate(base, glm::vec3(0, sh, 0));
    m = glm::scale(m, glm::vec3(sw / 5.0f * 1.15f, 1.0f / 2.0f, sd / 4.0f * 1.1f));
    drawObject(houseRoof, m, roof, false, 1.0f, false, false, texRoof);

    // Door
    glm::mat4 door = glm::translate(base, glm::vec3(0, 0.65f, sd / 2 + 0.01f));
    door = glm::scale(door, glm::vec3(0.25f, 0.65f, 0.01f));
    drawObject(houseBody, door, glm::vec3(0.12f, 0.08f, 0.04f));
}

// ============================================================
// Draw a single fence segment between two points
// ============================================================
void drawFenceSegment(glm::vec3 p1, glm::vec3 p2) {
    glm::vec3 fenceWood(0.25f, 0.18f, 0.08f);
    glm::vec3 fenceWoodDark(0.2f, 0.14f, 0.06f);

    // Posts at each end
    for (auto& p : { p1, p2 }) {
        glm::mat4 m = glm::translate(glm::mat4(1.0f), p + glm::vec3(0, 0.5f, 0));
        m = glm::scale(m, glm::vec3(0.05f, 0.5f, 0.05f));
        drawObject(houseBody, m, fenceWood);
    }

    // Two horizontal rails
    glm::vec3 mid = (p1 + p2) * 0.5f;
    glm::vec3 diff = p2 - p1;
    float len = glm::length(diff);
    float angle = atan2(diff.z, diff.x);

    for (float rh : {0.35f, 0.7f}) {
        glm::mat4 m = glm::translate(glm::mat4(1.0f), mid + glm::vec3(0, rh, 0));
        m = glm::rotate(m, -angle, glm::vec3(0, 1, 0));
        m = glm::scale(m, glm::vec3(len / 2, 0.03f, 0.02f));
        drawObject(houseBody, m, fenceWoodDark);
    }
}

// ============================================================
// Draw a rectangular fence enclosure
// ============================================================
void drawFenceLoop(glm::vec3 center, float w, float d, int segsW, int segsD) {
    float hw = w / 2, hd = d / 2;

    // Front and back edges
    for (float zSide : {hd, -hd}) {
        for (int i = 0; i < segsW; i++) {
            float x0 = -hw + (float)i / segsW * w;
            float x1 = -hw + (float)(i + 1) / segsW * w;
            drawFenceSegment(center + glm::vec3(x0, 0, zSide),
                center + glm::vec3(x1, 0, zSide));
        }
    }
    // Left and right edges
    for (float xSide : {-hw, hw}) {
        for (int i = 0; i < segsD; i++) {
            float z0 = -hd + (float)i / segsD * d;
            float z1 = -hd + (float)(i + 1) / segsD * d;
            drawFenceSegment(center + glm::vec3(xSide, 0, z0),
                center + glm::vec3(xSide, 0, z1));
        }
    }
}

// ============================================================
// Draw a corn field (rows of corn stalks)
// ============================================================
void drawCornField(glm::vec3 pos, int rows, int cols, float spacing) {
    glm::vec3 stalkGreen(0.12f, 0.28f, 0.08f);
    glm::vec3 leafGreen(0.1f, 0.32f, 0.08f);
    glm::vec3 leafDark(0.08f, 0.22f, 0.06f);

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            float x = pos.x + c * spacing - (cols * spacing / 2);
            float z = pos.z + r * spacing - (rows * spacing / 2);
            // Slight random offset for natural look
            float ox = hashFloat(r * 137 + c * 59) * 0.15f - 0.075f;
            float oz = hashFloat(r * 89 + c * 173) * 0.15f - 0.075f;
            float stalkH = 0.6f + hashFloat(r * 37 + c * 97) * 0.3f;

            glm::vec3 sp(x + ox, 0, z + oz);

            // Stalk
            glm::mat4 m = glm::translate(glm::mat4(1.0f), sp);
            m = glm::scale(m, glm::vec3(0.2f, stalkH / 3.5f, 0.2f));
            drawObject(lampPost, m, stalkGreen);

            // Leaf tufts at top (small leaf clusters)
            float leafScale = 0.08f + hashFloat(r * 53 + c * 29) * 0.05f;
            drawLeaves(sp + glm::vec3(0, stalkH, 0), leafScale, leafScale * 0.8f, leafScale,
                (hashFloat(r + c) > 0.5f) ? leafGreen : leafDark, leafClusterSmall);
        }
    }
}

// ============================================================
// Draw a vegetable garden (low rows of green)
// ============================================================
void drawVegetableGarden(glm::vec3 pos, int rows, float rowLength) {
    glm::vec3 soil(0.15f, 0.1f, 0.05f);
    glm::vec3 vegGreen(0.1f, 0.3f, 0.08f);
    glm::vec3 vegDark(0.08f, 0.25f, 0.06f);

    float rowSpacing = 0.6f;

    // Soil bed
    glm::mat4 bed = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 0.02f, 0));
    bed = glm::scale(bed, glm::vec3(rowLength / 2, 0.02f, rows * rowSpacing / 2));
    drawObject(houseBody, bed, soil);

    // Vegetable rows
    for (int r = 0; r < rows; r++) {
        float z = pos.z + r * rowSpacing - (rows * rowSpacing / 2);
        glm::vec3 rowColor = (r % 2 == 0) ? vegGreen : vegDark;

        glm::mat4 m = glm::translate(glm::mat4(1.0f),
            glm::vec3(pos.x, 0.12f, z));
        m = glm::scale(m, glm::vec3(rowLength / 2, 0.1f, 0.12f));
        drawObject(houseBody, m, rowColor);

        // Small leaf tufts along the row
        int tufts = (int)(rowLength / 0.8f);
        for (int t = 0; t < tufts; t++) {
            float tx = pos.x - rowLength / 2 + t * 0.8f + 0.4f;
            float tScale = 0.06f + hashFloat(r * 31 + t * 17) * 0.04f;
            drawLeaves(glm::vec3(tx, 0.2f, z), tScale, tScale * 0.7f, tScale,
                rowColor * 1.1f, leafClusterSmall);
        }
    }
}

// ============================================================
// Draw a hay cart
// ============================================================
void drawHayCart(glm::vec3 pos, float rotY) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    glm::vec3 cartWood(0.22f, 0.15f, 0.06f);
    glm::vec3 hayColor(0.55f, 0.48f, 0.2f);
    glm::vec3 wheelColor(0.18f, 0.12f, 0.05f);

    // Cart bed/platform
    glm::mat4 bed = glm::translate(base, glm::vec3(0, 0.6f, 0));
    bed = glm::scale(bed, glm::vec3(0.8f, 0.04f, 0.5f));
    drawObject(houseBody, bed, cartWood);

    // Cart sides (low walls)
    for (float side : {-0.48f, 0.48f}) {
        glm::mat4 wall = glm::translate(base, glm::vec3(0, 0.8f, side));
        wall = glm::scale(wall, glm::vec3(0.78f, 0.15f, 0.02f));
        drawObject(houseBody, wall, cartWood);
    }
    // Front and back walls
    for (float fb : {-0.78f, 0.78f}) {
        glm::mat4 wall = glm::translate(base, glm::vec3(fb, 0.8f, 0));
        wall = glm::scale(wall, glm::vec3(0.02f, 0.15f, 0.5f));
        drawObject(houseBody, wall, cartWood);
    }

    // Hay bale on cart
    glm::mat4 hay = glm::translate(base, glm::vec3(0, 1.0f, 0));
    hay = glm::scale(hay, glm::vec3(0.6f, 0.25f, 0.35f));
    drawObject(houseBody, hay, hayColor);

    // Wheels (4 small cylinders on their side)
    for (float wx : {-0.55f, 0.55f}) {
        for (float wz : {-0.5f, 0.5f}) {
            glm::mat4 wheel = glm::translate(base, glm::vec3(wx, 0.3f, wz));
            wheel = glm::rotate(wheel, glm::radians(90.0f), glm::vec3(1, 0, 0));
            wheel = glm::scale(wheel, glm::vec3(2.5f, 0.15f, 2.5f));
            drawObject(lampPost, wheel, wheelColor);
        }
    }

    // Cart handle/tongue
    glm::mat4 tongue = glm::translate(base, glm::vec3(1.3f, 0.45f, 0));
    tongue = glm::scale(tongue, glm::vec3(0.35f, 0.02f, 0.02f));
    drawObject(houseBody, tongue, cartWood);
}

// ============================================================
// Draw the complete farmstead compound
// ============================================================
void drawFarmstead(glm::vec3 pos) {
    // Dirt yard area
    glm::mat4 yard = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 0.015f, 0));
    yard = glm::scale(yard, glm::vec3(0.15f, 1.0f, 0.15f));
    drawObject(groundMesh, yard, glm::vec3(0.2f, 0.16f, 0.1f));

    // === Main barn (center-ish, facing south) ===
    drawBarn(pos + glm::vec3(0, 0, -3.0f), 0);

    // === Silo next to barn ===
    drawSilo(pos + glm::vec3(5.0f, 0, -4.0f));

    // === Farmhouse (to the right, facing south) ===
    drawFarmhouse(pos + glm::vec3(10.0f, 0, 2.0f), 0);

    // === Green crop rows in front of farmhouse ===
    glm::vec3 cropFieldCenter = pos + glm::vec3(10.0f, 0, 10.0f);
    drawFenceLoop(cropFieldCenter, 8.0f, 5.0f, 3, 2);
    drawVegetableGarden(cropFieldCenter, 6, 6.0f);


    // === Small shed (behind barn) ===
    drawShed(pos + glm::vec3(-5.0f, 0, -6.0f), 45);

    // === Hay cart near barn door ===
    drawHayCart(pos + glm::vec3(-3.0f, 0, 2.0f), 15);

    // === Fenced corn field (left of barn) ===
    glm::vec3 fieldCenter = pos + glm::vec3(-8.0f, 0, 5.0f);
    drawFenceLoop(fieldCenter, 10.0f, 8.0f, 4, 3);
    drawCornField(fieldCenter, 8, 10, 0.8f);

    // === Third crop field (behind farmhouse) ===
    glm::vec3 field3Center = pos + glm::vec3(12.0f, 0, -5.0f);
    drawFenceLoop(field3Center, 7.0f, 5.0f, 3, 2);
    drawCornField(field3Center, 5, 7, 0.8f);

    // === Yard lamp post ===
    drawLampPost(pos + glm::vec3(3.0f, 0, 2.0f));

    // === Trees around the farmstead ===
    glm::vec3 farmGreen(0.1f, 0.28f, 0.08f);
    glm::vec3 farmDarkGreen(0.08f, 0.22f, 0.07f);
    drawTree(pos + glm::vec3(-14.0f, 0, -2.0f), 1.2f, farmGreen);
    drawTree(pos + glm::vec3(-13.0f, 0, 8.0f), 1.0f, farmDarkGreen);
    drawTree(pos + glm::vec3(15.0f, 0, -3.0f), 1.3f, farmGreen);
    drawTree(pos + glm::vec3(14.0f, 0, 10.0f), 0.9f, farmDarkGreen);
    drawTree(pos + glm::vec3(0, 0, -12.0f), 1.1f, farmGreen);
    drawTree(pos + glm::vec3(8.0f, 0, -10.0f), 1.0f, farmDarkGreen);

    // === Rocks scattered ===
    drawRocks(pos + glm::vec3(-3.0f, 0, -8.0f), 0.5f);
    drawRocks(pos + glm::vec3(12.0f, 0, -5.0f), 0.4f);
}

// ============================================================
// Draw a church/chapel with bell tower steeple
// ============================================================
void drawChurch(glm::vec3 pos, float rotY) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    glm::vec3 woodWall(0.32f, 0.24f, 0.14f);    // warm brown wood
    glm::vec3 stoneWall(0.38f, 0.35f, 0.3f);     // stone grey
    glm::vec3 roofDark(0.15f, 0.1f, 0.06f);      // dark roof
    glm::vec3 doorCol(0.1f, 0.07f, 0.03f);       // very dark door
    glm::vec3 winGlow(1.0f, 0.85f, 0.4f);        // warm window glow
    glm::vec3 crossCol(0.35f, 0.3f, 0.25f);      // dark metal cross

    float cw = 4.5f, ch = 4.0f, cd = 6.0f;       // church body

    // === Main nave (body) ===
    glm::mat4 m = glm::translate(base, glm::vec3(0, ch / 2, 0));
    m = glm::scale(m, glm::vec3(cw / 4.0f, ch / 3.0f, cd / 3.5f));
    drawObject(houseBody, m, woodWall, false, 1.0f, false, false, texBrick);

    // === Main roof (peaked) ===
    m = glm::translate(base, glm::vec3(0, ch, 0));
    m = glm::scale(m, glm::vec3(cw / 5.0f * 1.2f, 2.2f / 2.0f, cd / 4.0f * 1.1f));
    drawObject(houseRoof, m, roofDark, false, 1.0f, false, false, texRoof);

    // === Bell tower/steeple (front of church) ===
    float tw = 1.8f, th = 6.5f;  // tower dimensions
    glm::mat4 tower = glm::translate(base, glm::vec3(0, th / 2, cd / 2 + tw / 2 - 0.3f));
    tower = glm::scale(tower, glm::vec3(tw / 4.0f, th / 3.0f, tw / 3.5f));
    drawObject(houseBody, tower, stoneWall, false, 1.0f, false, false, texBrick);

    // Steeple roof (tall pointed cone)
    glm::mat4 steeple = glm::translate(base, glm::vec3(0, th, cd / 2 + tw / 2 - 0.3f));
    steeple = glm::scale(steeple, glm::vec3(0.6f, 1.2f, 0.6f));
    drawObject(castleTowerRoof, steeple, roofDark, false, 1.0f, false, false, texRoof);

    // Cross on top of steeple
    float crossY = th + 3.5f;
    float crossZ = cd / 2 + tw / 2 - 0.3f;
    // Vertical bar
    glm::mat4 cv = glm::translate(base, glm::vec3(0, crossY, crossZ));
    cv = glm::scale(cv, glm::vec3(0.03f, 0.35f, 0.03f));
    drawObject(houseBody, cv, crossCol);
    // Horizontal bar
    glm::mat4 ch2 = glm::translate(base, glm::vec3(0, crossY + 0.15f, crossZ));
    ch2 = glm::scale(ch2, glm::vec3(0.2f, 0.03f, 0.03f));
    drawObject(houseBody, ch2, crossCol);

    // === Arched entrance (front of tower) ===
    float dw = 0.5f, dh = 2.0f;
    glm::mat4 door = glm::translate(base, glm::vec3(0, dh / 2, cd / 2 + tw - 0.3f + 0.02f));
    door = glm::scale(door, glm::vec3(dw, dh / 2, 0.02f));
    drawObject(houseBody, door, doorCol);

    // Arch above door (half-circle approximation)
    glm::mat4 arch = glm::translate(base, glm::vec3(0, dh + 0.15f, cd / 2 + tw - 0.3f + 0.025f));
    arch = glm::scale(arch, glm::vec3(0.08f, 0.08f, 0.01f));
    drawObject(rockMesh, arch, stoneWall);

    // Door frame
    glm::mat4 df;
    df = glm::translate(base, glm::vec3(-dw, dh / 2, cd / 2 + tw - 0.3f + 0.03f));
    df = glm::scale(df, glm::vec3(0.04f, dh / 2 + 0.03f, 0.015f));
    drawObject(houseBody, df, stoneWall);
    df = glm::translate(base, glm::vec3(dw, dh / 2, cd / 2 + tw - 0.3f + 0.03f));
    df = glm::scale(df, glm::vec3(0.04f, dh / 2 + 0.03f, 0.015f));
    drawObject(houseBody, df, stoneWall);

    // === Tower window (emissive, belfry opening) ===
    glm::mat4 bw = glm::translate(base, glm::vec3(0, th * 0.7f, cd / 2 + tw - 0.3f + 0.02f));
    bw = glm::scale(bw, glm::vec3(0.22f, 0.35f, 0.005f));
    drawObject(houseBody, bw, winGlow, true, 2.5f);

    // === Side windows (arched, emissive, 3 on each side) ===
    for (float side : {-1.0f, 1.0f}) {
        for (int i = 0; i < 3; i++) {
            float wz = -cd / 3 + i * (cd / 3);
            glm::mat4 sw = glm::translate(base, glm::vec3(side * (cw / 2 + 0.015f), ch * 0.55f, wz));
            sw = glm::scale(sw, glm::vec3(0.005f, 0.4f, 0.25f));
            drawObject(houseBody, sw, winGlow, true, 1.8f);

            // Small arch detail above window
            glm::mat4 wa = glm::translate(base, glm::vec3(side * (cw / 2 + 0.02f), ch * 0.55f + 0.42f, wz));
            wa = glm::scale(wa, glm::vec3(0.005f, 0.04f, 0.04f));
            drawObject(rockMesh, wa, stoneWall);
        }
    }

    // === Stone chimney on rear ===
    glm::mat4 chim = glm::translate(base, glm::vec3(cw * 0.35f, ch + 1.5f, -cd / 2 + 0.5f));
    chim = glm::scale(chim, glm::vec3(0.2f, 0.7f, 0.2f));
    drawObject(houseBody, chim, stoneWall);

    // === Steps in front of entrance ===
    for (int s = 0; s < 3; s++) {
        float stepW = 0.7f + s * 0.15f;
        float stepH = 0.08f;
        float stepZ = cd / 2 + tw - 0.3f + 0.3f + s * 0.25f;
        glm::mat4 step = glm::translate(base, glm::vec3(0, stepH * (3 - s) - 0.04f, stepZ));
        step = glm::scale(step, glm::vec3(stepW, stepH, 0.12f));
        drawObject(houseBody, step, stoneWall * 0.9f);
    }

    // Interior warm glow light
    PointLight cl;
    cl.position = pos + glm::vec3(0, 2.5f, 0);
    cl.color = glm::vec3(1.0f, 0.8f, 0.4f);
    cl.radius = 10.0f;
    pointLights.push_back(cl);

    // Tower lantern light
    PointLight tl;
    tl.position = pos + glm::vec3(0, th * 0.7f, cd / 2 + tw - 0.3f + 0.5f);
    tl.color = glm::vec3(1.0f, 0.85f, 0.45f);
    tl.radius = 6.0f;
    pointLights.push_back(tl);
}

// ============================================================
// Draw a conifer/pine tree (stacked cones on trunk + leaves)
// ============================================================
void drawConiferTree(glm::vec3 pos, float scale) {
    glm::vec3 bark(0.12f, 0.08f, 0.03f);
    glm::vec3 pine1(0.06f, 0.18f, 0.06f);   // dark pine green
    glm::vec3 pine2(0.08f, 0.22f, 0.07f);   // slightly lighter
    glm::vec3 pine3(0.05f, 0.15f, 0.05f);   // darkest
    glm::vec3 leaf1(0.06f, 0.2f, 0.06f);    // leaf cluster greens
    glm::vec3 leaf2(0.08f, 0.24f, 0.08f);
    glm::vec3 leaf3(0.04f, 0.16f, 0.05f);
    float s = scale;

    // Trunk
    glm::mat4 m = glm::translate(glm::mat4(1.0f), pos);
    m = glm::scale(m, glm::vec3(s * 0.5f, s * 0.6f, s * 0.5f));
    drawObject(treeTrunk, m, bark, false, 1.0f, false, false, texBark);

    // Bottom cone (widest)
    glm::mat4 c1 = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 1.5f * s, 0));
    c1 = glm::scale(c1, glm::vec3(s * 1.2f, s * 1.5f, s * 1.2f));
    drawObject(castleTowerRoof, c1, pine1);

    // Middle cone
    glm::mat4 c2 = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 3.2f * s, 0));
    c2 = glm::scale(c2, glm::vec3(s * 0.9f, s * 1.3f, s * 0.9f));
    drawObject(castleTowerRoof, c2, pine2);

    // Top cone (narrowest)
    glm::mat4 c3 = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 4.8f * s, 0));
    c3 = glm::scale(c3, glm::vec3(s * 0.6f, s * 1.1f, s * 0.6f));
    drawObject(castleTowerRoof, c3, pine3);

    // ===== NEEDLE CLUSTERS around each tier (pine-like) =====
    // Dense ring of needles around bottom cone base
    int needleSegs = 10;
    for (int i = 0; i < needleSegs; i++) {
        float angle = 2.0f * M_PI * i / needleSegs;
        float r1 = s * 1.35f;
        float lx = cos(angle) * r1;
        float lz = sin(angle) * r1;
        glm::vec3 lc = (i % 3 == 0) ? leaf1 : ((i % 3 == 1) ? leaf2 : leaf3);
        drawLeaves(pos + glm::vec3(lx, 1.6f * s, lz),
            s * 0.75f, s * 0.45f, s * 0.75f, lc, needleClusterBig);
    }

    // Needles around bottom cone mid-height (offset ring)
    for (int i = 0; i < needleSegs; i++) {
        float angle = 2.0f * M_PI * i / needleSegs + 0.32f;
        float r2 = s * 1.05f;
        float lx = cos(angle) * r2;
        float lz = sin(angle) * r2;
        glm::vec3 lc = (i % 2 == 0) ? leaf2 : leaf3;
        drawLeaves(pos + glm::vec3(lx, 2.4f * s, lz),
            s * 0.65f, s * 0.4f, s * 0.65f, lc, needleClusterMed);
    }

    // Needles around middle cone
    int midSegs = 8;
    for (int i = 0; i < midSegs; i++) {
        float angle = 2.0f * M_PI * i / midSegs + 0.2f;
        float r3 = s * 0.9f;
        float lx = cos(angle) * r3;
        float lz = sin(angle) * r3;
        glm::vec3 lc = (i % 2 == 0) ? leaf1 : leaf3;
        drawLeaves(pos + glm::vec3(lx, 3.4f * s, lz),
            s * 0.55f, s * 0.35f, s * 0.55f, lc, needleClusterMed);
    }

    // Needles around middle cone upper portion
    for (int i = 0; i < 6; i++) {
        float angle = 2.0f * M_PI * i / 6 + 0.5f;
        float r4 = s * 0.7f;
        float lx = cos(angle) * r4;
        float lz = sin(angle) * r4;
        drawLeaves(pos + glm::vec3(lx, 4.2f * s, lz),
            s * 0.48f, s * 0.3f, s * 0.48f, leaf2, needleClusterSmall);
    }

    // Needles around top cone
    for (int i = 0; i < 5; i++) {
        float angle = 2.0f * M_PI * i / 5 + 0.8f;
        float r5 = s * 0.55f;
        float lx = cos(angle) * r5;
        float lz = sin(angle) * r5;
        drawLeaves(pos + glm::vec3(lx, 5.2f * s, lz),
            s * 0.4f, s * 0.25f, s * 0.4f, leaf1, needleClusterSmall);
    }

    // Top needle cluster (spire)
    drawLeaves(pos + glm::vec3(0, 5.8f * s, 0),
        s * 0.32f, s * 0.22f, s * 0.32f, leaf3, needleClusterSmall);
}

// ============================================================
// Draw a cylindrical hay bale
// ============================================================
void drawHayBale(glm::vec3 pos, float rotY) {
    glm::vec3 hayCol(0.5f, 0.42f, 0.18f);      // golden straw
    glm::vec3 haySide(0.45f, 0.38f, 0.15f);    // slightly darker sides

    glm::mat4 m = glm::translate(glm::mat4(1.0f), pos);
    m = glm::rotate(m, glm::radians(rotY), glm::vec3(0, 1, 0));
    // Lay cylinder on its side
    m = glm::rotate(m, glm::radians(90.0f), glm::vec3(0, 0, 1));
    m = glm::scale(m, glm::vec3(3.5f, 0.4f, 3.5f));
    drawObject(lampPost, m, hayCol);
}

// ============================================================
// Draw a windmill with rotating blades
// ============================================================
void drawWindmill(glm::vec3 pos, float rotY) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    // --- Colours ---
    glm::vec3 stoneBase(0.35f, 0.30f, 0.22f);     // warm stone lower
    glm::vec3 stoneDark(0.25f, 0.20f, 0.14f);      // dark mortar / detail
    glm::vec3 woodBody(0.45f, 0.38f, 0.25f);       // light wooden upper
    glm::vec3 timber(0.12f, 0.08f, 0.04f);         // dark timber beams
    glm::vec3 roofCol(0.18f, 0.12f, 0.07f);        // dark cap
    glm::vec3 bladeWood(0.4f, 0.35f, 0.22f);       // blade frame
    glm::vec3 bladeSail(0.55f, 0.52f, 0.45f);       // sail canvas
    glm::vec3 winGlow(1.0f, 0.88f, 0.45f);         // window glow
    glm::vec3 doorCol(0.1f, 0.06f, 0.03f);         // dark door

    // --- Proportions ---
    float towerW = 3.2f, towerD = 3.2f;
    float stoneH = 4.0f;      // stone lower section
    float woodH = 4.5f;       // wood upper section
    float totalH = stoneH + woodH;
    float capH = 2.5f;

    // ===== STONE LOWER BODY =====
    glm::mat4 m = glm::translate(base, glm::vec3(0, stoneH / 2, 0));
    m = glm::scale(m, glm::vec3(towerW / 4.0f, stoneH / 3.0f, towerD / 3.5f));
    drawObject(houseBody, m, stoneBase, false, 1.0f, false, false, texBrick);

    // Stone detail: horizontal bands
    for (float my : {stoneH * 0.25f, stoneH * 0.5f, stoneH * 0.75f}) {
        glm::mat4 band = glm::translate(base, glm::vec3(0, my, towerD / 2 + 0.02f));
        band = glm::scale(band, glm::vec3(towerW / 2 + 0.02f, 0.03f, 0.015f));
        drawObject(houseBody, band, stoneDark);
    }

    // Corner stone quoins
    for (float sx : {-1.0f, 1.0f}) {
        glm::mat4 q = glm::translate(base, glm::vec3(sx * (towerW / 2 - 0.06f), stoneH / 2, towerD / 2 + 0.02f));
        q = glm::scale(q, glm::vec3(0.08f, stoneH / 2, 0.015f));
        drawObject(houseBody, q, stoneDark);
    }

    // ===== WOOD UPPER BODY =====
    m = glm::translate(base, glm::vec3(0, stoneH + woodH / 2, 0));
    m = glm::scale(m, glm::vec3(towerW / 4.0f * 0.92f, woodH / 3.0f, towerD / 3.5f * 0.92f));
    drawObject(houseBody, m, woodBody, false, 1.0f, false, false, texBrick);

    // Timber beams on upper
    // Horizontal transition beam
    glm::mat4 bm = glm::translate(base, glm::vec3(0, stoneH, towerD / 2 + 0.02f));
    bm = glm::scale(bm, glm::vec3(towerW / 2 + 0.02f, 0.06f, 0.03f));
    drawObject(houseBody, bm, timber);

    // Vertical corner timbers
    for (float sx : {-1.0f, 1.0f}) {
        bm = glm::translate(base, glm::vec3(sx * (towerW / 2 * 0.92f - 0.04f), stoneH + woodH / 2, towerD / 2 * 0.92f + 0.02f));
        bm = glm::scale(bm, glm::vec3(0.04f, woodH / 2, 0.03f));
        drawObject(houseBody, bm, timber);
    }

    // Cross braces on wood section (X pattern)
    bm = glm::translate(base, glm::vec3(-towerW * 0.12f, stoneH + woodH * 0.5f, towerD / 2 * 0.92f + 0.02f));
    bm = glm::rotate(bm, glm::radians(25.0f), glm::vec3(0, 0, 1));
    bm = glm::scale(bm, glm::vec3(0.035f, woodH * 0.42f, 0.025f));
    drawObject(houseBody, bm, timber);
    bm = glm::translate(base, glm::vec3(towerW * 0.12f, stoneH + woodH * 0.5f, towerD / 2 * 0.92f + 0.02f));
    bm = glm::rotate(bm, glm::radians(-25.0f), glm::vec3(0, 0, 1));
    bm = glm::scale(bm, glm::vec3(0.035f, woodH * 0.42f, 0.025f));
    drawObject(houseBody, bm, timber);

    // ===== CAP/ROOF (cone) =====
    m = glm::translate(base, glm::vec3(0, totalH, 0));
    m = glm::scale(m, glm::vec3(towerW / 4.0f * 1.15f, capH / 3.0f, towerD / 4.0f * 1.15f));
    drawObject(castleTowerRoof, m, roofCol, false, 1.0f, false, false, texRoof);

    // ===== DOOR =====
    float doorW = 0.55f, doorH = 1.8f;
    glm::mat4 door = glm::translate(base, glm::vec3(0, doorH / 2, towerD / 2 + 0.03f));
    door = glm::scale(door, glm::vec3(doorW, doorH / 2, 0.02f));
    drawObject(houseBody, door, doorCol);
    // Door frame
    glm::mat4 df;
    df = glm::translate(base, glm::vec3(-doorW, doorH / 2, towerD / 2 + 0.04f));
    df = glm::scale(df, glm::vec3(0.05f, doorH / 2 + 0.05f, 0.02f));
    drawObject(houseBody, df, stoneDark);
    df = glm::translate(base, glm::vec3(doorW, doorH / 2, towerD / 2 + 0.04f));
    df = glm::scale(df, glm::vec3(0.05f, doorH / 2 + 0.05f, 0.02f));
    drawObject(houseBody, df, stoneDark);
    df = glm::translate(base, glm::vec3(0, doorH + 0.05f, towerD / 2 + 0.04f));
    df = glm::scale(df, glm::vec3(doorW + 0.08f, 0.05f, 0.02f));
    drawObject(houseBody, df, stoneDark);

    // ===== WINDOW (emissive, on upper body) =====
    float ww = 0.35f, wh = 0.45f;
    float wy = stoneH + woodH * 0.55f;
    glm::mat4 win = glm::translate(base, glm::vec3(0, wy, towerD / 2 * 0.92f + 0.03f));
    win = glm::scale(win, glm::vec3(ww, wh, 0.005f));
    drawObject(houseBody, win, winGlow, true, 2.5f);
    // Window frame
    glm::mat4 fr;
    fr = glm::translate(base, glm::vec3(0, wy + wh / 2, towerD / 2 * 0.92f + 0.035f));
    fr = glm::scale(fr, glm::vec3(ww + 0.04f, 0.025f, 0.015f));
    drawObject(houseBody, fr, timber);
    fr = glm::translate(base, glm::vec3(0, wy - wh / 2, towerD / 2 * 0.92f + 0.035f));
    fr = glm::scale(fr, glm::vec3(ww + 0.04f, 0.025f, 0.015f));
    drawObject(houseBody, fr, timber);
    fr = glm::translate(base, glm::vec3(-ww / 2, wy, towerD / 2 * 0.92f + 0.035f));
    fr = glm::scale(fr, glm::vec3(0.02f, wh / 2 + 0.02f, 0.015f));
    drawObject(houseBody, fr, timber);
    fr = glm::translate(base, glm::vec3(ww / 2, wy, towerD / 2 * 0.92f + 0.035f));
    fr = glm::scale(fr, glm::vec3(0.02f, wh / 2 + 0.02f, 0.015f));
    drawObject(houseBody, fr, timber);
    // Cross muntin
    fr = glm::translate(base, glm::vec3(0, wy, towerD / 2 * 0.92f + 0.04f));
    fr = glm::scale(fr, glm::vec3(ww, 0.015f, 0.012f));
    drawObject(houseBody, fr, timber);

    // Side windows (small)
    for (float side : {-1.0f, 1.0f}) {
        glm::mat4 sw = glm::translate(base, glm::vec3(side * (towerW / 2 * 0.92f + 0.02f), wy, 0));
        sw = glm::scale(sw, glm::vec3(0.005f, 0.3f, 0.25f));
        drawObject(houseBody, sw, winGlow, true, 1.5f);
    }

    // ===== WOODEN PLATFORM at base =====
    glm::mat4 plat = glm::translate(base, glm::vec3(0, 0.08f, 0));
    plat = glm::scale(plat, glm::vec3(towerW / 2 + 0.4f, 0.08f, towerD / 2 + 0.4f));
    drawObject(houseBody, plat, timber);

    // Support beams under platform
    for (float bx : {-towerW / 2 - 0.2f, towerW / 2 + 0.2f}) {
        for (float bz : {-towerD / 2 - 0.2f, towerD / 2 + 0.2f}) {
            glm::mat4 sb = glm::translate(base, glm::vec3(bx, 0.04f, bz));
            sb = glm::scale(sb, glm::vec3(0.08f, 0.04f, 0.08f));
            drawObject(houseBody, sb, timber);
        }
    }

    // ===== ROTATING BLADES =====
    float bladeLen = 5.0f;
    float bladeW = 0.8f;
    float hubY = totalH - 0.8f;    // near the top of the tower body
    float hubZ = towerD / 2 * 0.92f + 0.25f;  // slightly in front
    float bladeAngle = globalTime * 25.0f;  // degrees per second rotation

    // Hub
    glm::mat4 hub = glm::translate(base, glm::vec3(0, hubY, hubZ));
    hub = glm::scale(hub, glm::vec3(0.2f, 0.2f, 0.15f));
    drawObject(houseBody, hub, timber);

    // Four blades, 90 degrees apart
    for (int i = 0; i < 4; i++) {
        float angle = bladeAngle + i * 90.0f;
        float rad = glm::radians(angle);

        // Hub to blade-tip direction (in YZ plane of the front face)
        // Blade extends radially from hub
        glm::mat4 bladeBase = glm::translate(base, glm::vec3(0, hubY, hubZ));
        bladeBase = glm::rotate(bladeBase, rad, glm::vec3(0, 0, 1));

        // Blade frame (long beam from hub outward along local +Y)
        glm::mat4 bf = glm::translate(bladeBase, glm::vec3(0, bladeLen / 2 + 0.2f, 0));
        bf = glm::scale(bf, glm::vec3(0.06f, bladeLen / 2, 0.04f));
        drawObject(houseBody, bf, bladeWood);

        // Cross struts on blade
        for (float sy : {bladeLen * 0.3f, bladeLen * 0.55f, bladeLen * 0.8f}) {
            glm::mat4 strut = glm::translate(bladeBase, glm::vec3(0, sy, 0));
            strut = glm::scale(strut, glm::vec3(bladeW / 2, 0.03f, 0.03f));
            drawObject(houseBody, strut, bladeWood);
        }

        // Sail canvas (thin quad filling one side of the blade frame)
        glm::mat4 sail = glm::translate(bladeBase, glm::vec3(bladeW * 0.22f, bladeLen * 0.5f + 0.2f, 0.01f));
        sail = glm::scale(sail, glm::vec3(bladeW * 0.38f, bladeLen * 0.35f, 0.005f));
        drawObject(houseBody, sail, bladeSail);
    }

    // Axle (cylinder from hub into the tower)
    glm::mat4 axle = glm::translate(base, glm::vec3(0, hubY, hubZ - 0.15f));
    axle = glm::rotate(axle, glm::radians(90.0f), glm::vec3(1, 0, 0));
    axle = glm::scale(axle, glm::vec3(1.2f, 0.12f, 1.2f));
    drawObject(lampPost, axle, timber);

    // ===== POINT LIGHT from window =====
    PointLight wl;
    wl.position = glm::vec3(base * glm::vec4(0, wy, towerD / 2 * 0.92f + 0.5f, 1.0f));
    wl.color = glm::vec3(1.0f, 0.85f, 0.45f);
    wl.radius = 8.0f;
    pointLights.push_back(wl);
}

// ============================================================
// Draw a water lily (pad + flower) on water surface
// ============================================================
void drawWaterLily(glm::vec3 pos, float scale, float rotY) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    // Lily pad: flat green disc (heavily squashed sphere)
    glm::vec3 padGreen(0.08f, 0.28f, 0.06f);
    glm::vec3 padDark(0.06f, 0.2f, 0.04f);
    glm::mat4 pad = glm::translate(base, glm::vec3(0, 0.01f, 0));
    pad = glm::scale(pad, glm::vec3(scale * 0.6f, scale * 0.02f, scale * 0.6f));
    drawObject(rockMesh, pad, padGreen);

    // Second smaller overlapping pad (offset)
    glm::mat4 pad2 = glm::translate(base, glm::vec3(scale * 0.3f, 0.01f, scale * 0.15f));
    pad2 = glm::scale(pad2, glm::vec3(scale * 0.45f, scale * 0.02f, scale * 0.45f));
    drawObject(rockMesh, pad2, padDark);

    // Flower centre (small yellow sphere)
    glm::vec3 centerYellow(0.85f, 0.75f, 0.2f);
    glm::mat4 fc = glm::translate(base, glm::vec3(scale * 0.1f, 0.06f * scale, scale * 0.05f));
    fc = glm::scale(fc, glm::vec3(scale * 0.06f, scale * 0.04f, scale * 0.06f));
    drawObject(rockMesh, fc, centerYellow);

    // Petals: ring of small flattened cones around the centre
    glm::vec3 petalWhite(0.9f, 0.85f, 0.88f);
    glm::vec3 petalPink(0.9f, 0.6f, 0.7f);
    int petalCount = 8;
    float petalR = scale * 0.12f;
    for (int i = 0; i < petalCount; i++) {
        float angle = 2.0f * M_PI * i / petalCount;
        float px = cos(angle) * petalR + scale * 0.1f;
        float pz = sin(angle) * petalR + scale * 0.05f;
        glm::vec3 pCol = (i % 2 == 0) ? petalWhite : petalPink;

        glm::mat4 petal = glm::translate(base, glm::vec3(px, 0.04f * scale, pz));
        // Tilt petal outward
        petal = glm::rotate(petal, angle, glm::vec3(0, 1, 0));
        petal = glm::rotate(petal, glm::radians(30.0f), glm::vec3(0, 0, 1));
        petal = glm::scale(petal, glm::vec3(scale * 0.04f, scale * 0.06f, scale * 0.025f));
        drawObject(houseBody, petal, pCol);
    }
}

// ============================================================
// Draw a low-poly sheep (realistic rounded wool body)
// ============================================================
void drawSheep(glm::vec3 pos, float rotY, float scale = 1.0f) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));
    float s = scale;

    glm::vec3 wool1(0.84f, 0.82f, 0.76f);       // light cream wool
    glm::vec3 wool2(0.76f, 0.73f, 0.67f);       // medium wool
    glm::vec3 wool3(0.7f, 0.68f, 0.62f);        // darker wool (shadows)
    glm::vec3 wool4(0.8f, 0.78f, 0.72f);        // mid-tone
    glm::vec3 face(0.08f, 0.06f, 0.05f);        // very dark face
    glm::vec3 faceMid(0.14f, 0.11f, 0.08f);     // slightly lighter face
    glm::vec3 legCol(0.08f, 0.06f, 0.04f);      // dark legs
    glm::vec3 hoofCol(0.05f, 0.04f, 0.03f);     // nearly black hooves
    glm::vec3 earInner(0.35f, 0.2f, 0.18f);     // pinkish inner ear
    glm::vec3 noseCol(0.25f, 0.15f, 0.12f);     // pinkish nose

    // === WOOLLY BODY (multiple overlapping spheres for fluffy look) ===
    // Main body core (large oval sphere)
    glm::mat4 body = glm::translate(base, glm::vec3(0, 0.55f * s, 0));
    body = glm::scale(body, glm::vec3(0.42f * s, 0.28f * s, 0.3f * s));
    drawObject(rockMesh, body, wool1);

    // Upper wool bulge (makes the back rounder)
    glm::mat4 upper = glm::translate(base, glm::vec3(-0.02f * s, 0.7f * s, 0));
    upper = glm::scale(upper, glm::vec3(0.35f * s, 0.18f * s, 0.26f * s));
    drawObject(rockMesh, upper, wool2);

    // Front wool puff (chest area)
    glm::mat4 chest = glm::translate(base, glm::vec3(0.22f * s, 0.58f * s, 0));
    chest = glm::scale(chest, glm::vec3(0.2f * s, 0.22f * s, 0.24f * s));
    drawObject(rockMesh, chest, wool4);

    // Rear wool puff
    glm::mat4 rear = glm::translate(base, glm::vec3(-0.22f * s, 0.55f * s, 0));
    rear = glm::scale(rear, glm::vec3(0.2f * s, 0.22f * s, 0.25f * s));
    drawObject(rockMesh, rear, wool2);

    // Side wool tufts (left and right for roundness)
    for (float side : {-1.0f, 1.0f}) {
        glm::mat4 sideTuft = glm::translate(base, glm::vec3(0, 0.55f * s, side * 0.18f * s));
        sideTuft = glm::scale(sideTuft, glm::vec3(0.3f * s, 0.2f * s, 0.16f * s));
        drawObject(rockMesh, sideTuft, wool3);
    }

    // Top wool tufts (small bumps for fluffy texture)
    glm::mat4 t1 = glm::translate(base, glm::vec3(0.1f * s, 0.78f * s, 0.05f * s));
    t1 = glm::scale(t1, glm::vec3(0.1f * s, 0.08f * s, 0.1f * s));
    drawObject(rockMesh, t1, wool1);
    glm::mat4 t2 = glm::translate(base, glm::vec3(-0.08f * s, 0.76f * s, -0.06f * s));
    t2 = glm::scale(t2, glm::vec3(0.09f * s, 0.07f * s, 0.09f * s));
    drawObject(rockMesh, t2, wool4);
    glm::mat4 t3 = glm::translate(base, glm::vec3(0.0f, 0.8f * s, 0));
    t3 = glm::scale(t3, glm::vec3(0.08f * s, 0.06f * s, 0.08f * s));
    drawObject(rockMesh, t3, wool2);

    // === HEAD (elongated sphere - NOT a box) ===
    glm::mat4 head = glm::translate(base, glm::vec3(0.45f * s, 0.62f * s, 0));
    head = glm::rotate(head, glm::radians(-8.0f), glm::vec3(0, 0, 1));  // slight tilt down
    head = glm::scale(head, glm::vec3(0.14f * s, 0.1f * s, 0.1f * s));
    drawObject(rockMesh, head, face);

    // Snout / muzzle (lighter, slightly protruding)
    glm::mat4 snout = glm::translate(base, glm::vec3(0.56f * s, 0.58f * s, 0));
    snout = glm::scale(snout, glm::vec3(0.06f * s, 0.055f * s, 0.065f * s));
    drawObject(rockMesh, snout, faceMid);

    // Nose (tiny pink sphere at tip)
    glm::mat4 nose = glm::translate(base, glm::vec3(0.6f * s, 0.57f * s, 0));
    nose = glm::scale(nose, glm::vec3(0.025f * s, 0.02f * s, 0.03f * s));
    drawObject(rockMesh, nose, noseCol);

    // Wool tuft on forehead (between ears)
    glm::mat4 forehead = glm::translate(base, glm::vec3(0.4f * s, 0.72f * s, 0));
    forehead = glm::scale(forehead, glm::vec3(0.08f * s, 0.06f * s, 0.08f * s));
    drawObject(rockMesh, forehead, wool1);

    // === EARS (drooping, angled outward) ===
    for (float side : {-1.0f, 1.0f}) {
        // Outer ear
        glm::mat4 ear = glm::translate(base, glm::vec3(0.42f * s, 0.68f * s, side * 0.1f * s));
        ear = glm::rotate(ear, glm::radians(side * 50.0f), glm::vec3(1, 0, 0));
        ear = glm::rotate(ear, glm::radians(-20.0f), glm::vec3(0, 0, 1));  // droop
        ear = glm::scale(ear, glm::vec3(0.04f * s, 0.015f * s, 0.06f * s));
        drawObject(rockMesh, ear, face);
        // Inner ear (pink/lighter)
        glm::mat4 earIn = glm::translate(base, glm::vec3(0.42f * s, 0.675f * s, side * 0.11f * s));
        earIn = glm::rotate(earIn, glm::radians(side * 50.0f), glm::vec3(1, 0, 0));
        earIn = glm::rotate(earIn, glm::radians(-20.0f), glm::vec3(0, 0, 1));
        earIn = glm::scale(earIn, glm::vec3(0.025f * s, 0.01f * s, 0.04f * s));
        drawObject(rockMesh, earIn, earInner);
    }

    // === EYES (tiny dark spheres) ===
    for (float side : {-1.0f, 1.0f}) {
        glm::mat4 eye = glm::translate(base, glm::vec3(0.5f * s, 0.64f * s, side * 0.06f * s));
        eye = glm::scale(eye, glm::vec3(0.012f * s, 0.012f * s, 0.012f * s));
        drawObject(rockMesh, eye, glm::vec3(0.02f, 0.02f, 0.02f));
    }

    // === LEGS (thin cylinders with hooves) ===
    float legH = 0.28f * s;
    float legThick = 0.03f * s;
    float frontX = 0.2f, backX = -0.22f;
    float legZ = 0.1f;
    for (auto& lx : { frontX, backX }) {
        for (float lz : {legZ, -legZ}) {
            // Upper leg
            glm::mat4 leg = glm::translate(base, glm::vec3(lx * s, legH * 0.55f, lz * s));
            leg = glm::scale(leg, glm::vec3(legThick * 5.5f, legH * 0.3f, legThick * 5.5f));
            drawObject(lampPost, leg, legCol);

            // Lower leg (slightly thinner)
            glm::mat4 lower = glm::translate(base, glm::vec3(lx * s, legH * 0.15f, lz * s));
            lower = glm::scale(lower, glm::vec3(legThick * 4.0f, legH * 0.17f, legThick * 4.0f));
            drawObject(lampPost, lower, legCol);

            // Hoof (tiny dark box at bottom)
            glm::mat4 hoof = glm::translate(base, glm::vec3(lx * s, 0.015f * s, lz * s));
            hoof = glm::scale(hoof, glm::vec3(legThick * 1.8f, 0.015f * s, legThick * 2.0f));
            drawObject(houseBody, hoof, hoofCol);
        }
    }

    // === TAIL (small fluffy wool tuft at rear) ===
    glm::mat4 tail = glm::translate(base, glm::vec3(-0.4f * s, 0.6f * s, 0));
    tail = glm::scale(tail, glm::vec3(0.06f * s, 0.05f * s, 0.05f * s));
    drawObject(rockMesh, tail, wool1);
    // Secondary tail tuft
    glm::mat4 tail2 = glm::translate(base, glm::vec3(-0.44f * s, 0.58f * s, 0));
    tail2 = glm::scale(tail2, glm::vec3(0.04f * s, 0.04f * s, 0.04f * s));
    drawObject(rockMesh, tail2, wool3);
}



// ============================================================
// Draw a wooden barrel
// ============================================================
void drawBarrel(glm::vec3 pos, float rotY = 0.0f) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    glm::vec3 wood(0.35f, 0.22f, 0.1f);       // warm brown
    glm::vec3 band(0.15f, 0.12f, 0.1f);       // dark metal
    glm::vec3 woodLight(0.4f, 0.28f, 0.12f);

    // Main barrel body (cylinder)
    glm::mat4 body = glm::translate(base, glm::vec3(0, 0, 0));
    body = glm::scale(body, glm::vec3(2.5f, 0.22f, 2.5f));
    drawObject(lampPost, body, wood);

    // Metal bands (3 dark rings at different heights)
    for (float h : {0.15f, 0.4f, 0.65f}) {
        glm::mat4 b = glm::translate(base, glm::vec3(0, h, 0));
        b = glm::scale(b, glm::vec3(0.22f, 0.025f, 0.22f));
        drawObject(houseBody, b, band);
    }

    // Lid (flat disc on top)
    glm::mat4 lid = glm::translate(base, glm::vec3(0, 0.78f, 0));
    lid = glm::scale(lid, glm::vec3(0.18f, 0.02f, 0.18f));
    drawObject(houseBody, lid, woodLight);
}

// ============================================================
// Draw a rectangular hay bale (stackable)
// ============================================================
void drawHayBaleRect(glm::vec3 pos, float rotY = 0.0f, float scaleX = 1.0f, float scaleY = 1.0f, float scaleZ = 1.0f) {
    glm::mat4 base = glm::translate(glm::mat4(1.0f), pos);
    base = glm::rotate(base, glm::radians(rotY), glm::vec3(0, 1, 0));

    glm::vec3 hay(0.58f, 0.48f, 0.2f);        // golden straw
    glm::vec3 hayDark(0.48f, 0.4f, 0.16f);    // darker straw
    glm::vec3 twine(0.25f, 0.2f, 0.1f);       // binding

    float bw = 1.2f * scaleX, bh = 0.8f * scaleY, bd = 0.9f * scaleZ;

    // Main bale body
    glm::mat4 body = glm::translate(base, glm::vec3(0, bh / 2, 0));
    body = glm::scale(body, glm::vec3(bw / 4.0f, bh / 3.0f, bd / 3.5f));
    drawObject(houseBody, body, hay);

    // Straw texture lines (horizontal bands on front)
    for (float ly : {bh * 0.25f, bh * 0.5f, bh * 0.75f}) {
        glm::mat4 line = glm::translate(base, glm::vec3(0, ly, bd / 2 + 0.01f));
        line = glm::scale(line, glm::vec3(bw / 2, 0.01f, 0.005f));
        drawObject(houseBody, line, hayDark);
    }

    // Twine bands (two vertical straps)
    for (float tx : {-bw * 0.25f, bw * 0.25f}) {
        glm::mat4 tw = glm::translate(base, glm::vec3(tx, bh / 2, bd / 2 + 0.015f));
        tw = glm::scale(tw, glm::vec3(0.015f, bh / 2, 0.008f));
        drawObject(houseBody, tw, twine);
    }
}

// ============================================================
// Draw the complete windmill farm scene
// ============================================================
void drawWindmillFarmScene(glm::vec3 pos) {
    // === RAISED PLATFORM (slightly elevated green ground) ===
    glm::mat4 platform = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 0.12f, 0));
    platform = glm::scale(platform, glm::vec3(0.2f, 1.0f, 0.18f));
    drawObject(groundMesh, platform, glm::vec3(0.14f, 0.24f, 0.1f), false, 1.0f, false, false, texGrass);

    // Darker edge trim (thin border around the platform)
    glm::mat4 edge = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 0.06f, 0));
    edge = glm::scale(edge, glm::vec3(0.205f, 1.0f, 0.185f));
    drawObject(groundMesh, edge, glm::vec3(0.1f, 0.18f, 0.08f), false, 1.0f, false, false, texGrass);

    // === WINDMILL (right side, prominent) ===
    drawWindmill(pos + glm::vec3(8.0f, 0.12f, -4.0f), -15);

    // === COBBLESTONE PATH (center, leading to windmill) ===
    glm::mat4 path1 = glm::translate(glm::mat4(1.0f), pos + glm::vec3(0, 0.14f, 2.0f));
    path1 = glm::rotate(path1, glm::radians(30.0f), glm::vec3(0, 1, 0));
    path1 = glm::scale(path1, glm::vec3(0.35f, 1.0f, 1.0f));
    drawObject(sideRoad1, path1, glm::vec3(0.32f, 0.3f, 0.26f), false, 1.0f, false, false, texRoad);

    // Second path segment to windmill
    glm::mat4 path2 = glm::translate(glm::mat4(1.0f), pos + glm::vec3(5.0f, 0.14f, -1.0f));
    path2 = glm::rotate(path2, glm::radians(50.0f), glm::vec3(0, 1, 0));
    path2 = glm::scale(path2, glm::vec3(0.25f, 1.0f, 0.8f));
    drawObject(sideRoad1, path2, glm::vec3(0.3f, 0.28f, 0.24f), false, 1.0f, false, false, texRoad);

    // === STACKED RECTANGULAR HAY BALES (left area, pyramid) ===
    // Bottom row (3x2 grid)
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 2; j++) {
            drawHayBaleRect(pos + glm::vec3(-10.0f + i * 1.4f, 0.12f, -3.0f + j * 1.1f),
                5.0f * (i - 1), 1.0f, 1.0f, 1.0f);
        }
    }
    // Middle row (2x2)
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            drawHayBaleRect(pos + glm::vec3(-9.3f + i * 1.4f, 0.92f, -2.8f + j * 1.1f),
                -3.0f * i, 1.0f, 1.0f, 1.0f);
        }
    }
    // Top row (2x1)
    drawHayBaleRect(pos + glm::vec3(-9.6f, 1.72f, -2.5f), 8.0f, 1.0f, 1.0f, 1.0f);
    drawHayBaleRect(pos + glm::vec3(-8.2f, 1.72f, -2.5f), -5.0f, 1.0f, 1.0f, 1.0f);

    // Second smaller hay stack (further left)
    drawHayBaleRect(pos + glm::vec3(-12.0f, 0.12f, -1.0f), 20.0f);
    drawHayBaleRect(pos + glm::vec3(-12.8f, 0.12f, -0.5f), -10.0f);
    drawHayBaleRect(pos + glm::vec3(-12.4f, 0.92f, -0.7f), 5.0f);

    // === SHEEP (scattered on the grass) ===
    drawSheep(pos + glm::vec3(-6.0f, 0.12f, 5.0f), 45.0f, 1.0f);
    drawSheep(pos + glm::vec3(-4.5f, 0.12f, 6.5f), -30.0f, 0.9f);
    drawSheep(pos + glm::vec3(-7.5f, 0.12f, 6.0f), 120.0f, 1.1f);
    drawSheep(pos + glm::vec3(-3.0f, 0.12f, 4.5f), 200.0f, 0.85f);
    drawSheep(pos + glm::vec3(-8.5f, 0.12f, 3.5f), -60.0f, 0.95f);
    drawSheep(pos + glm::vec3(-5.5f, 0.12f, 7.5f), 80.0f, 0.9f);
    drawSheep(pos + glm::vec3(-10.0f, 0.12f, 5.5f), 150.0f, 1.05f);


    // === BARRELS (near the windmill) ===
    drawBarrel(pos + glm::vec3(5.5f, 0.12f, -2.0f), 15.0f);
    drawBarrel(pos + glm::vec3(6.2f, 0.12f, -1.2f), -30.0f);
    drawBarrel(pos + glm::vec3(5.0f, 0.12f, -0.5f), 45.0f);

    // === BENCHES (front area, facing the scene) ===
    drawBench(pos + glm::vec3(-2.0f, 0.12f, 8.5f), 0);
    drawBench(pos + glm::vec3(3.0f, 0.12f, 8.5f), 0);

    // === LAMP POSTS (along the path, warm glow) ===
    drawLampPost(pos + glm::vec3(-1.5f, 0.12f, 3.0f));
    drawLampPost(pos + glm::vec3(3.0f, 0.12f, 0.5f));
    drawLampPost(pos + glm::vec3(6.0f, 0.12f, 5.0f));

    // === TREES (around the perimeter) ===
    glm::vec3 farmGreen(0.1f, 0.28f, 0.08f);
    glm::vec3 farmDarkGreen(0.08f, 0.22f, 0.07f);
    glm::vec3 farmLightGreen(0.14f, 0.32f, 0.1f);

    // Back row of trees
    drawTree(pos + glm::vec3(-12.0f, 0.12f, -10.0f), 1.2f, farmDarkGreen);
    drawTree(pos + glm::vec3(-8.0f, 0.12f, -11.0f), 1.0f, farmGreen);
    drawTree(pos + glm::vec3(-4.0f, 0.12f, -10.5f), 1.3f, farmDarkGreen);
    drawTree(pos + glm::vec3(0, 0.12f, -11.0f), 1.1f, farmLightGreen);
    drawTree(pos + glm::vec3(4.0f, 0.12f, -10.0f), 0.9f, farmGreen);

    // Right side trees
    drawTree(pos + glm::vec3(16.0f, 0.12f, -2.0f), 1.2f, farmGreen);
    drawTree(pos + glm::vec3(15.0f, 0.12f, 3.0f), 1.0f, farmDarkGreen);
    drawTree(pos + glm::vec3(16.5f, 0.12f, 7.0f), 1.1f, farmLightGreen);

    drawTree(pos + glm::vec3(16.0f, 0.12f, -9.0f), 1.2f, farmGreen);
   
    drawTree(pos + glm::vec3(16.5f, 0.12f, 12.0f), 1.1f, farmLightGreen);

    // Left side trees
    drawTree(pos + glm::vec3(-14.0f, 0.12f, 0), 1.3f, farmGreen);
    drawTree(pos + glm::vec3(-14.5f, 0.12f, 5.0f), 1.0f, farmDarkGreen);

    // Front trees (flanking benches)
    drawTree(pos + glm::vec3(-9.0f, 0.12f, 14.5f), 0.85f, farmLightGreen);
    drawTree(pos + glm::vec3(13.0f, 0.12f, 14.5f), 0.95f, farmGreen);

    // === STONE WALL / WATER CHANNEL at windmill base ===
    glm::vec3 stoneGrey(0.35f, 0.33f, 0.3f);
    // Small stone wall beside the windmill
    glm::mat4 wall = glm::translate(glm::mat4(1.0f), pos + glm::vec3(10.5f, 0.35f, -3.0f));
    wall = glm::scale(wall, glm::vec3(0.3f, 0.2f, 1.2f));
    drawObject(houseBody, wall, stoneGrey);

    // Water trough
    glm::mat4 trough = glm::translate(glm::mat4(1.0f), pos + glm::vec3(10.5f, 0.18f, 0.5f));
    trough = glm::scale(trough, glm::vec3(0.3f, 0.04f, 0.5f));
    drawObject(houseBody, trough, glm::vec3(0.08f, 0.15f, 0.2f));

    // === ROCKS scattered around ===
    drawRocks(pos + glm::vec3(10.0f, 0.12f, -7.0f), 0.5f);
    drawRocks(pos + glm::vec3(-13.0f, 0.12f, -5.0f), 0.4f);
    drawRocks(pos + glm::vec3(4.0f, 0.12f, -5.5f), 0.35f);
}

// ============================================================
// Clouds - fluffy cumulus clouds from overlapping sphere puffs
// ============================================================
void drawCloud(glm::vec3 pos, float scale, float seed) {
    // Each cloud is a cluster of overlapping spheres with different scales
    struct Puff { float dx, dy, dz, sx, sy, sz; };
    Puff puffs[] = {
        {  0.0f,  0.0f,  0.0f,  2.2f, 1.3f, 1.6f },
        {  1.8f,  0.3f,  0.2f,  1.9f, 1.1f, 1.4f },
        { -1.5f,  0.2f, -0.1f,  1.7f, 1.2f, 1.5f },
        {  0.9f, -0.1f,  0.6f,  1.5f, 1.0f, 1.3f },
        { -0.6f,  0.5f, -0.4f,  1.4f, 1.1f, 1.2f },
        {  2.8f,  0.1f,  0.1f,  1.3f, 0.9f, 1.1f },
        { -2.5f,  0.0f,  0.3f,  1.2f, 1.0f, 1.3f },
        {  3.5f, -0.2f, -0.2f,  1.0f, 0.7f, 0.9f },
        { -3.2f,  0.1f,  0.1f,  0.9f, 0.8f, 1.0f },
    };
    int numPuffs = 9;

    // Cloud colour: bright white in day, dim blue-grey at night
    glm::vec3 cloudColor = isNightScene
        ? glm::vec3(0.12f, 0.15f, 0.22f)
        : glm::vec3(0.95f, 0.96f, 0.98f);
    float emStr = isNightScene ? 0.3f : 0.85f;

    // Vary puff arrangement slightly per cloud using seed
    for (int i = 0; i < numPuffs; i++) {
        float offsetVariation = sin(seed * 3.7f + i * 1.3f) * 0.3f;
        glm::vec3 puffPos = pos + glm::vec3(
            (puffs[i].dx + offsetVariation) * scale,
            (puffs[i].dy + offsetVariation * 0.2f) * scale,
            (puffs[i].dz + offsetVariation * 0.5f) * scale
        );
        glm::mat4 m = glm::translate(glm::mat4(1.0f), puffPos);
        m = glm::scale(m, glm::vec3(puffs[i].sx, puffs[i].sy, puffs[i].sz) * scale);
        drawObject(cloudPuff, m, cloudColor, true, emStr);
    }
}

void drawClouds() {
    // Cloud positions: world XZ with high Y, slowly drifting
    struct CloudDef { float x, y, z, scale, seed, speedMult; };
    CloudDef clouds[] = {
        {   0.0f, 45.0f,  -20.0f, 3.5f, 1.0f, 1.0f },
        {  25.0f, 50.0f,  -35.0f, 4.0f, 2.3f, 0.7f },
        { -30.0f, 42.0f,  -10.0f, 3.0f, 3.7f, 1.2f },
        {  40.0f, 48.0f,   10.0f, 3.8f, 4.1f, 0.8f },
        { -15.0f, 55.0f,  -45.0f, 4.5f, 5.5f, 0.6f },
        {  55.0f, 44.0f,  -25.0f, 3.2f, 6.2f, 1.1f },
        { -40.0f, 52.0f,   15.0f, 3.6f, 7.8f, 0.9f },
        {  15.0f, 47.0f,   25.0f, 2.8f, 8.4f, 1.3f },
        { -50.0f, 46.0f,  -30.0f, 4.2f, 9.1f, 0.5f },
        {  35.0f, 53.0f,  -50.0f, 3.4f, 10.0f, 0.75f },
        { -20.0f, 49.0f,   30.0f, 3.0f, 11.3f, 1.0f },
        {  60.0f, 51.0f,    0.0f, 3.7f, 12.6f, 0.85f },
    };
    int numClouds = 12;

    float driftSpeed = 1.5f; // base drift speed in units/sec
    float driftRange = 200.0f; // wrap range

    for (int i = 0; i < numClouds; i++) {
        // Drift along X axis slowly
        float driftX = fmod(clouds[i].x + globalTime * driftSpeed * clouds[i].speedMult, driftRange);
        if (driftX > driftRange / 2.0f) driftX -= driftRange;
        // Subtle bob up and down
        float bobY = sin(globalTime * 0.3f + clouds[i].seed * 2.0f) * 0.8f;
        glm::vec3 cloudPos(driftX, clouds[i].y + bobY, clouds[i].z);
        drawCloud(cloudPos, clouds[i].scale, clouds[i].seed);
    }
}

// ============================================================
// Input handling
// ============================================================
void processInput(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    float velocity = moveSpeed * deltaTime;
    glm::vec3 front = glm::normalize(glm::vec3(cameraFront.x, 0, cameraFront.z));
    glm::vec3 right = glm::normalize(glm::cross(front, cameraUp));

    glm::vec3 newPos = cameraPos;

    // WASD movement along roads
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        newPos += front * velocity;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        newPos -= front * velocity;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        newPos -= right * velocity;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        newPos += right * velocity;

    // Q/E for strafing
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        newPos -= right * velocity;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        newPos += right * velocity;

    // Space/Shift for up/down
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
        newPos.y += velocity;
    if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
        newPos.y -= velocity;

    // Collision detection: try full move, then try axis-separated sliding
    if (!checkCollision(newPos)) {
        cameraPos = newPos;
    }
    else {
        // Try sliding along each axis independently
        glm::vec3 slideX = glm::vec3(newPos.x, cameraPos.y, cameraPos.z);
        glm::vec3 slideZ = glm::vec3(cameraPos.x, cameraPos.y, newPos.z);
        glm::vec3 slideY = glm::vec3(cameraPos.x, newPos.y, cameraPos.z);
        if (!checkCollision(slideX)) cameraPos.x = newPos.x;
        if (!checkCollision(slideZ)) cameraPos.z = newPos.z;
        if (!checkCollision(slideY)) cameraPos.y = newPos.y;
    }

    // Keep camera above ground
    if (cameraPos.y < 1.5f) cameraPos.y = 1.5f;

    // Arrow keys for looking around
    float rotSpeed = sensitivity * deltaTime;
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        yaw -= rotSpeed;
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        yaw += rotSpeed;
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
        pitch += rotSpeed;
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
        pitch -= rotSpeed;

    // Clamp pitch
    if (pitch > 89.0f) pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;

    // Update camera front
    glm::vec3 dir;
    dir.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    dir.y = sin(glm::radians(pitch));
    dir.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(dir);

    // Fog controls
    if (glfwGetKey(window, GLFW_KEY_EQUAL) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_KP_ADD) == GLFW_PRESS)
        fogDensity += 0.001f;
    if (glfwGetKey(window, GLFW_KEY_MINUS) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_KP_SUBTRACT) == GLFW_PRESS)
        fogDensity = std::max(0.0f, fogDensity - 0.001f);

    // Speed controls
    if (glfwGetKey(window, GLFW_KEY_LEFT_BRACKET) == GLFW_PRESS)
        moveSpeed = std::max(1.0f, moveSpeed - 0.1f);
    if (glfwGetKey(window, GLFW_KEY_RIGHT_BRACKET) == GLFW_PRESS)
        moveSpeed = std::min(20.0f, moveSpeed + 0.1f);

    // Zoom controls (Z = zoom in, X = zoom out)
    if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS)
        fov = std::max(15.0f, fov - 30.0f * deltaTime);
    if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS)
        fov = std::min(110.0f, fov + 30.0f * deltaTime);
}

void scrollCallback(GLFWwindow* window, double xoffset, double yoffset) {
    fov -= (float)yoffset * 3.0f;
    if (fov < 15.0f) fov = 15.0f;
    if (fov > 110.0f) fov = 110.0f;
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (action == GLFW_PRESS) {
        if (key == GLFW_KEY_F)
            flashlightOn = !flashlightOn;
        // Reset position and zoom
        if (key == GLFW_KEY_R) {
            cameraPos = glm::vec3(0.0f, 2.0f, 15.0f);
            yaw = -90.0f;
            pitch = -5.0f;
            fov = 60.0f;
        }
        // Toggle nearest door with G key
        if (key == GLFW_KEY_G) {
            float closestDist = 999.0f;
            int closestDoor = -1;
            for (int i = 0; i < (int)doors.size(); i++) {
                float dist = glm::length(cameraPos - doors[i].doorWorldPos);
                if (dist < closestDist) {
                    closestDist = dist;
                    closestDoor = i;
                }
            }
            if (closestDoor >= 0 && closestDist < 4.0f) {
                doors[closestDoor].isOpen = !doors[closestDoor].isOpen;
                if (doors[closestDoor].isOpen)
                    std::cout << "Door opened! (House " << closestDoor << ")" << std::endl;
                else
                    std::cout << "Door closed! (House " << closestDoor << ")" << std::endl;
            }
        }
        // Toggle day/night with N key
        if (key == GLFW_KEY_N) {
            isNightScene = !isNightScene;
            if (isNightScene)
                std::cout << "Switched to NIGHT scene" << std::endl;
            else
                std::cout << "Switched to DAY scene" << std::endl;
        }
    }
}

void framebufferSizeCallback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

// ============================================================
// MAIN
// ============================================================
int main() {
    // Initialize GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_SAMPLES, 4);

    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT,
        "European Countryside - Night Scene [WASD:Move | Arrows:Look | Space/Shift:Up/Down | +/-:Fog | F:Flashlight | R:Reset]",
        NULL, NULL);
    if (!window) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebufferSizeCallback);
    glfwSetKeyCallback(window, keyCallback);
    glfwSetScrollCallback(window, scrollCallback);

    // Initialize GLEW
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) {
        std::cerr << "Failed to initialize GLEW" << std::endl;
        return -1;
    }

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Load shaders
    shaderProgram = createShaderProgram("shader.vs", "shader.fs");

    // ============================================================
    // Create all meshes
    // ============================================================
    houseBody = createBox(4.0f, 3.0f, 3.5f, glm::vec3(0.75f, 0.7f, 0.6f));
    houseRoof = createRoof(5.0f, 2.0f, 4.0f, glm::vec3(0.35f, 0.2f, 0.1f));
    windowMesh = createBox(0.6f, 0.6f, 0.05f, glm::vec3(1.0f, 0.85f, 0.4f));

    // Ground
    groundMesh = createGround(200.0f, glm::vec3(0.15f, 0.25f, 0.1f));
    waterMesh = createGround(200.0f, glm::vec3(0.05f, 0.12f, 0.15f));

    // Castle parts
    castleTower = createCylinder(1.5f, 6.0f, 16, glm::vec3(0.4f, 0.4f, 0.42f));
    castleTowerRoof = createCone(2.0f, 3.0f, 16, glm::vec3(0.3f, 0.15f, 0.15f));

    // Bridge (drawn procedurally, no mesh needed)

    // Well
    wellBase = createCylinder(0.8f, 1.0f, 12, glm::vec3(0.45f, 0.45f, 0.5f));

    // Trees - trunk, branches, and leaf clusters
    treeTrunk = createCylinder(0.35f, 3.5f, 10, glm::vec3(0.2f, 0.13f, 0.06f));
    treeBranch = createCylinder(0.12f, 2.5f, 6, glm::vec3(0.2f, 0.13f, 0.06f));
    leafClusterBig = createLeafCluster(1.0f, 120, glm::vec3(0.18f, 0.4f, 0.12f));
    leafClusterMed = createLeafCluster(0.75f, 80, glm::vec3(0.15f, 0.38f, 0.1f));
    leafClusterSmall = createLeafCluster(0.55f, 50, glm::vec3(0.2f, 0.42f, 0.14f));
    // Pine needle clusters
    needleClusterBig = createNeedleCluster(1.0f, 180, glm::vec3(0.06f, 0.2f, 0.06f));
    needleClusterMed = createNeedleCluster(0.75f, 120, glm::vec3(0.07f, 0.22f, 0.07f));
    needleClusterSmall = createNeedleCluster(0.55f, 80, glm::vec3(0.05f, 0.18f, 0.05f));

    // Lamp post
    lampPost = createCylinder(0.06f, 3.5f, 8, glm::vec3(0.1f, 0.1f, 0.12f));

    // Moon
    moonMesh = createSphere(3.0f, 16, 24, glm::vec3(0.95f, 0.95f, 0.85f));

    // Star
    starMesh = createSphere(0.15f, 4, 6, glm::vec3(1.0f, 1.0f, 0.9f));

    // Cloud puff (unit sphere, will be stretched per-puff)
    cloudPuff = createSphere(1.0f, 10, 14, glm::vec3(1.0f, 1.0f, 1.0f));

    // Rock
    rockMesh = createSphere(1.0f, 6, 8, glm::vec3(0.4f, 0.4f, 0.42f));

    // Roads
    mainRoad = createRoad(80.0f, 5.0f, glm::vec3(0.35f, 0.33f, 0.3f));
    sideRoad1 = createRoad(40.0f, 4.0f, glm::vec3(0.33f, 0.31f, 0.28f));
    squareGround = createGround(20.0f, glm::vec3(0.35f, 0.33f, 0.3f));

    // Load textures
    texGrass = loadTexture("textures/green-grass-texture-close-up.jpg");
    texRoad = loadTexture("textures/natural-stone-paviment.jpg");
    texBridge = loadTexture("textures/abstract-surface-stone-textures.jpg");
    texBrick = loadTexture("textures/brick-wall-background-texture.jpg");
    texRoof = loadTexture("textures/roof.jpg");
    texBark = loadTexture("textures/tree-surface-texture-darwin-australia-march-06-2024.jpg");

    // Farmstead meshes (most geometry reuses existing primitives)

    // ============================================================
    // Register obstacle bounding boxes for collision detection
    // ============================================================
    obstacles.clear();

    // --- Cottage Houses ---
    // drawCottageHouse(glm::vec3(-14.0f, 0, -5.0f), 90, 1.0f)  bodyW=3.8 bodyH=2.8 bodyD=3.2
    addObstacle(glm::vec3(-14.0f, 1.4f, -5.0f), glm::vec3(1.6f, 2.8f, 1.9f));
    // drawCottageHouse(glm::vec3(-22.0f, 0, -5.0f), -90, 1.05f)
    addObstacle(glm::vec3(-22.0f, 1.4f, -5.0f), glm::vec3(1.7f, 2.9f, 2.0f));
    // drawCottageHouse(glm::vec3(4.5f, 0, -5.0f), -5, 1.0f)
    addObstacle(glm::vec3(4.5f, 1.4f, -5.0f), glm::vec3(1.9f, 2.8f, 1.6f));
    // drawCottageHouse(glm::vec3(-4.5f, 0, 2.0f), 180, 0.95f)
    addObstacle(glm::vec3(-4.5f, 1.4f, 2.0f), glm::vec3(1.8f, 2.7f, 1.5f));

    // --- Church ---
    addObstacle(glm::vec3(-18.0f, 2.5f, 8.0f), glm::vec3(3.0f, 5.0f, 2.5f));

    // --- Well ---
    addObstacle(glm::vec3(-18.0f, 0.5f, -5.0f), glm::vec3(0.9f, 1.2f, 0.9f));

    // --- Hay cart ---
    addObstacle(glm::vec3(-18.0f, 0.5f, -3.0f), glm::vec3(1.0f, 1.0f, 0.6f));

    // --- Benches ---
    addObstacle(glm::vec3(-16.0f, 0.3f, -7.5f), glm::vec3(0.8f, 0.5f, 0.4f));
    addObstacle(glm::vec3(-20.0f, 0.3f, -7.5f), glm::vec3(0.8f, 0.5f, 0.4f));
    addObstacle(glm::vec3(-32.0f, 0.3f, 7.0f), glm::vec3(0.8f, 0.5f, 0.4f));
    addObstacle(glm::vec3(-32.0f, 0.3f, 13.0f), glm::vec3(0.8f, 0.5f, 0.4f));
    addObstacle(glm::vec3(-33.0f, 0.3f, 10.0f), glm::vec3(0.4f, 0.5f, 0.8f));

    // --- Hay bales ---
    addObstacle(glm::vec3(-23.0f, 0.4f, 6.0f), glm::vec3(0.6f, 0.5f, 0.6f));
    addObstacle(glm::vec3(-24.0f, 0.4f, 7.5f), glm::vec3(0.6f, 0.5f, 0.6f));
    addObstacle(glm::vec3(-12.0f, 0.4f, 10.0f), glm::vec3(0.6f, 0.5f, 0.6f));

    // --- Trees helper lambda (needed for windmill and farmstead sub-sections) ---
    auto addTreeObstacle = [](glm::vec3 pos, float scale) {
        addObstacle(glm::vec3(pos.x, 1.5f * scale, pos.z), glm::vec3(0.5f * scale, 2.0f * scale, 0.5f * scale));
        };

    // --- Windmill Farm Scene --- pos = (-15, 0, -40)
    {
        glm::vec3 wfp(-15.0f, 0.0f, -40.0f); // windmill farm scene base position

        // Windmill tower: drawWindmill at pos+(8, 0.12, -4), tower 3.2x8.5x3.2
        addObstacle(wfp + glm::vec3(8.0f, 4.25f, -4.0f), glm::vec3(2.0f, 5.5f, 2.0f));

        // Hay bale pyramid (left area) � bottom row covers pos+(-11.4..-7.2, 0, -3..-1.9)
        addObstacle(wfp + glm::vec3(-9.3f, 1.0f, -2.5f), glm::vec3(2.5f, 1.5f, 1.2f));
        // Second smaller hay stack (further left)
        addObstacle(wfp + glm::vec3(-12.4f, 0.6f, -0.7f), glm::vec3(1.0f, 1.0f, 0.7f));

        // Barrels (near windmill)
        addObstacle(wfp + glm::vec3(5.5f, 0.5f, -1.5f), glm::vec3(1.0f, 0.6f, 1.0f));

        // Stone wall beside windmill
        addObstacle(wfp + glm::vec3(10.5f, 0.35f, -3.0f), glm::vec3(1.2f, 0.6f, 4.2f));

        // Water trough
        addObstacle(wfp + glm::vec3(10.5f, 0.18f, 0.5f), glm::vec3(1.2f, 0.3f, 1.75f));

        // Benches in windmill scene
        addObstacle(wfp + glm::vec3(-2.0f, 0.3f, 8.5f), glm::vec3(0.8f, 0.5f, 0.4f));
        addObstacle(wfp + glm::vec3(3.0f, 0.3f, 8.5f), glm::vec3(0.8f, 0.5f, 0.4f));

        // Lamp posts in windmill scene
        addObstacle(wfp + glm::vec3(-1.5f, 1.75f, 3.0f), glm::vec3(0.2f, 1.75f, 0.2f));
        addObstacle(wfp + glm::vec3(3.0f, 1.75f, 0.5f), glm::vec3(0.2f, 1.75f, 0.2f));
        addObstacle(wfp + glm::vec3(6.0f, 1.75f, 5.0f), glm::vec3(0.2f, 1.75f, 0.2f));

        // Cows (larger animals)
        addObstacle(wfp + glm::vec3(-8.0f, 0.5f, 7.5f), glm::vec3(0.7f, 0.7f, 0.5f));
        addObstacle(wfp + glm::vec3(-3.5f, 0.5f, 8.0f), glm::vec3(0.7f, 0.7f, 0.5f));
        addObstacle(wfp + glm::vec3(-11.0f, 0.5f, 4.0f), glm::vec3(0.7f, 0.7f, 0.5f));

        // Trees in windmill farm scene � back row
        addTreeObstacle(wfp + glm::vec3(-12.0f, 0, -6.0f), 1.2f);
        addTreeObstacle(wfp + glm::vec3(-8.0f, 0, -7.0f), 1.0f);
        addTreeObstacle(wfp + glm::vec3(-4.0f, 0, -6.5f), 1.3f);
        addTreeObstacle(wfp + glm::vec3(0, 0, -7.0f), 1.1f);
        addTreeObstacle(wfp + glm::vec3(4.0f, 0, -6.0f), 0.9f);
        // Right side trees
        addTreeObstacle(wfp + glm::vec3(12.0f, 0, -2.0f), 1.2f);
        addTreeObstacle(wfp + glm::vec3(13.0f, 0, 3.0f), 1.0f);
        addTreeObstacle(wfp + glm::vec3(12.5f, 0, 7.0f), 1.1f);
        // Left side trees
        addTreeObstacle(wfp + glm::vec3(-14.0f, 0, 0), 1.3f);
        addTreeObstacle(wfp + glm::vec3(-14.5f, 0, 5.0f), 1.0f);
        // Front trees
        addTreeObstacle(wfp + glm::vec3(-6.0f, 0, 9.5f), 0.85f);
        addTreeObstacle(wfp + glm::vec3(7.0f, 0, 9.5f), 0.95f);

        // Rocks
        addObstacle(wfp + glm::vec3(10.0f, 0.2f, -7.0f), glm::vec3(0.5f, 0.3f, 0.5f));
        addObstacle(wfp + glm::vec3(-13.0f, 0.2f, -5.0f), glm::vec3(0.4f, 0.3f, 0.4f));
    }

    // --- Trees along roads ---
    addTreeObstacle(glm::vec3(-6.0f, 0, -8.0f), 1.0f);
    addTreeObstacle(glm::vec3(-6.0f, 0, 1.0f), 1.2f);
    addTreeObstacle(glm::vec3(-6.5f, 0, 8.0f), 0.9f);
    addTreeObstacle(glm::vec3(7.0f, 0, 1.0f), 1.1f);
    addTreeObstacle(glm::vec3(7.5f, 0, 7.0f), 0.8f);
    addTreeObstacle(glm::vec3(6.0f, 0, -4.0f), 1.0f);
    // Trees near windmill
    addTreeObstacle(glm::vec3(-8.0f, 0, -35.0f), 1.3f);
    addTreeObstacle(glm::vec3(-22.0f, 0, -35.0f), 1.1f);
    addTreeObstacle(glm::vec3(-10.0f, 0, -30.0f), 1.0f);
    addTreeObstacle(glm::vec3(-20.0f, 0, -30.0f), 1.2f);
    // Park area trees
    for (int i = 0; i < 6; i++) {
        addTreeObstacle(glm::vec3(-28.0f, 0, 3.0f + i * 3.0f), 1.3f);
        addTreeObstacle(glm::vec3(-37.0f, 0, 3.0f + i * 3.0f), 1.3f);
    }
    for (int i = 0; i < 5; i++) {
        addTreeObstacle(glm::vec3(-26.0f, 0, 4.5f + i * 3.0f), 1.0f);
        addTreeObstacle(glm::vec3(-39.0f, 0, 4.5f + i * 3.0f), 1.0f);
    }
    // Scattered trees
    addTreeObstacle(glm::vec3(15.0f, 0, -15.0f), 1.2f);
    addTreeObstacle(glm::vec3(-25.0f, 0, -15.0f), 1.4f);
    addTreeObstacle(glm::vec3(10.0f, 0, 15.0f), 1.0f);
    addTreeObstacle(glm::vec3(-10.0f, 0, 15.0f), 1.1f);
    // River trees
    addTreeObstacle(glm::vec3(31.0f, 0, -10.0f), 1.1f);
    addTreeObstacle(glm::vec3(39.0f, 0, -7.0f), 0.9f);
    addTreeObstacle(glm::vec3(31.0f, 0, 7.0f), 1.0f);
    addTreeObstacle(glm::vec3(39.5f, 0, 10.0f), 1.2f);
    addTreeObstacle(glm::vec3(30.5f, 0, -20.0f), 1.0f);
    addTreeObstacle(glm::vec3(39.5f, 0, -18.0f), 0.85f);
    addTreeObstacle(glm::vec3(31.0f, 0, 18.0f), 0.95f);
    addTreeObstacle(glm::vec3(39.0f, 0, 20.0f), 1.1f);
    addTreeObstacle(glm::vec3(15.0f, 0, 3.0f), 0.9f);
    addTreeObstacle(glm::vec3(21.0f, 0, -3.0f), 1.0f);
    addTreeObstacle(glm::vec3(27.0f, 0, 3.0f), 0.85f);

    // --- Conifer trees around church ---
    addTreeObstacle(glm::vec3(-12.0f, 0, 12.0f), 1.0f);
    addTreeObstacle(glm::vec3(-24.0f, 0, 12.0f), 1.2f);
    addTreeObstacle(glm::vec3(-14.0f, 0, 15.0f), 0.9f);
    addTreeObstacle(glm::vec3(-22.0f, 0, 15.0f), 1.1f);
    addTreeObstacle(glm::vec3(-10.0f, 0, 8.0f), 0.85f);
    addTreeObstacle(glm::vec3(-26.0f, 0, 9.0f), 1.0f);
    addTreeObstacle(glm::vec3(-18.0f, 0, 18.0f), 1.3f);
    addTreeObstacle(glm::vec3(-15.0f, 0, 20.0f), 0.95f);

    // --- Lamp posts (thin but tall) ---
    auto addLampObstacle = [](glm::vec3 pos) {
        addObstacle(glm::vec3(pos.x, 1.75f, pos.z), glm::vec3(0.2f, 1.75f, 0.2f));
        };
    addLampObstacle(glm::vec3(30.0f, 0, 3.5f));
    addLampObstacle(glm::vec3(30.0f, 0, -3.5f));
    addLampObstacle(glm::vec3(40.0f, 0, 3.5f));
    addLampObstacle(glm::vec3(40.0f, 0, -3.5f));
    addLampObstacle(glm::vec3(2.5f, 0, -3.0f));
    addLampObstacle(glm::vec3(2.5f, 0, 6.0f));
    addLampObstacle(glm::vec3(-2.5f, 0, 0.0f));
    addLampObstacle(glm::vec3(-18.0f, 0, -1.0f));
    addLampObstacle(glm::vec3(-15.0f, 0, 6.0f));
    addLampObstacle(glm::vec3(-30.0f, 0, 5.0f));
    addLampObstacle(glm::vec3(-35.0f, 0, 5.0f));
    addLampObstacle(glm::vec3(-30.0f, 0, 12.0f));
    addLampObstacle(glm::vec3(-35.0f, 0, 12.0f));

    // --- Farmstead at (55, 0, -20) --- detailed sub-objects
    {
        glm::vec3 fp(55.0f, 0.0f, -20.0f); // farmstead base position
        // Barn at pos+(0, 0, -3)
        addObstacle(fp + glm::vec3(0.0f, 2.5f, -3.0f), glm::vec3(3.5f, 3.5f, 2.5f));
        // Silo at pos+(5, 0, -4)
        addObstacle(fp + glm::vec3(5.0f, 3.0f, -4.0f), glm::vec3(1.2f, 4.0f, 1.2f));
        // Farmhouse at pos+(10, 0, 2)
        addObstacle(fp + glm::vec3(10.0f, 1.8f, 2.0f), glm::vec3(2.5f, 2.5f, 2.0f));
        // Shed at pos+(-5, 0, -6)
        addObstacle(fp + glm::vec3(-5.0f, 1.2f, -6.0f), glm::vec3(1.5f, 1.5f, 1.5f));
        // Hay cart at pos+(-3, 0, 2)
        addObstacle(fp + glm::vec3(-3.0f, 0.6f, 2.0f), glm::vec3(1.0f, 1.0f, 0.6f));
        // Yard lamp post
        addObstacle(fp + glm::vec3(3.0f, 1.75f, 2.0f), glm::vec3(0.2f, 1.75f, 0.2f));
        // Farmstead trees
        addTreeObstacle(fp + glm::vec3(-14.0f, 0, -2.0f), 1.2f);
        addTreeObstacle(fp + glm::vec3(-13.0f, 0, 8.0f), 1.0f);
        addTreeObstacle(fp + glm::vec3(15.0f, 0, -3.0f), 1.3f);
        addTreeObstacle(fp + glm::vec3(14.0f, 0, 10.0f), 0.9f);
        addTreeObstacle(fp + glm::vec3(0, 0, -12.0f), 1.1f);
        addTreeObstacle(fp + glm::vec3(8.0f, 0, -10.0f), 1.0f);
        // Farmstead rocks
        addObstacle(fp + glm::vec3(-3.0f, 0.2f, -8.0f), glm::vec3(0.5f, 0.3f, 0.5f));
        addObstacle(fp + glm::vec3(12.0f, 0.2f, -5.0f), glm::vec3(0.4f, 0.3f, 0.4f));
    }

    // --- Bridge walls (prevent walking off sides) ---
    // Bridge at x=35, z=0, width=5, length=12
    addObstacle(glm::vec3(35.0f, 1.0f, 3.0f), glm::vec3(6.0f, 1.5f, 0.4f));  // left wall
    addObstacle(glm::vec3(35.0f, 1.0f, -3.0f), glm::vec3(6.0f, 1.5f, 0.4f)); // right wall

    std::cout << "Registered " << obstacles.size() << " obstacle bounding boxes for collision detection." << std::endl;

    // ============================================================
    // Register interactive doors for all 4 cottage houses
    // ============================================================
    doors.clear();
    // Helper to compute door world position from house pos, rotation, and scale
    auto registerDoor = [](glm::vec3 housePos, float rotY, float scale, int obstIdx) {
        DoorInfo d;
        d.housePos = housePos;
        d.houseRotY = rotY;
        d.scale = scale;
        d.openAngle = 0.0f;
        d.isOpen = false;
        d.obstacleIndex = obstIdx;
        // Door is at local Z = hd + 0.01 = bodyD/2 + 0.01, with bodyD = 3.2*s
        float hd = 3.2f * scale / 2.0f;
        float fz = hd + 0.01f;
        // Transform local door position (0, 0.65*s, fz) to world
        float rad = glm::radians(rotY);
        d.doorWorldPos = housePos + glm::vec3(
            sin(rad) * fz,   // local Z -> world XZ via rotation
            0.65f * scale,    // door center height
            cos(rad) * fz
        );
        doors.push_back(d);
        };
    // Cottage House 0: (-14, 0, -5), rot=90, scale=1.0, obstacle index 0
    registerDoor(glm::vec3(-14.0f, 0, -5.0f), 90.0f, 1.0f, 0);
    // Cottage House 1: (-22, 0, -5), rot=-90, scale=1.05, obstacle index 1
    registerDoor(glm::vec3(-22.0f, 0, -5.0f), -90.0f, 1.05f, 1);
    // Cottage House 2: (4.5, 0, -5), rot=-5, scale=1.0, obstacle index 2
    registerDoor(glm::vec3(4.5f, 0, -5.0f), -5.0f, 1.0f, 2);
    // Cottage House 3: (-4.5, 0, 2), rot=180, scale=0.95, obstacle index 3
    registerDoor(glm::vec3(-4.5f, 0, 2.0f), 180.0f, 0.95f, 3);

    std::cout << "Registered " << doors.size() << " interactive doors." << std::endl;

    // Print controls
    std::cout << "========================================" << std::endl;
    std::cout << " European Countryside - Night Scene" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << " WASD       - Move forward/back/strafe" << std::endl;
    std::cout << " Arrow Keys - Look around" << std::endl;
    std::cout << " Space      - Go up" << std::endl;
    std::cout << " Shift      - Go down" << std::endl;
    std::cout << " Q/E        - Strafe left/right" << std::endl;
    std::cout << " +/-        - Adjust fog density" << std::endl;
    std::cout << " [ / ]      - Adjust move speed" << std::endl;
    std::cout << " F          - Toggle flashlight" << std::endl;
    std::cout << " G          - Open/Close nearest door" << std::endl;
    std::cout << " N          - Toggle Day / Night" << std::endl;
    std::cout << " Z / X      - Zoom in / out" << std::endl;
    std::cout << " Mouse Scroll - Zoom in / out" << std::endl;
    std::cout << " R          - Reset position & zoom" << std::endl;
    std::cout << " ESC        - Quit" << std::endl;
    std::cout << "========================================" << std::endl;

    // ============================================================
    // Render loop
    // ============================================================
    while (!glfwWindowShouldClose(window)) {
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;
        globalTime = currentFrame;

        processInput(window);

        // ============================================================
        // DOOR ANIMATION + COLLISION UPDATE
        // ============================================================
        for (int di = 0; di < (int)doors.size(); di++) {
            DoorInfo& d = doors[di];
            float targetAngle = d.isOpen ? 90.0f : 0.0f;
            float speed = 120.0f; // degrees per second
            if (d.openAngle < targetAngle) {
                d.openAngle = std::min(d.openAngle + speed * deltaTime, targetAngle);
            }
            else if (d.openAngle > targetAngle) {
                d.openAngle = std::max(d.openAngle - speed * deltaTime, targetAngle);
            }
            // Update collision box: when door is mostly open, shrink/disable main AABB
            if (d.obstacleIndex >= 0 && d.obstacleIndex < (int)obstacles.size()) {
                if (d.openAngle > 45.0f) {
                    // Move the AABB far away to effectively disable it
                    obstacles[d.obstacleIndex].min = glm::vec3(9999.0f);
                    obstacles[d.obstacleIndex].max = glm::vec3(9999.1f);
                }
                else {
                    // Restore original AABB
                    glm::vec3 center = glm::vec3(d.housePos.x, 1.4f, d.housePos.z);
                    glm::vec3 half = glm::vec3(1.9f * d.scale, 2.8f, 1.9f * d.scale);
                    obstacles[d.obstacleIndex].min = center - half;
                    obstacles[d.obstacleIndex].max = center + half;
                }
            }
        }

        // Clear with sky color (day or night)
        if (isNightScene) {
            glClearColor(0.02f, 0.05f, 0.08f, 1.0f);
        }
        else {
            glClearColor(0.45f, 0.65f, 0.95f, 1.0f);  // bright blue sky
        }
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glUseProgram(shaderProgram);

        // Camera matrices
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        if (height == 0) height = 1;
        glm::mat4 projection = glm::perspective(glm::radians(fov),
            (float)width / (float)height, 0.1f, 300.0f);
        glm::mat4 viewMat = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

        setMat4(shaderProgram, "projection", projection);
        setMat4(shaderProgram, "view", viewMat);
        setVec3(shaderProgram, "viewPos", cameraPos);
        setFloat(shaderProgram, "time", globalTime);

        if (isNightScene) {
            // Night: greenish-grey fog, moonlight
            setFloat(shaderProgram, "fogDensity", fogDensity);
            setVec3(shaderProgram, "fogColor", glm::vec3(0.04f, 0.08f, 0.06f));
            setVec3(shaderProgram, "moonDir", glm::vec3(-0.3f, -1.0f, -0.5f));
            setVec3(shaderProgram, "moonColor", glm::vec3(0.6f, 0.65f, 0.8f));
            setFloat(shaderProgram, "moonIntensity", 0.4f);
            setVec3(shaderProgram, "ambientColor", glm::vec3(0.06f, 0.08f, 0.1f));
        }
        else {
            // Day: light blue-white fog, bright sunlight
            setFloat(shaderProgram, "fogDensity", fogDensity * 0.4f);  // less fog during day
            setVec3(shaderProgram, "fogColor", glm::vec3(0.55f, 0.7f, 0.85f));
            // Reuse moonDir/moonColor uniforms as sun direction/color
            setVec3(shaderProgram, "moonDir", glm::vec3(-0.5f, -1.0f, -0.3f));
            setVec3(shaderProgram, "moonColor", glm::vec3(1.0f, 0.95f, 0.85f));
            setFloat(shaderProgram, "moonIntensity", 1.2f);
            setVec3(shaderProgram, "ambientColor", glm::vec3(0.35f, 0.38f, 0.42f));
        }
        setFloat(shaderProgram, "materialShininess", 32.0f);

        // Reset point lights for this frame
        pointLights.clear();

        // Flashlight as point light near camera
        if (flashlightOn) {
            PointLight fl;
            fl.position = cameraPos + cameraFront * 0.5f;
            fl.color = glm::vec3(1.0f, 0.95f, 0.8f);
            fl.radius = 15.0f;
            pointLights.push_back(fl);
        }

        // ============================================================
        // DRAW THE SCENE
        // ============================================================

        // --- Ground (grass) ---
        glm::mat4 groundModel = glm::translate(glm::mat4(1.0f), glm::vec3(0, 0, 0));
        drawObject(groundMesh, groundModel, glm::vec3(0.1f, 0.2f, 0.08f), false, 1.0f, false, false, texGrass);

        // --- Windmill Farm Scene (replaces castle hill) ---
        drawWindmillFarmScene(glm::vec3(-15.0f, 0, -40.0f));


        // --- Main Road (runs along Z axis) ---
        glm::mat4 roadM = glm::translate(glm::mat4(1.0f), glm::vec3(0, 0.02f, 0));
        drawObject(mainRoad, roadM, glm::vec3(0.3f, 0.28f, 0.25f), false, 1.0f, false, false, texRoad);

        // --- Side road to the square ---
        glm::mat4 sideR = glm::translate(glm::mat4(1.0f), glm::vec3(-8.0f, 0.02f, -5.0f));
        sideR = glm::rotate(sideR, glm::radians(90.0f), glm::vec3(0, 1, 0));
        drawObject(sideRoad1, sideR, glm::vec3(0.3f, 0.28f, 0.25f), false, 1.0f, false, false, texRoad);

        // --- Village Square (cobblestone area) ---
        glm::mat4 sqM = glm::translate(glm::mat4(1.0f), glm::vec3(-18.0f, 0.02f, -5.0f));
        drawObject(squareGround, sqM, glm::vec3(0.32f, 0.3f, 0.27f), false, 1.0f, false, false, texRoad);

        // Tree color palette (declared early for use in river section too)
        glm::vec3 darkGreen(0.08f, 0.22f, 0.08f);
        glm::vec3 medGreen(0.1f, 0.3f, 0.1f);
        glm::vec3 lightGreen(0.15f, 0.35f, 0.12f);

        // --- River flowing north-south, far east of village ---
        // Use waterMesh (200x200 ground plane) scaled to a long narrow river strip
        // River at X=35, ~10 units wide, ~150 units long along Z
        glm::mat4 riverMat = glm::translate(glm::mat4(1.0f), glm::vec3(35.0f, 0.03f, 0.0f));
        riverMat = glm::scale(riverMat, glm::vec3(0.05f, 1.0f, 0.75f));
        drawObject(waterMesh, riverMat, glm::vec3(0.1f, 0.22f, 0.38f), false, 0, true);

        // --- Stone Bridge crossing the river ---
        drawDetailedBridge(glm::vec3(35.0f, 0.0f, 0.0f));

        // Road leading from village to bridge
        glm::mat4 bridgeRoad = glm::translate(glm::mat4(1.0f), glm::vec3(18.0f, 0.02f, 0.0f));
        drawObject(sideRoad1, bridgeRoad, glm::vec3(0.3f, 0.28f, 0.25f), false, 1.0f, false, false, texRoad);

        // Road continuing past bridge
        glm::mat4 bridgeRoad2 = glm::translate(glm::mat4(1.0f), glm::vec3(45.0f, 0.02f, 0.0f));
        bridgeRoad2 = glm::scale(bridgeRoad2, glm::vec3(0.5f, 1.0f, 1.0f));
        drawObject(sideRoad1, bridgeRoad2, glm::vec3(0.3f, 0.28f, 0.25f), false, 1.0f, false, false, texRoad);

        // --- Lampposts: ONLY 4, at bridge start and end, off to the sides ---
        drawLampPost(glm::vec3(30.0f, 0, 3.5f));
        drawLampPost(glm::vec3(30.0f, 0, -3.5f));
        drawLampPost(glm::vec3(40.0f, 0, 3.5f));
        drawLampPost(glm::vec3(40.0f, 0, -3.5f));

        // --- Rocks along the riverbank (many more) ---
        drawRocks(glm::vec3(31.0f, 0, -5.0f), 0.7f);
        drawRocks(glm::vec3(39.0f, 0, 3.0f), 0.6f);
        drawRocks(glm::vec3(31.5f, 0, 8.0f), 0.5f);
        drawRocks(glm::vec3(38.5f, 0, -8.0f), 0.8f);
        drawRocks(glm::vec3(31.0f, 0, -15.0f), 0.6f);
        drawRocks(glm::vec3(39.0f, 0, -12.0f), 0.5f);
        drawRocks(glm::vec3(31.5f, 0, 15.0f), 0.7f);
        drawRocks(glm::vec3(38.5f, 0, 12.0f), 0.4f);
        drawRocks(glm::vec3(32.0f, 0, 0.5f), 0.3f);
        drawRocks(glm::vec3(38.0f, 0, -0.5f), 0.35f);
        drawRocks(glm::vec3(31.0f, 0, 20.0f), 0.6f);
        drawRocks(glm::vec3(39.5f, 0, -20.0f), 0.5f);

        // --- Water lilies in the river ---
        drawWaterLily(glm::vec3(34.0f, 0.04f, -8.0f), 0.9f, 25.0f);
        drawWaterLily(glm::vec3(36.5f, 0.04f, -12.0f), 1.1f, 110.0f);
        drawWaterLily(glm::vec3(33.5f, 0.04f, -18.0f), 0.8f, 200.0f);
        drawWaterLily(glm::vec3(37.0f, 0.04f, -22.0f), 1.0f, 65.0f);
        drawWaterLily(glm::vec3(35.5f, 0.04f, 6.0f), 1.2f, 150.0f);
        drawWaterLily(glm::vec3(34.5f, 0.04f, 10.0f), 0.7f, 280.0f);
        drawWaterLily(glm::vec3(36.0f, 0.04f, 15.0f), 1.0f, 45.0f);
        drawWaterLily(glm::vec3(33.8f, 0.04f, 20.0f), 0.85f, 320.0f);
        drawWaterLily(glm::vec3(37.2f, 0.04f, -28.0f), 0.95f, 175.0f);
        drawWaterLily(glm::vec3(34.2f, 0.04f, 25.0f), 1.05f, 90.0f);
        drawWaterLily(glm::vec3(36.8f, 0.04f, -35.0f), 0.75f, 240.0f);
        drawWaterLily(glm::vec3(35.0f, 0.04f, 30.0f), 1.15f, 10.0f);

        // --- Trees along the river ---
        drawTree(glm::vec3(29.0f, 0, -10.0f), 1.1f, darkGreen);
        drawTree(glm::vec3(29.0f, 0, -30.0f), 1.1f, darkGreen);
        drawTree(glm::vec3(40.0f, 0, -7.0f), 0.9f, medGreen);
        drawTree(glm::vec3(29.0f, 0, 7.0f), 1.0f, darkGreen);
        drawTree(glm::vec3(40.5f, 0, 10.0f), 1.2f, medGreen);
        drawTree(glm::vec3(30.5f, 0, -20.0f), 1.0f, darkGreen);
        drawTree(glm::vec3(40.5f, 0, -18.0f), 0.85f, medGreen);
        drawTree(glm::vec3(29.0f, 0, 18.0f), 0.95f, darkGreen);
        drawTree(glm::vec3(40.0f, 0, 20.0f), 1.1f, medGreen);
        // Trees along the bridge road
        drawTree(glm::vec3(15.0f, 0, 3.0f), 0.9f, lightGreen);
        drawTree(glm::vec3(21.0f, 0, -3.0f), 1.0f, darkGreen);
        drawTree(glm::vec3(27.0f, 0, 3.0f), 0.85f, medGreen);

        // ============================================================
        // COTTAGE HOUSES - Cozy stone cottages with thatched roofs
        // ============================================================
        drawCottageHouse(glm::vec3(-14.0f, 0, -5.0f), 90, 1.0f, 0);
        drawCottageHouse(glm::vec3(-22.0f, 0, -5.0f), -90, 1.05f, 1);
        drawCottageHouse(glm::vec3(4.5f, 0, -5.0f), -5, 1.0f, 2);
        drawCottageHouse(glm::vec3(-4.5f, 0, 2.0f), 180, 0.95f, 3);

        // --- Well in the village square ---
        drawWell(glm::vec3(-18.0f, 0, -5.0f));

        // --- Hay cart in the square (between cottages) ---
        drawHayCart(glm::vec3(-19.0f, 0, -9.0f), -10);

        // --- Benches in the square ---
        drawBench(glm::vec3(-15.0f, 0, -15.5f), 0);
        drawBench(glm::vec3(-15.0f, 0, -15.5f), 0);

        // ============================================================
        // CHURCH / CHAPEL (behind the square)
        // ============================================================
        drawChurch(glm::vec3(-18.0f, 0, 8.0f), 0);

        // --- Hay bales near the church ---
        drawHayBale(glm::vec3(-23.0f, 0, 6.0f), 30);
        drawHayBale(glm::vec3(-24.0f, 0, 7.5f), -15);
        drawHayBale(glm::vec3(-23.5f, 0, 6.8f), 5);  // stacked on top
        drawHayBale(glm::vec3(-12.0f, 0, 10.0f), 45);

        // ============================================================
        // CONIFER / PINE TREES around the church
        // ============================================================
        drawConiferTree(glm::vec3(-12.0f, 0, 12.0f), 1.0f);
        drawConiferTree(glm::vec3(-24.0f, 0, 12.0f), 1.2f);
        drawConiferTree(glm::vec3(-14.0f, 0, 15.0f), 0.9f);
        drawConiferTree(glm::vec3(-22.0f, 0, 15.0f), 1.1f);
        drawConiferTree(glm::vec3(-10.0f, 0, 8.0f), 0.85f);
        drawConiferTree(glm::vec3(-26.0f, 0, 9.0f), 1.0f);

        drawConiferTree(glm::vec3(-15.0f, 0, 20.0f), 0.95f);

        // ============================================================
        // LAMP POSTS (trimmed for sparser layout)
        // ============================================================
        // Along main road (fewer)
        drawLampPost(glm::vec3(2.5f, 0, -3.0f));
        drawLampPost(glm::vec3(2.5f, 0, 6.0f));
        drawLampPost(glm::vec3(-2.5f, 0, 0.0f));
        // Village square
        drawLampPost(glm::vec3(-18.0f, 0, -1.0f));
        // Near church
        drawLampPost(glm::vec3(-15.0f, 0, 6.0f));
        // Park area lamps
        drawLampPost(glm::vec3(-30.0f, 0, 5.0f));
        drawLampPost(glm::vec3(-35.0f, 0, 5.0f));
        drawLampPost(glm::vec3(-30.0f, 0, 12.0f));
        drawLampPost(glm::vec3(-35.0f, 0, 12.0f));

        // ============================================================
        // TREES
        // ============================================================
        // Trees along roads

        drawTree(glm::vec3(-6.0f, 0, -8.0f), 1.0f, darkGreen);
        drawTree(glm::vec3(-6.0f, 0, 1.0f), 1.2f, medGreen);
        drawTree(glm::vec3(-6.5f, 0, 8.0f), 0.9f, darkGreen);
        drawTree(glm::vec3(7.0f, 0, 7.0f), 1.1f, lightGreen);
        drawTree(glm::vec3(7.5f, 0, 4.0f), 0.8f, medGreen);
        drawTree(glm::vec3(7.5f, 0, -4.0f), 1.0f, darkGreen);

        // Trees near windmill farm scene
        drawTree(glm::vec3(-55.0f, 0, -35.0f), 1.3f, darkGreen);
        drawTree(glm::vec3(-20.0f, 0, -30.0f), 1.2f, darkGreen);

        // Park area with tree-lined path (from image 3)
        for (int i = 0; i < 6; i++) {
            drawTree(glm::vec3(-28.0f, 0, 3.0f + i * 3.0f), 1.3f, darkGreen);
            drawTree(glm::vec3(-37.0f, 0, 3.0f + i * 3.0f), 1.3f, darkGreen);
        }
        // More trees behind the rows
        for (int i = 0; i < 5; i++) {
            drawTree(glm::vec3(-26.0f, 0, 4.5f + i * 3.0f), 1.0f, medGreen);
            drawTree(glm::vec3(-39.0f, 0, 4.5f + i * 3.0f), 1.0f, medGreen);
        }

        // Scattered trees
        drawTree(glm::vec3(15.0f, 0, -15.0f), 1.2f, darkGreen);
        drawTree(glm::vec3(-25.0f, 0, -15.0f), 1.4f, medGreen);
        drawTree(glm::vec3(10.0f, 0, 15.0f), 1.0f, lightGreen);
        drawTree(glm::vec3(-10.0f, 0, 15.0f), 1.1f, darkGreen);

        // ============================================================
        // Benches in the park area
        // ============================================================
        drawBench(glm::vec3(-32.0f, 0, 7.0f), 0);
        drawBench(glm::vec3(-32.0f, 0, 13.0f), 0);
        drawBench(glm::vec3(-33.0f, 0, 10.0f), 90);

        // ============================================================
        // Farmstead with Fields (past the bridge)
        // ============================================================
        drawFarmstead(glm::vec3(55.0f, 0, -20.0f));

        // ============================================================
        // Rocks in the village
        // ============================================================
        drawRocks(glm::vec3(-5.0f, 0, -12.0f), 0.5f);
        drawRocks(glm::vec3(6.0f, 0, 13.0f), 0.4f);

        // ============================================================
        // Set point lights in shader
        // ============================================================
        setInt(shaderProgram, "numPointLights", std::min((int)pointLights.size(), 40));
        for (int i = 0; i < (int)pointLights.size() && i < 40; i++) {
            std::string base = "pointLightPos[" + std::to_string(i) + "]";
            setVec3(shaderProgram, base, pointLights[i].position);
            base = "pointLightColor[" + std::to_string(i) + "]";
            setVec3(shaderProgram, base, pointLights[i].color);
            base = "pointLightRadius[" + std::to_string(i) + "]";
            setFloat(shaderProgram, base, pointLights[i].radius);
        }

        // ============================================================
        // Moon (rendered as a distant billboard)
        // ============================================================
        // --- Clouds (day and night) ---
        drawClouds();

        // Moon and stars only at night
        if (isNightScene) {
            setBool(shaderProgram, "isEmissive", true);
            setFloat(shaderProgram, "emissiveStrength", 1.5f);
            setBool(shaderProgram, "isStar", false);
            glm::vec3 moonPos = cameraPos + glm::vec3(-30.0f, 50.0f, -60.0f);
            glm::mat4 moonModel = glm::translate(glm::mat4(1.0f), moonPos);
            drawObject(moonMesh, moonModel, glm::vec3(0.95f, 0.93f, 0.85f), true, 1.5f);

            // ============================================================
            // Stars
            // ============================================================
            setBool(shaderProgram, "isStar", true);
            float starPositions[][3] = {
                {-20, 60, -50}, {10, 70, -45}, {-40, 55, -35}, {30, 65, -55},
                {-15, 75, -60}, {25, 58, -40}, {-35, 68, -50}, {5, 72, -38},
                {40, 60, -45}, {-50, 63, -42}, {15, 78, -52}, {-25, 56, -48},
                {35, 70, -58}, {-10, 64, -36}, {20, 76, -44}, {-45, 59, -53}
            };
            for (int i = 0; i < 16; i++) {
                glm::vec3 sp = cameraPos + glm::vec3(starPositions[i][0], starPositions[i][1], starPositions[i][2]);
                glm::mat4 sm = glm::translate(glm::mat4(1.0f), sp);
                float twinkleScale = 0.8f + 0.4f * sin(globalTime * 1.5f + i * 2.0f);
                sm = glm::scale(sm, glm::vec3(twinkleScale));
                setMat4(shaderProgram, "model", sm);
                setVec3(shaderProgram, "materialColor", glm::vec3(1.0f, 1.0f, 0.9f));
                setBool(shaderProgram, "useVertexColor", false);
                setBool(shaderProgram, "isEmissive", false);
                setBool(shaderProgram, "isWater", false);
                drawMesh(starMesh);
            }
            setBool(shaderProgram, "isStar", false);
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}